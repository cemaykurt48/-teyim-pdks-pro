import { assertFails, assertSucceeds, initializeTestEnvironment, RulesTestEnvironment } from '@firebase/rules-unit-testing';
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'fs';
import { resolve } from 'path';

let testEnv: RulesTestEnvironment;

beforeAll(async () => {
  const rulesPath = resolve(__dirname, 'DRAFT_firestore.rules');
  const rules = readFileSync(rulesPath, 'utf8');
  
  testEnv = await initializeTestEnvironment({
    projectId: 'test-project',
    firestore: {
      rules,
    },
  });
});

afterAll(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  await testEnv.clearFirestore();
});

describe('İşteyim App Firestore Rules', () => {
  test('Payload 1: Identity Spoofing - update changing ownerId should fail', async () => {
    await testEnv.withSecurityRulesDisabled(async (context) => {
      const db = context.firestore();
      await db.collection('companies').doc('comp1').set({
        name: 'My Company',
        ownerId: 'user_alice',
        status: 'active',
        createdAt: new Date(),
      });
    });

    const aliceContext = testEnv.authenticatedContext('user_alice', { email_verified: true });
    const compRef = aliceContext.firestore().collection('companies').doc('comp1');

    await assertFails(compRef.update({
      ownerId: 'user_bob',
      updatedAt: testEnv.firestore.FieldValue.serverTimestamp(),
    }));
  });

  test('Payload 3: Ghost Field - adding an unknown field', async () => {
    const context = testEnv.authenticatedContext('user_alice', { email_verified: true });
    const compRef = context.firestore().collection('companies').doc('comp2');

    await assertFails(compRef.set({
      name: 'Valid Name',
      ownerId: 'user_alice',
      status: 'active',
      isVerified: true, // Ghost field
      createdAt: testEnv.firestore.FieldValue.serverTimestamp(),
    }));
  });

  test('Payload 4: DoW - giant string', async () => {
    const context = testEnv.authenticatedContext('user_alice', { email_verified: true });
    const compRef = context.firestore().collection('companies').doc('comp3');

    await assertFails(compRef.set({
      name: 'a'.repeat(200), // > 100
      ownerId: 'user_alice',
      status: 'active',
      createdAt: testEnv.firestore.FieldValue.serverTimestamp(),
    }));
  });

  test('Payload 12: Unverified user - email_verified is false', async () => {
    const context = testEnv.authenticatedContext('user_unverified', { email_verified: false });
    const compRef = context.firestore().collection('companies').doc('comp4');
    
    await assertFails(compRef.set({
      name: 'Test',
      ownerId: 'user_unverified',
      status: 'active',
      createdAt: testEnv.firestore.FieldValue.serverTimestamp(),
    }));
  });
  
  test('Valid creation succeeds', async () => {
    const context = testEnv.authenticatedContext('user_alice', { email_verified: true });
    const compRef = context.firestore().collection('companies').doc('comp5');
    
    await assertSucceeds(compRef.set({
      name: 'Test Comp',
      ownerId: 'user_alice',
      status: 'active',
      createdAt: testEnv.firestore.FieldValue.serverTimestamp(),
    }));
  });
});
