"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { QrCode, ArrowRight, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { auth, googleProvider } from "@/lib/firebase";
import { signInWithPopup } from "firebase/auth";
import { toast } from "sonner";

const registerSchema = z.object({
  firstName: z.string().min(2, "Ad en az 2 karakter olmalıdır"),
  lastName: z.string().min(2, "Soyad en az 2 karakter olmalıdır"),
  email: z.string().email("Geçerli bir e-posta adresi giriniz"),
  password: z.string().min(6, "Şifre en az 6 karakter olmalıdır"),
});

export default function RegisterPage() {
  const router = useRouter();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleGoogleSignUp = async () => {
    setIsSubmitting(true);
    try {
      await signInWithPopup(auth, googleProvider);
      toast.success("Google ile kayıt başarılı!");
      router.push("/onboarding");
    } catch (error: any) {
      console.error("Google sign-up error:", error);
      toast.error("Google ile kayıt olurken bir hata oluştu.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const form = useForm({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      password: "",
    }
  });

  const onSubmit = (data: any) => {
    setIsSubmitting(true);
    // Simulate API call for registration
    setTimeout(() => {
      setIsSubmitting(false);
      router.push("/onboarding");
    }, 1000);
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-slate-50 dark:bg-slate-950">
      
      {/* LEFT PANEL - BRANDING */}
      <div className="hidden md:flex w-full md:w-[45%] lg:w-[40%] bg-blue-600 p-8 md:p-12 flex-col justify-between relative overflow-hidden text-white">
        {/* Background Elements */}
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
          <div className="absolute -top-24 -left-24 w-96 h-96 bg-white opacity-10 rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-blue-400 opacity-20 rounded-full blur-3xl translate-x-1/3 translate-y-1/3"></div>
        </div>

        <div className="relative z-10">
          <Link href="/" className="flex items-center gap-2 mb-12 w-fit">
            <div className="bg-white text-blue-600 p-1.5 rounded-lg">
              <QrCode className="h-6 w-6" />
            </div>
            <span className="font-bold text-2xl tracking-tight">İşteyim</span>
          </Link>

          <div className="space-y-6">
            <h1 className="text-3xl md:text-4xl font-bold leading-tight">
              İşletmenizi dijitalleştirmeye hazır mısınız?
            </h1>
            <p className="text-blue-100 text-lg">
              Saniyeler içinde hesabınızı oluşturun, personel ve vardiya yönetimine hemen başlayın.
            </p>
          </div>
        </div>

        <div className="relative z-10 mt-12 text-blue-200 text-sm flex items-center gap-2">
          <ShieldCheck className="w-5 h-5" />
          <span>Kişisel verileriniz KVKK kapsamında korunmaktadır</span>
        </div>
      </div>

      {/* RIGHT PANEL - REGISTRATION FORM */}
      <div className="flex-1 flex items-center justify-center p-6 md:p-12 overflow-y-auto">
        <div className="w-full max-w-md space-y-8">
          
          {/* Mobile Header */}
          <div className="md:hidden flex justify-center mb-8">
            <Link href="/" className="flex items-center gap-2 w-fit">
              <div className="bg-blue-600 text-white p-1.5 rounded-lg">
                <QrCode className="h-6 w-6" />
              </div>
              <span className="font-bold text-2xl tracking-tight text-blue-600">İşteyim</span>
            </Link>
          </div>

          <div className="space-y-2 text-center md:text-left">
            <h2 className="text-3xl font-bold tracking-tight">Hesap Oluştur</h2>
            <p className="text-muted-foreground">
              Ücretsiz hesabınızı hemen oluşturun.
            </p>
          </div>

          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Adınız</Label>
                  <Input {...form.register("firstName")} placeholder="Örn: Ahmet" className="h-11 rounded-xl bg-white dark:bg-slate-900" />
                  {form.formState.errors.firstName && <p className="text-xs text-rose-500">{form.formState.errors.firstName.message as string}</p>}
                </div>
                <div className="space-y-2">
                  <Label>Soyadınız</Label>
                  <Input {...form.register("lastName")} placeholder="Örn: Yılmaz" className="h-11 rounded-xl bg-white dark:bg-slate-900" />
                  {form.formState.errors.lastName && <p className="text-xs text-rose-500">{form.formState.errors.lastName.message as string}</p>}
                </div>
              </div>
              <div className="space-y-2">
                <Label>E-posta Adresiniz</Label>
                <Input {...form.register("email")} type="email" placeholder="ornek@sirket.com" className="h-11 rounded-xl bg-white dark:bg-slate-900" />
                {form.formState.errors.email && <p className="text-xs text-rose-500">{form.formState.errors.email.message as string}</p>}
              </div>
              <div className="space-y-2">
                <Label>Şifreniz</Label>
                <Input {...form.register("password")} type="password" placeholder="••••••••" className="h-11 rounded-xl bg-white dark:bg-slate-900" />
                {form.formState.errors.password && <p className="text-xs text-rose-500">{form.formState.errors.password.message as string}</p>}
              </div>
            </div>

            <Button 
              type="submit" 
              disabled={isSubmitting}
              className="w-full h-14 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white text-lg font-semibold shadow-xl shadow-blue-200 dark:shadow-none transition-all"
            >
              {isSubmitting ? (
                <div className="flex items-center gap-2">
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  İşleniyor...
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  Ücretsiz Kayıt Ol
                  <ArrowRight className="w-5 h-5" />
                </div>
              )}
            </Button>

            <div className="relative my-4">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t border-slate-200" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-slate-50 dark:bg-slate-950 px-2 text-muted-foreground whitespace-nowrap">veya</span>
              </div>
            </div>

            <Button 
              type="button" 
              variant="outline" 
              className="w-full h-14 rounded-2xl border-slate-200 hover:bg-slate-50 dark:hover:bg-slate-900 text-slate-700 dark:text-slate-300 gap-3 font-medium transition-all"
              onClick={handleGoogleSignUp}
              disabled={isSubmitting}
            >
              <svg className="h-5 w-5" viewBox="0 0 24 24">
                <path
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  fill="#4285F4"
                />
                <path
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  fill="#34A853"
                />
                <path
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"
                  fill="#FBBC05"
                />
                <path
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                  fill="#EA4335"
                />
              </svg>
              Google ile Devam Et
            </Button>
            
            <p className="text-center text-sm text-muted-foreground">
              Zaten bir hesabınız var mı? <Link href="/login" className="text-blue-600 hover:underline font-medium">Giriş Yapın</Link>
            </p>
          </form>
        </div>
      </div>
    </div>
  );
}
