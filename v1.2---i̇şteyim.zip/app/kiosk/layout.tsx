export default function KioskLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col font-sans selection:bg-primary/30">
      {children}
    </div>
  );
}
