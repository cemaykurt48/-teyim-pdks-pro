"use client";

import { useState, useEffect } from "react";
import { useParams, useRouter } from "next/navigation";
import { QrCode, ArrowLeft, Delete } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

export default function KioskPage() {
  const params = useParams();
  const router = useRouter();
  const branchId = params.branchId as string;
  
  const [pin, setPin] = useState("");
  const [time, setTime] = useState("");
  const [qrKey, setQrKey] = useState(0);

  useEffect(() => {
    const updateTime = () => {
      setTime(new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" }));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Refresh QR every 10 seconds
  useEffect(() => {
    const qrInterval = setInterval(() => {
      setQrKey(prev => prev + 1);
    }, 10000);
    return () => clearInterval(qrInterval);
  }, []);

  const handlePinPress = (num: string) => {
    if (pin.length < 4) {
      setPin(prev => prev + num);
    }
  };

  const handleDelete = () => {
    setPin(prev => prev.slice(0, -1));
  };

  const handleEnter = () => {
    if (pin.length !== 4) {
      toast.error("Lütfen 4 haneli PIN girin");
      return;
    }
    
    // Mock validation
    if (pin === "1234") {
      toast.success("Giriş başarılı! Hoş geldin.");
      setPin("");
    } else {
      toast.error("Hatalı PIN kodu.");
      setPin("");
    }
  };

  return (
    <div className="flex-1 flex flex-col lg:flex-row h-[100dvh] overflow-hidden bg-slate-900">
      {/* Header for mobile, absolute for desktop */}
      <div className="lg:absolute top-0 left-0 w-full p-6 flex justify-between items-center z-10">
        <Button variant="ghost" className="text-slate-300 hover:text-white hover:bg-white/10" onClick={() => router.push("/dashboard/branches")}>
          <ArrowLeft className="mr-2 h-5 w-5" />
          Panele Dön
        </Button>
        <div className="text-2xl font-bold tracking-tighter text-white">{time || "00:00"}</div>
      </div>

      {/* Left Side: QR Code */}
      <div className="flex-1 flex flex-col items-center justify-center p-8 border-b lg:border-b-0 lg:border-r border-slate-800 relative">
        <div className="text-center mb-8 mt-12 lg:mt-0">
          <h1 className="text-3xl font-bold text-white mb-2">Şube Girişi</h1>
          <p className="text-slate-400">İşteyim uygulamasından QR kodu okutun</p>
        </div>

        <div className="relative">
          <div className="w-64 h-64 bg-white rounded-3xl p-4 shadow-2xl flex items-center justify-center relative overflow-hidden">
            {/* Simulated Dynamic QR */}
            <div key={qrKey} className="w-full h-full bg-slate-900 rounded-xl flex flex-wrap p-2 gap-1 animate-in fade-in duration-500">
              {Array.from({ length: 100 }).map((_, i) => {
                // Use a pseudo-random stable pattern based on qrKey and index
                const isVisible = ((i * 13 + qrKey * 7) % 10) > 4;
                return (
                  <div key={i} className={cn("w-[8%] h-[8%] bg-white", isVisible ? "opacity-100" : "opacity-0")} />
                );
              })}
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="bg-white p-3 rounded-xl shadow-lg">
                  <QrCode className="h-10 w-10 text-primary" />
                </div>
              </div>
            </div>
          </div>
          
          {/* Progress bar for QR refresh */}
          <div className="absolute -bottom-8 left-0 w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
            <div key={qrKey} className="h-full bg-primary animate-[shrink_10s_linear]" />
          </div>
        </div>
      </div>

      {/* Right Side: PIN Entry */}
      <div className="flex-1 flex flex-col items-center justify-center p-8 bg-slate-950">
        <div className="text-center mb-8">
          <h2 className="text-2xl font-semibold text-white mb-2">PIN ile Giriş</h2>
          <p className="text-slate-400 text-sm">Sadece yetkili personeller içindir</p>
        </div>

        {/* PIN Display */}
        <div className="flex gap-4 mb-8">
          {[0, 1, 2, 3].map((i) => (
            <div 
              key={i} 
              className={cn(
                "w-14 h-16 rounded-xl border-2 flex items-center justify-center text-3xl font-bold transition-all",
                pin.length > i 
                  ? "border-primary bg-primary/20 text-white" 
                  : "border-slate-800 bg-slate-900 text-slate-600"
              )}
            >
              {pin.length > i ? "•" : ""}
            </div>
          ))}
        </div>

        {/* Numpad */}
        <div className="grid grid-cols-3 gap-4 max-w-[300px] w-full">
          {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
            <Button 
              key={num} 
              variant="outline" 
              className="h-16 text-2xl font-medium border-slate-800 bg-slate-900 text-white hover:bg-slate-800 hover:text-white rounded-2xl"
              onClick={() => handlePinPress(num.toString())}
            >
              {num}
            </Button>
          ))}
          <Button 
            variant="outline" 
            className="h-16 text-xl font-medium border-slate-800 bg-slate-900 text-slate-400 hover:bg-slate-800 hover:text-white rounded-2xl"
            onClick={handleDelete}
          >
            <Delete className="h-6 w-6" />
          </Button>
          <Button 
            variant="outline" 
            className="h-16 text-2xl font-medium border-slate-800 bg-slate-900 text-white hover:bg-slate-800 hover:text-white rounded-2xl"
            onClick={() => handlePinPress("0")}
          >
            0
          </Button>
          <Button 
            className="h-16 text-lg font-medium bg-primary hover:bg-primary/90 text-white rounded-2xl"
            onClick={handleEnter}
          >
            GİRİŞ
          </Button>
        </div>
      </div>
    </div>
  );
}
