/* eslint-disable react-hooks/set-state-in-effect */
"use client";

import { useState, useEffect } from "react";
import { Download, FileSpreadsheet, Search, Printer, Info, Save, MessageCircle, UserCheck, Clock, CalendarX2, CheckCircle2, AlertCircle, Building2, ChevronDown, ChevronUp } from "lucide-react";
import { InfoBubble } from "@/components/info-bubble";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

interface ReportRow {
  id: number;
  name: string;
  branch: string;
  expectedDays: number;
  attendedDays: number;
  absentDays: number;
  lateMinutes: number;
  overtimeHours: number;
  manualBonus: string;
  manualDeduction: string;
  manualNote: string;
}

const initialData: ReportRow[] = [
  { id: 1, name: "Ayşe Yılmaz", branch: "Merkez Şube", expectedDays: 26, attendedDays: 26, absentDays: 0, lateMinutes: 15, overtimeHours: 4, manualBonus: "", manualDeduction: "", manualNote: "" },
  { id: 3, name: "Zeynep Kaya", branch: "Merkez Şube", expectedDays: 26, attendedDays: 23, absentDays: 0, lateMinutes: 0, overtimeHours: 0, manualBonus: "", manualDeduction: "", manualNote: "3 gün yıllık izinli" },
  { id: 5, name: "Hasan Kaya", branch: "Merkez Şube", expectedDays: 26, attendedDays: 26, absentDays: 0, lateMinutes: 0, overtimeHours: 0, manualBonus: "", manualDeduction: "", manualNote: "" },
  { id: 2, name: "Mehmet Demir", branch: "Kadıköy Şube", expectedDays: 26, attendedDays: 25, absentDays: 1, lateMinutes: 45, overtimeHours: 0, manualBonus: "", manualDeduction: "", manualNote: "1 gün mazeretsiz" },
  { id: 4, name: "Ali Veli", branch: "Kadıköy Şube", expectedDays: 26, attendedDays: 26, absentDays: 0, lateMinutes: 120, overtimeHours: 12, manualBonus: "500", manualDeduction: "", manualNote: "Hafta sonu mesaisi" },
];

export default function ReportsPage() {
  const [reportData, setReportData] = useState<ReportRow[]>(initialData);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedMobileRowId, setSelectedMobileRowId] = useState<number | null>(null);
  const [selectedMonth, setSelectedMonth] = useState("nisan-2026");
  const [expandedBranches, setExpandedBranches] = useState<string[]>([]);
  const [hasInitialized, setHasInitialized] = useState(false);

  const selectedMobileRow = reportData.find(r => r.id === selectedMobileRowId);

  const handleInputChange = (id: number, field: keyof ReportRow, value: string) => {
    setReportData(prev => prev.map(row => 
      row.id === id ? { ...row, [field]: value } : row
    ));
  };

  const filteredData = reportData.filter(row => 
    row.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    row.branch.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Verileri Şubelere Göre Grupla
  const branches = Array.from(new Set(filteredData.map(r => r.branch)));
  const groupedData = branches.map(branch => {
    const personnel = filteredData.filter(r => r.branch === branch);
    return {
      branch,
      personnel,
      totalOvertime: personnel.reduce((acc, r) => acc + r.overtimeHours, 0),
      totalAbsent: personnel.reduce((acc, r) => acc + r.absentDays, 0),
    };
  });

  // İlk açılışta ilk şubeyi açık bırak
  useEffect(() => {
    if (groupedData.length > 0 && !hasInitialized) {
      setExpandedBranches([groupedData[0].branch]);
      setHasInitialized(true);
    }
  }, [groupedData, hasInitialized]);

  // Arama yapıldığında tüm eşleşen şubeleri aç
  useEffect(() => {
    if (searchQuery) {
      setExpandedBranches(groupedData.map(g => g.branch));
    }
  }, [searchQuery, groupedData]);

  const toggleBranch = (branch: string) => {
    setExpandedBranches(prev => 
      prev.includes(branch) ? prev.filter(b => b !== branch) : [...prev, branch]
    );
  };

  // Genel Metrik Hesaplamaları
  const perfectStaffCount = reportData.filter(r => r.absentDays === 0 && r.lateMinutes === 0).length;
  const totalOvertime = reportData.reduce((acc, r) => acc + r.overtimeHours, 0);
  const totalAbsent = reportData.reduce((acc, r) => acc + r.absentDays, 0);

  const handleSave = () => {
    toast.success("Değişiklikler başarıyla kaydedildi.");
  };

  const handleExportExcel = (silent = false) => {
    if (!silent) toast.success("Excel dosyası hazırlanıyor...");
    
    let excelData: any[] = [];
    
    groupedData.forEach(group => {
      excelData.push({
        'Personel': `--- ${group.branch.toUpperCase()} ---`,
        'Çalışması Gereken (Gün)': '',
        'Geldiği Gün': '',
        'Devamsız Gün': '',
        'Geç Kalma (Dk)': '',
        'Ek Mesai (Saat)': '',
        'Prim (TL)': '',
        'Kesinti (TL)': '',
        'Muhasebeye Not': ''
      });
      
      group.personnel.forEach(row => {
        excelData.push({
          'Personel': row.name,
          'Çalışması Gereken (Gün)': row.expectedDays,
          'Geldiği Gün': row.attendedDays,
          'Devamsız Gün': row.absentDays,
          'Geç Kalma (Dk)': row.lateMinutes,
          'Ek Mesai (Saat)': row.overtimeHours,
          'Prim (TL)': row.manualBonus,
          'Kesinti (TL)': row.manualDeduction,
          'Muhasebeye Not': row.manualNote
        });
      });
      
      excelData.push({}); // Boş satır
    });

    const ws = XLSX.utils.json_to_sheet(excelData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Puantaj Raporu");

    const colWidths = [
      { wch: 25 }, { wch: 25 }, { wch: 15 }, { wch: 15 },
      { wch: 15 }, { wch: 15 }, { wch: 15 }, { wch: 15 }, { wch: 30 }
    ];
    ws['!cols'] = colWidths;

    XLSX.writeFile(wb, `Puantaj_${selectedMonth.replace('-', '_')}.xlsx`);
    if (!silent) toast.success("Excel dosyası başarıyla indirildi.");
  };

  const normalizeTr = (text: string) => {
    if (!text) return "";
    return text.toString()
      .replace(/Ğ/g, 'G')
      .replace(/ğ/g, 'g')
      .replace(/Ü/g, 'U')
      .replace(/ü/g, 'u')
      .replace(/Ş/g, 'S')
      .replace(/ş/g, 's')
      .replace(/İ/g, 'I')
      .replace(/ı/g, 'i')
      .replace(/Ö/g, 'O')
      .replace(/ö/g, 'o')
      .replace(/Ç/g, 'C')
      .replace(/ç/g, 'c');
  };

  const handleExportPDF = async (silent = false) => {
    if (!silent) toast.success("PDF dosyası hazırlanıyor, lütfen bekleyin...");
    try {
      const doc = new jsPDF('p'); // Portrait
      
      doc.setFontSize(16);
      doc.text(normalizeTr(`Puantaj Raporu - ${selectedMonth.toUpperCase()}`), 14, 15);

      let currentY = 25;

      groupedData.forEach((group, index) => {
        if (index !== 0) {
          // @ts-ignore
          currentY = doc.lastAutoTable.finalY + 15;
          if (currentY > 250) {
            doc.addPage();
            currentY = 20;
          }
        }
        
        doc.setFontSize(12);
        doc.setFont('helvetica', 'bold');
        doc.text(normalizeTr(`Sube: ${group.branch} (${group.personnel.length} Personel)`), 14, currentY);
        
        autoTable(doc, {
          head: [[ 'Personel', 'Gereken', 'Geldi', 'Devamsiz', 'Gec(Dk)', 'Mesai(S)', 'Prim', 'Kesinti', 'Not' ]],
          body: group.personnel.map(row => [
            normalizeTr(row.name),
            row.expectedDays.toString(),
            row.attendedDays.toString(),
            row.absentDays.toString(),
            row.lateMinutes.toString(),
            row.overtimeHours.toString(),
            row.manualBonus,
            row.manualDeduction,
            normalizeTr(row.manualNote)
          ]),
          startY: currentY + 5,
          theme: 'striped',
          headStyles: { fillColor: [220, 220, 220], textColor: [0, 0, 0], fontStyle: 'bold', fontSize: 9 },
          bodyStyles: { textColor: [55, 65, 81], fontSize: 9 },
          columnStyles: {
            0: { cellWidth: 30 },
            1: { cellWidth: 15, halign: 'center' },
            2: { cellWidth: 15, halign: 'center', textColor: [4, 124, 70] },
            3: { cellWidth: 15, halign: 'center', textColor: [239, 68, 68] },
            4: { cellWidth: 15, halign: 'center', textColor: [217, 119, 6] },
            5: { cellWidth: 15, halign: 'center', textColor: [37, 99, 235] },
            6: { cellWidth: 15, halign: 'right' },
            7: { cellWidth: 15, halign: 'right', textColor: [239, 68, 68] },
            8: { cellWidth: 'auto' }
          },
          alternateRowStyles: { fillColor: [250, 250, 250] }
        });
      });

      doc.save(`Puantaj_${selectedMonth.replace('-', '_')}.pdf`);
      if (!silent) toast.success("PDF dosyası başarıyla indirildi.");
    } catch (error) {
      console.error("PDF oluşturulurken hata:", error);
      if (!silent) toast.error("PDF oluşturulurken bir hata oluştu.");
    }
  };

  const handleWhatsAppShare = () => {
    let text = `*${selectedMonth.replace('-', ' ').toUpperCase()} PUANTAJ RAPORU*\n\n`;
    
    groupedData.forEach(group => {
      text += `🏢 *${group.branch.toUpperCase()}*\n`;
      group.personnel.forEach(p => {
        let details = [];
        details.push(`${p.attendedDays} Gün Geldi`);
        if (p.absentDays > 0) details.push(`${p.absentDays} Gün Devamsız`);
        if (p.lateMinutes > 0) details.push(`${p.lateMinutes} Dk Geç`);
        if (p.overtimeHours > 0) details.push(`${p.overtimeHours} Saat Mesai`);
        if (p.manualBonus) details.push(`${p.manualBonus} TL Prim`);
        if (p.manualDeduction) details.push(`${p.manualDeduction} TL Kesinti`);
        if (p.manualNote) details.push(`Not: ${p.manualNote}`);
        
        text += `- ${p.name}: ${details.join(', ')}\n`;
      });
      text += `\n`;
    });

    text += `📊 *GENEL ÖZET*\n`;
    text += `Kusursuz Çalışan: ${perfectStaffCount} Kişi\n`;
    text += `Toplam Ek Mesai: ${totalOvertime} Saat\n`;
    text += `Toplam Devamsızlık: ${totalAbsent} Gün\n`;

    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
    toast.success("WhatsApp'a yönlendiriliyor...");
  };

  const getStatusBadge = (row: ReportRow) => {
    if (row.absentDays > 0 || row.lateMinutes > 0) {
      return <Badge variant="outline" className="bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-200 dark:border-rose-500/20 gap-1 whitespace-nowrap"><AlertCircle className="w-3 h-3"/> Devamsız/Geç</Badge>;
    }
    if (row.overtimeHours > 0) {
      return <Badge variant="outline" className="bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-200 dark:border-blue-500/20 gap-1 whitespace-nowrap"><Clock className="w-3 h-3"/> Ek Mesai</Badge>;
    }
    return <Badge variant="outline" className="bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-200 dark:border-emerald-500/20 gap-1 whitespace-nowrap"><CheckCircle2 className="w-3 h-3"/> Sorunsuz</Badge>;
  };

  return (
    <div className="space-y-6 pb-20 md:pb-0">
      
      {/* BÖLÜM 1: Kompakt Mavi Özet Alanı */}
      <div className="bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 text-white rounded-2xl p-6 flex flex-col gap-5 shadow-xl relative overflow-hidden">
        {/* Dekoratif Arka Plan Efektleri */}
        <div className="absolute top-0 right-0 -mt-16 -mr-16 w-64 h-64 bg-white opacity-5 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 -mb-16 -ml-16 w-48 h-48 bg-blue-400 opacity-10 rounded-full blur-2xl pointer-events-none"></div>

        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-2">
            <h2 className="text-2xl font-bold">Puantaj ve Raporlar</h2>
            <InfoBubble content="Personellerin ay boyunca kaç gün ve kaç saat çalıştığını gösteren, maaş hesaplamasında kullanılan temel rapordur." className="w-6 h-6 hover:bg-white/10" iconClassName="text-blue-200 hover:text-white" />
          </div>
          <p className="text-blue-100 text-sm md:text-base max-w-2xl">
            <strong className="text-white font-semibold">{selectedMonth.replace('-', ' ').toUpperCase()}</strong> dönemi verileri hazır. Bu ay toplam <strong className="text-white font-semibold bg-blue-500/30 px-1.5 py-0.5 rounded">{totalOvertime} saat ek mesai</strong> yapıldı, <strong className="text-white font-semibold bg-rose-500/30 px-1.5 py-0.5 rounded">{totalAbsent} gün devamsızlık</strong> kaydedildi.
          </p>
        </div>

        {/* Yan Yana Mini Kartlar (Daha az yer kaplayan, hap tasarım) */}
        <div className="flex flex-wrap gap-3 relative z-10">
          <div className="bg-white/10 border border-white/20 rounded-full px-4 py-2 backdrop-blur-sm flex items-center gap-2">
            <UserCheck className="w-4 h-4 text-emerald-300"/>
            <span className="text-sm font-medium text-white">{perfectStaffCount} Kusursuz</span>
          </div>
          <div className="bg-white/10 border border-white/20 rounded-full px-4 py-2 backdrop-blur-sm flex items-center gap-2">
            <Clock className="w-4 h-4 text-blue-300"/>
            <span className="text-sm font-medium text-white">{totalOvertime}s Mesai</span>
          </div>
          <div className="bg-white/10 border border-white/20 rounded-full px-4 py-2 backdrop-blur-sm flex items-center gap-2">
            <CalendarX2 className="w-4 h-4 text-rose-300"/>
            <span className="text-sm font-medium text-white">{totalAbsent}g Devamsız</span>
          </div>
        </div>
      </div>

      {/* BÖLÜM 1.5: Dönem Seçimi ve Dışa Aktarma (Mavi alanın dışında, ortalı) */}
      <div className="bg-card border rounded-2xl p-6 flex flex-col items-center text-center gap-5 shadow-sm">
        <div className="space-y-1 max-w-md">
          <div className="flex items-center justify-center gap-2">
            <h3 className="font-semibold text-lg">Dönem Seçimi ve Dışa Aktarma</h3>
            <InfoBubble content="Bu raporu muhasebecinize göndermek veya bilgisayarınıza kaydetmek için indirebilirsiniz." />
          </div>
          <p className="text-sm text-muted-foreground">
            İncelemek veya dışa aktarmak istediğiniz puantaj dönemini aşağıdan seçebilirsiniz. Seçtiğiniz döneme ait veriler anında güncellenir.
          </p>
        </div>

        <Select value={selectedMonth} onValueChange={(val) => setSelectedMonth(val || "")}>
          <SelectTrigger className="w-[200px] rounded-full h-10 bg-secondary/50 border-border">
            <SelectValue placeholder="Ay Seçin" />
          </SelectTrigger>
          <SelectContent className="rounded-xl">
            <SelectItem value="mart-2026" className="rounded-lg">Mart 2026</SelectItem>
            <SelectItem value="nisan-2026" className="rounded-lg">Nisan 2026</SelectItem>
            <SelectItem value="mayis-2026" className="rounded-lg">Mayıs 2026</SelectItem>
          </SelectContent>
        </Select>

        <div className="flex flex-wrap justify-center items-center gap-3 pt-2">
          <Button className="bg-emerald-500 hover:bg-emerald-600 text-white shadow-sm gap-2 rounded-full h-10 px-6" onClick={handleWhatsAppShare}>
            <MessageCircle className="w-4 h-4" /> WhatsApp&apos;ta Paylaş
          </Button>
          <Button variant="outline" className="gap-2 rounded-full h-10 px-6" onClick={() => handleExportExcel(false)}>
            <FileSpreadsheet className="w-4 h-4 text-emerald-600 dark:text-emerald-400" /> Excel İndir
          </Button>
          <Button variant="outline" className="gap-2 rounded-full h-10 px-6" onClick={() => handleExportPDF(false)}>
            <Printer className="w-4 h-4 text-rose-600 dark:text-rose-400" /> PDF İndir
          </Button>
        </div>
      </div>

      {/* BÖLÜM 2: Şube Bazlı Akordeon Liste */}
      <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Personel veya Şube ara..."
            className="pl-9 bg-card border-border shadow-sm rounded-full h-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        
        <Button variant="default" className="w-full sm:w-auto gap-2 bg-blue-600 hover:bg-blue-700 text-white shadow-sm rounded-full h-10 px-6" onClick={handleSave}>
          <Save className="h-4 w-4" />
          Verileri Kaydet
        </Button>
      </div>

      <div className="bg-blue-50/50 dark:bg-blue-900/10 border border-blue-100 dark:border-blue-900/30 rounded-xl p-3 flex items-start gap-3 text-blue-800 dark:text-blue-300 text-sm">
        <Info className="h-5 w-5 flex-shrink-0 mt-0.5" />
        <p>
          <strong>İpucu:</strong> Sistem giriş/çıkış saatlerine göre günleri otomatik hesaplar. Muhasebecinize göndermeden önce <strong>Prim</strong>, <strong>Kesinti</strong> veya <strong>Not</strong> alanlarına tıklayarak manuel eklemeler yapabilirsiniz.
        </p>
      </div>

      <div className="space-y-4">
        {groupedData.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground border rounded-xl bg-slate-50/50 dark:bg-slate-900/50">
            Arama kriterlerine uygun kayıt bulunamadı.
          </div>
        ) : groupedData.map((group) => {
          const isExpanded = expandedBranches.includes(group.branch);
          return (
            <div key={group.branch} className="border rounded-xl bg-card overflow-hidden shadow-sm transition-all">
              {/* Şube Başlığı (Akordeon Tetikleyici) */}
              <div 
                className="flex flex-col sm:flex-row sm:items-center justify-between p-4 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors gap-4"
                onClick={() => toggleBranch(group.branch)}
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-primary/10 text-primary rounded-lg">
                    <Building2 className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg">{group.branch}</h3>
                    <p className="text-sm text-muted-foreground">{group.personnel.length} Personel</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-4 sm:gap-6">
                  <div className="hidden sm:flex items-center gap-4 text-sm">
                    <span className="text-blue-600 dark:text-blue-400 font-medium flex items-center gap-1"><Clock className="w-4 h-4"/> {group.totalOvertime}s Mesai</span>
                    <span className="text-rose-600 dark:text-rose-400 font-medium flex items-center gap-1"><CalendarX2 className="w-4 h-4"/> {group.totalAbsent}g Devamsız</span>
                  </div>
                  {isExpanded ? <ChevronUp className="w-5 h-5 text-muted-foreground" /> : <ChevronDown className="w-5 h-5 text-muted-foreground" />}
                </div>
              </div>

              {/* Şube Personel Listesi */}
              {isExpanded && (
                <div className="border-t animate-in slide-in-from-top-2 duration-200">
                  {/* Desktop Table View */}
                  <div className="hidden lg:block overflow-x-auto">
                    <Table>
                      <TableHeader className="bg-slate-50/80 dark:bg-slate-900/80">
                        <TableRow>
                          <TableHead className="font-semibold text-slate-900 dark:text-slate-200">Personel</TableHead>
                          <TableHead>Durum</TableHead>
                          <TableHead className="text-center">Çalışması<br/>Gereken</TableHead>
                          <TableHead className="text-center text-emerald-600">Geldiği<br/>Gün</TableHead>
                          <TableHead className="text-center text-rose-600">Devamsız<br/>Gün</TableHead>
                          <TableHead className="text-center text-amber-600">Geç Kalma<br/>(Dk)</TableHead>
                          <TableHead className="text-center text-blue-600">
                            <div className="flex items-center justify-center gap-1">
                              Ek Mesai<br/>(Saat)
                              <InfoBubble content="Personelin günlük çalışma saatinden daha fazla çalıştığı toplam süredir." className="w-4 h-4" />
                            </div>
                          </TableHead>
                          <TableHead className="w-[120px]">
                            <div className="flex items-center gap-1">
                              Prim (TL)
                              <InfoBubble content="Personele bu ay verilecek ek ödeme tutarı (Örn: Yol, Yemek, Başarı primi)." className="w-4 h-4" />
                            </div>
                          </TableHead>
                          <TableHead className="w-[120px]">
                            <div className="flex items-center gap-1">
                              Kesinti (TL)
                              <InfoBubble content="Maaştan kesilecek tutar (Örn: Avans, Geç kalma cezası)." className="w-4 h-4" />
                            </div>
                          </TableHead>
                          <TableHead className="w-[200px]">
                            <div className="flex items-center gap-1">
                              Muhasebeye Not
                              <InfoBubble content="Muhasebecinizin bilmesi gereken özel durumları buraya yazabilirsiniz." className="w-4 h-4" />
                            </div>
                          </TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {group.personnel.map((row) => (
                          <TableRow key={row.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/50 transition-colors">
                            <TableCell className="font-medium text-base">{row.name}</TableCell>
                            <TableCell>{getStatusBadge(row)}</TableCell>
                            <TableCell className="text-center font-medium">{row.expectedDays}</TableCell>
                            <TableCell className="text-center font-bold text-emerald-600">{row.attendedDays}</TableCell>
                            <TableCell className="text-center font-bold text-rose-600">{row.absentDays > 0 ? row.absentDays : "-"}</TableCell>
                            <TableCell className="text-center font-medium text-amber-600">{row.lateMinutes > 0 ? row.lateMinutes : "-"}</TableCell>
                            <TableCell className="text-center font-bold text-blue-600">{row.overtimeHours > 0 ? row.overtimeHours : "-"}</TableCell>
                            <TableCell>
                              <Input 
                                type="number" 
                                placeholder="0" 
                                className="h-9 text-right bg-slate-50/50 dark:bg-slate-900/50 border-transparent hover:border-slate-200 focus:bg-background focus:border-blue-500 transition-all shadow-none" 
                                value={row.manualBonus}
                                onChange={(e) => handleInputChange(row.id, 'manualBonus', e.target.value)}
                              />
                            </TableCell>
                            <TableCell>
                              <Input 
                                type="number" 
                                placeholder="0" 
                                className="h-9 text-right text-rose-600 bg-slate-50/50 dark:bg-slate-900/50 border-transparent hover:border-slate-200 focus:bg-background focus:border-rose-500 transition-all shadow-none" 
                                value={row.manualDeduction}
                                onChange={(e) => handleInputChange(row.id, 'manualDeduction', e.target.value)}
                              />
                            </TableCell>
                            <TableCell>
                              <Input 
                                type="text" 
                                placeholder="Örn: Avans aldı" 
                                className="h-9 bg-slate-50/50 dark:bg-slate-900/50 border-transparent hover:border-slate-200 focus:bg-background focus:border-blue-500 transition-all shadow-none" 
                                value={row.manualNote}
                                onChange={(e) => handleInputChange(row.id, 'manualNote', e.target.value)}
                              />
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>

                  {/* Mobile Card View */}
                  <div className="grid gap-0 divide-y lg:hidden">
                    {group.personnel.map((row) => (
                      <div 
                        key={row.id} 
                        className="p-4 flex flex-col gap-3 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors cursor-pointer"
                        onClick={() => setSelectedMobileRowId(row.id)}
                      >
                        <div className="flex justify-between items-start">
                          <div className="font-bold text-base">{row.name}</div>
                          {getStatusBadge(row)}
                        </div>
                        <div className="grid grid-cols-3 gap-2 pt-2">
                          <div className="text-center">
                            <div className="text-sm font-bold text-emerald-600">{row.attendedDays} / {row.expectedDays}</div>
                            <div className="text-[10px] text-muted-foreground">Gün Geldi</div>
                          </div>
                          <div className="text-center">
                            <div className="text-sm font-bold text-blue-600">{row.overtimeHours}</div>
                            <div className="text-[10px] text-muted-foreground">Saat Mesai</div>
                          </div>
                          <div className="text-center">
                            <div className="text-sm font-bold text-rose-600">{row.absentDays}</div>
                            <div className="text-[10px] text-muted-foreground">Gün Devamsız</div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Mobile Detail Dialog */}
      <Dialog open={!!selectedMobileRowId} onOpenChange={(open) => !open && setSelectedMobileRowId(null)}>
        <DialogContent className="sm:max-w-[425px] w-[95vw] rounded-xl">
          <DialogHeader>
            <DialogTitle>{selectedMobileRow?.name}</DialogTitle>
            <DialogDescription>{selectedMobileRow?.branch} - Puantaj Detayları</DialogDescription>
          </DialogHeader>
          {selectedMobileRow && (
            <div className="space-y-4 py-2">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="bg-slate-50 dark:bg-slate-900 p-2 rounded-lg flex flex-col items-center justify-center text-center border">
                  <span className="text-muted-foreground text-xs mb-1">Geldiği Gün</span>
                  <span className="font-bold text-emerald-600 text-lg">{selectedMobileRow.attendedDays} / {selectedMobileRow.expectedDays}</span>
                </div>
                <div className="bg-slate-50 dark:bg-slate-900 p-2 rounded-lg flex flex-col items-center justify-center text-center border">
                  <span className="text-muted-foreground text-xs mb-1">Devamsız</span>
                  <span className="font-bold text-rose-600 text-lg">{selectedMobileRow.absentDays}</span>
                </div>
                <div className="bg-slate-50 dark:bg-slate-900 p-2 rounded-lg flex flex-col items-center justify-center text-center border">
                  <span className="text-muted-foreground text-xs mb-1">Geç Kalma</span>
                  <span className="font-bold text-amber-600 text-lg">{selectedMobileRow.lateMinutes} dk</span>
                </div>
                <div className="bg-slate-50 dark:bg-slate-900 p-2 rounded-lg flex flex-col items-center justify-center text-center border">
                  <span className="text-muted-foreground text-xs mb-1">Ek Mesai</span>
                  <span className="font-bold text-blue-600 text-lg">{selectedMobileRow.overtimeHours} saat</span>
                </div>
              </div>

              <div className="space-y-3 pt-2">
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-muted-foreground">Prim (TL)</label>
                    <Input 
                      type="number" 
                      placeholder="0" 
                      className="h-9" 
                      value={selectedMobileRow.manualBonus}
                      onChange={(e) => handleInputChange(selectedMobileRow.id, 'manualBonus', e.target.value)}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-muted-foreground">Kesinti (TL)</label>
                    <Input 
                      type="number" 
                      placeholder="0" 
                      className="h-9 text-rose-600" 
                      value={selectedMobileRow.manualDeduction}
                      onChange={(e) => handleInputChange(selectedMobileRow.id, 'manualDeduction', e.target.value)}
                    />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-muted-foreground">Muhasebeye Not</label>
                  <Input 
                    type="text" 
                    placeholder="Örn: Avans aldı" 
                    className="h-9" 
                    value={selectedMobileRow.manualNote}
                    onChange={(e) => handleInputChange(selectedMobileRow.id, 'manualNote', e.target.value)}
                  />
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
