import { Loader2 } from "lucide-react";

export default function DashboardLoading() {
  return (
    <div className="h-[80vh] w-full flex flex-col items-center justify-center space-y-4">
      <Loader2 className="h-8 w-8 animate-spin text-primary" />
      <p className="text-muted-foreground text-sm font-medium animate-pulse">Sayfa yükleniyor...</p>
    </div>
  );
}
