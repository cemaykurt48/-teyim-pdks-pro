"use client";

import React, { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Clock, UserCheck, Phone, MessageCircle, MonitorSmartphone, Share2, CalendarPlus, ArrowRight, AlertCircle, CheckCircle2, UserX, FileText, Check, X, Search, ChevronDown, ChevronLeft, ChevronRight, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { InfoBubble } from "@/components/info-bubble";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import Link from "next/link";
import PWAInstallButton from "@/components/PWAInstallButton";
import { toast } from "sonner";

// --- MOCK DATA ---
const statsData = {
  present: [
    { id: 1, name: "Ayşe Yılmaz", time: "08:55" },
    { id: 2, name: "Fatma Kaya", time: "08:58" },
    { id: 3, name: "Mustafa Demir", time: "09:00" },
    { id: 10, name: "Ahmet Yılmaz", time: "09:01" },
    { id: 11, name: "Canan Öz", time: "09:02" },
    { id: 12, name: "Burak Yılmaz", time: "09:03" },
    { id: 13, name: "Elif Demir", time: "09:04" },
    { id: 14, name: "Hasan Kaya", time: "09:05" },
    { id: 15, name: "Hüseyin Demir", time: "09:06" },
    { id: 16, name: "Kemal Yılmaz", time: "09:07" },
    { id: 17, name: "Lale Öz", time: "09:08" },
    { id: 18, name: "Murat Kaya", time: "09:09" },
    { id: 19, name: "Nedim Demir", time: "09:10" },
    { id: 20, name: "Orhan Yılmaz", time: "09:11" },
    { id: 21, name: "Pelin Öz", time: "09:12" },
    { id: 22, name: "Rıza Kaya", time: "09:13" },
    { id: 23, name: "Sevgi Demir", time: "09:14" },
    { id: 24, name: "Tarkan Yılmaz", time: "09:14" },
  ],
  late: [
    { id: 4, name: "Mehmet Demir", time: "09:15", note: "15 dk geç" },
    { id: 5, name: "Veli Yılmaz", time: "09:45", note: "45 dk geç" },
    { id: 6, name: "Ayşe Kaya", time: "10:00", note: "1 saat geç" },
  ],
  absent: [
    { id: 7, name: "Canan Öz", note: "Mazeretsiz" },
    { id: 8, name: "Zeynep Kaya", note: "Yıllık İzin" },
    { id: 9, name: "Ali Demir", note: "Raporlu" },
  ]
};

const chronicIssues = [
  { id: 1, user: "Ahmet Yılmaz", issue: "Üst üste 3 gün geç kaldı", phone: "905551234567" },
  { id: 2, user: "Canan Öz", issue: "Bu ay 2. kez mazeretsiz gelmedi", phone: "905559876543" },
];

const pendingLeaves = [
  { id: 1, user: "Burak Yılmaz", type: "Mazeret İzni", date: "Yarın (Yarım Gün)" },
  { id: 2, user: "Elif Demir", type: "Yıllık İzin", date: "12-15 Nisan (3 Gün)" },
];

const fullTimeline = [
  { id: 8, user: "Ali Veli", action: "Çıkış yaptı", time: "12:00", type: "out" },
  { id: 7, user: "Zeynep Kaya", action: "İzinli", time: "09:30", type: "leave", note: "Yıllık İzin" },
  { id: 6, user: "Mehmet Demir", action: "Giriş yaptı", time: "09:15", type: "late", note: "15 dk geç" },
  { id: 5, user: "Mustafa Demir", action: "Giriş yaptı", time: "09:00", type: "in" },
  { id: 4, user: "Fatma Kaya", action: "Giriş yaptı", time: "08:58", type: "in" },
  { id: 3, user: "Ayşe Yılmaz", action: "Giriş yaptı", time: "08:55", type: "in" },
  { id: 2, user: "Sistem", action: "Mesai Başladı", time: "08:30", type: "info" },
  { id: 1, user: "Ahmet Bey", action: "Giriş Ekranı Açıldı", time: "08:15", type: "info" },
];

const allPersonnel = [
  "Ahmet Yılmaz", "Ali Demir", "Ayşe Kaya", "Ayşe Yılmaz", "Burak Yılmaz", "Canan Öz", 
  "Elif Demir", "Fatma Kaya", "Hasan Kaya", "Hüseyin Demir", "Kemal Yılmaz", "Lale Öz", 
  "Mehmet Demir", "Murat Kaya", "Mustafa Demir", "Nedim Demir", "Orhan Yılmaz", "Pelin Öz", 
  "Rıza Kaya", "Sevgi Demir", "Tarkan Yılmaz", "Veli Yılmaz", "Zeynep Kaya"
];

export default function DashboardOverview() {
  const [showAllPresent, setShowAllPresent] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [selectedPerson, setSelectedPerson] = useState("");
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Sayfalama State'i (Timeline için)
  const [currentTimelinePage, setCurrentTimelinePage] = useState(1);
  const TIMELINE_ITEMS_PER_PAGE = 10;

  // Sayfalama Hesaplamaları
  const totalTimelinePages = Math.ceil(fullTimeline.length / TIMELINE_ITEMS_PER_PAGE);
  const startTimelineIndex = (currentTimelinePage - 1) * TIMELINE_ITEMS_PER_PAGE;
  const currentTimelineItems = fullTimeline.slice(startTimelineIndex, startTimelineIndex + TIMELINE_ITEMS_PER_PAGE);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const filteredPersonnel = allPersonnel.filter(p => p.toLowerCase().includes(searchQuery.toLowerCase()));

  const handleShare = () => {
    const text = `*Günlük Özet (İşteyim)*\n\n🟢 *18* Kişi İçeride\n🟡 *3* Kişi Geç Kaldı\n🔴 *3* Kişi Gelmedi/İzinli\n\n*Geç Kalanlar:*\n${statsData.late.map(p => `- ${p.name} (${p.note})`).join('\n')}\n\n*Gelmeyenler:*\n${statsData.absent.map(p => `- ${p.name} (${p.note})`).join('\n')}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
    toast.success("WhatsApp'a yönlendiriliyor...");
  };

  const handleApproveLeave = (id: number) => {
    toast.success("İzin onaylandı.");
  };

  const handleRejectLeave = (id: number) => {
    toast.error("İzin reddedildi.");
  };

  const handleSubmitManualLeave = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("İzin başarıyla sisteme işlendi.");
  };

  return (
    <div className="space-y-8 pb-20 md:pb-0">
      
      {/* BÖLÜM 1: Patron Özeti (Hero Section) */}
      <div className="bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 text-white rounded-2xl p-6 md:p-8 flex flex-col gap-6 shadow-xl relative overflow-hidden">
        {/* Dekoratif Arka Plan Efektleri */}
        <div className="absolute top-0 right-0 -mt-16 -mr-16 w-64 h-64 bg-white opacity-5 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 -mb-16 -ml-16 w-48 h-48 bg-blue-400 opacity-10 rounded-full blur-2xl pointer-events-none"></div>

        <div className="relative z-10">
          <h2 className="text-2xl md:text-3xl font-bold mb-2">İyi Günler Ahmet Bey! 👋</h2>
          <p className="text-blue-100 text-base md:text-lg max-w-2xl">
            Bugün işler genel olarak yolunda. Ancak <strong className="text-white font-semibold">3 kişi geç kaldı</strong> ve <strong className="text-white font-semibold">3 kişi gelmedi</strong>.
          </p>
        </div>
        
        <div className="grid grid-cols-3 gap-3 md:gap-4 relative z-10 mt-2">
          {/* İçeridekiler Modal */}
          <div className="relative">
            <Dialog>
              <DialogTrigger className="flex flex-col bg-white/10 hover:bg-white/20 border border-white/20 transition-colors rounded-xl p-3 md:p-4 text-left cursor-pointer backdrop-blur-sm w-full h-full">
                <div className="flex items-center gap-2 mb-1 md:mb-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]"></div>
                  <span className="text-xs md:text-sm text-blue-100 font-medium pr-5">İçeride</span>
                </div>
                <div className="flex items-end justify-between w-full">
                  <span className="text-3xl md:text-4xl font-bold text-white">18</span>
                  <ArrowRight className="w-4 h-4 text-blue-200 mb-1.5 opacity-70" />
                </div>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2"><UserCheck className="w-5 h-5 text-emerald-500" /> İçerideki Personeller</DialogTitle>
                </DialogHeader>
                <div className="space-y-3 mt-4 max-h-[60vh] overflow-y-auto pr-2">
                  {(showAllPresent ? statsData.present : statsData.present.slice(0, 3)).map(p => (
                    <div key={p.id} className="flex justify-between items-center p-3 bg-slate-50 dark:bg-slate-900 rounded-lg border">
                      <span className="font-medium">{p.name}</span>
                      <Badge variant="outline" className="bg-emerald-50 text-emerald-600 border-emerald-200">{p.time}</Badge>
                    </div>
                  ))}
                  {!showAllPresent && statsData.present.length > 3 && (
                    <button 
                      onClick={() => setShowAllPresent(true)} 
                      className="w-full text-xs text-center text-blue-600 hover:text-blue-700 hover:underline pt-2 pb-1 font-medium"
                    >
                      + {statsData.present.length - 3} kişi daha...
                    </button>
                  )}
                </div>
              </DialogContent>
            </Dialog>
            <div className="absolute top-2 right-2 md:top-3 md:right-3 z-10">
              <InfoBubble content="Şu an ofiste bulunan ve mesaisi devam eden personelleri gösterir." className="w-6 h-6 hover:bg-white/10" iconClassName="text-blue-200 hover:text-white w-4 h-4" />
            </div>
          </div>

          {/* Geç Kalanlar Modal */}
          <div className="relative">
            <Dialog>
              <DialogTrigger className="flex flex-col bg-white/10 hover:bg-white/20 border border-white/20 transition-colors rounded-xl p-3 md:p-4 text-left cursor-pointer backdrop-blur-sm w-full h-full">
                <div className="flex items-center gap-2 mb-1 md:mb-2">
                  <div className="w-2 h-2 rounded-full bg-amber-400 shadow-[0_0_8px_rgba(251,191,36,0.8)]"></div>
                  <span className="text-xs md:text-sm text-blue-100 font-medium pr-5">Geç Kaldı</span>
                </div>
                <div className="flex items-end justify-between w-full">
                  <span className="text-3xl md:text-4xl font-bold text-white">3</span>
                  <ArrowRight className="w-4 h-4 text-blue-200 mb-1.5 opacity-70" />
                </div>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2"><Clock className="w-5 h-5 text-amber-500" /> Geç Kalan Personeller</DialogTitle>
                </DialogHeader>
                <div className="space-y-3 mt-4 max-h-[60vh] overflow-y-auto pr-2">
                  {statsData.late.map(p => (
                    <div key={p.id} className="flex justify-between items-center p-3 bg-slate-50 dark:bg-slate-900 rounded-lg border">
                      <div>
                        <p className="font-medium">{p.name}</p>
                        <p className="text-xs text-amber-600">{p.note}</p>
                      </div>
                      <Badge variant="outline" className="bg-amber-50 text-amber-600 border-amber-200">{p.time}</Badge>
                    </div>
                  ))}
                </div>
              </DialogContent>
            </Dialog>
            <div className="absolute top-2 right-2 md:top-3 md:right-3 z-10">
              <InfoBubble content="Mesai başlangıç saatinden sonra giriş yapan personelleri listeler." className="w-6 h-6 hover:bg-white/10" iconClassName="text-blue-200 hover:text-white w-4 h-4" />
            </div>
          </div>

          {/* Gelmeyenler Modal */}
          <div className="relative">
            <Dialog>
              <DialogTrigger className="flex flex-col bg-white/10 hover:bg-white/20 border border-white/20 transition-colors rounded-xl p-3 md:p-4 text-left cursor-pointer backdrop-blur-sm w-full h-full">
                <div className="flex items-center gap-2 mb-1 md:mb-2">
                  <div className="w-2 h-2 rounded-full bg-rose-400 shadow-[0_0_8px_rgba(251,113,133,0.8)]"></div>
                  <span className="text-xs md:text-sm text-blue-100 font-medium leading-tight pr-5">Gelmedi / İzinli</span>
                </div>
                <div className="flex items-end justify-between w-full">
                  <span className="text-3xl md:text-4xl font-bold text-white">3</span>
                  <ArrowRight className="w-4 h-4 text-blue-200 mb-1.5 opacity-70" />
                </div>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2"><UserX className="w-5 h-5 text-rose-500" /> Gelmeyen Personeller</DialogTitle>
                </DialogHeader>
                <div className="space-y-3 mt-4 max-h-[60vh] overflow-y-auto pr-2">
                  {statsData.absent.map(p => (
                    <div key={p.id} className="flex justify-between items-center p-3 bg-slate-50 dark:bg-slate-900 rounded-lg border">
                      <span className="font-medium">{p.name}</span>
                      <Badge variant="outline" className={p.note === "Mazeretsiz" ? "bg-rose-50 text-rose-600 border-rose-200" : "bg-blue-50 text-blue-600 border-blue-200"}>
                        {p.note}
                      </Badge>
                    </div>
                  ))}
                </div>
              </DialogContent>
            </Dialog>
            <div className="absolute top-2 right-2 md:top-3 md:right-3 z-10">
              <InfoBubble content="Bugün için mazeretli, mazeretsiz veya izinli olarak ofiste bulunmayan personeller." className="w-6 h-6 hover:bg-white/10" iconClassName="text-blue-200 hover:text-white w-4 h-4" />
            </div>
          </div>
        </div>
      </div>

      {/* BÖLÜM 2: Dikkat Gerektirenler (Kronik Sorunlar) */}
      <div>
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          Dikkat Gerektirenler
        </h3>
        {chronicIssues.length === 0 ? (
          <Card className="bg-emerald-50/50 border-emerald-200 dark:bg-emerald-900/10 dark:border-emerald-900/30 shadow-sm">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="p-2 bg-emerald-100 text-emerald-600 rounded-full dark:bg-emerald-900/50 dark:text-emerald-400">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <div>
                <p className="font-semibold text-emerald-800 dark:text-emerald-300">Her şey yolunda!</p>
                <p className="text-sm text-emerald-600 dark:text-emerald-400">Personel devamlılığında süreklilik arz eden bir problem bulunmuyor.</p>
              </div>
            </CardContent>
          </Card>
        ) : (
          <Dialog>
            <DialogTrigger className="w-full text-left">
              <Card className="cursor-pointer hover:bg-amber-50/80 transition-colors border-amber-200 bg-amber-50/30 dark:border-amber-900/30 dark:bg-amber-900/10 shadow-sm">
                <CardContent className="p-4 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-amber-100 text-amber-600 rounded-full dark:bg-amber-900/50 dark:text-amber-400">
                      <AlertCircle className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="font-semibold text-amber-800 dark:text-amber-300">Dikkat Edilmesi Gerekenler Var</p>
                      <p className="text-sm text-amber-600 dark:text-amber-400">{chronicIssues.length} personelin kronik devamlılık sorunu var. Detaylar için tıklayın.</p>
                    </div>
                  </div>
                  <ArrowRight className="w-5 h-5 text-amber-500" />
                </CardContent>
              </Card>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2"><AlertCircle className="w-5 h-5 text-amber-500" /> Kronik Sorunlar</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 mt-4">
                {chronicIssues.map(person => (
                  <div key={person.id} className="p-4 bg-slate-50 dark:bg-slate-900 rounded-lg border flex flex-col gap-3">
                    <div>
                      <p className="font-semibold text-foreground">{person.user}</p>
                      <p className="text-sm text-amber-600 dark:text-amber-400 font-medium mt-0.5">
                        {person.issue}
                      </p>
                    </div>
                    <div className="flex gap-2 w-full">
                      <Button 
                        variant="outline" 
                        className="flex-1 bg-emerald-50 text-emerald-600 border-emerald-200 hover:bg-emerald-100 hover:text-emerald-700 dark:bg-emerald-900/30 dark:border-emerald-800 dark:text-emerald-400" 
                        onClick={() => window.open(`https://wa.me/${person.phone}`, '_blank')}
                      >
                        <MessageCircle className="w-4 h-4 mr-2" /> WhatsApp
                      </Button>
                      <Button 
                        variant="outline" 
                        className="flex-1 bg-blue-50 text-blue-600 border-blue-200 hover:bg-blue-100 hover:text-blue-700 dark:bg-blue-900/30 dark:border-blue-800 dark:text-blue-400" 
                        onClick={() => window.open(`tel:+${person.phone}`, '_self')}
                      >
                        <Phone className="w-4 h-4 mr-2" /> Ara
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* BÖLÜM 3: Gerçek "Günlük" Hızlı İşlemler */}
      <div>
        <h3 className="text-lg font-semibold mb-4">Günlük İşlemler</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Link href="/kiosk/branch-1" className="block">
            <Card className="hover:border-primary/50 transition-all cursor-pointer h-full shadow-sm">
              <CardContent className="p-4 flex items-center gap-4">
                <div className="p-3 bg-indigo-100 text-indigo-600 rounded-xl dark:bg-indigo-900/50 dark:text-indigo-400">
                  <MonitorSmartphone className="w-6 h-6" />
                </div>
                <div>
                  <p className="font-semibold">Giriş Ekranını Aç</p>
                  <p className="text-xs text-muted-foreground mt-0.5">Tableti hazırla</p>
                </div>
              </CardContent>
            </Card>
          </Link>
          
          <button onClick={handleShare} className="block text-left w-full">
            <Card className="hover:border-primary/50 transition-all cursor-pointer h-full shadow-sm">
              <CardContent className="p-4 flex items-center gap-4">
                <div className="p-3 bg-emerald-100 text-emerald-600 rounded-xl dark:bg-emerald-900/50 dark:text-emerald-400">
                  <Share2 className="w-6 h-6" />
                </div>
                <div>
                  <p className="font-semibold">Günlük Özeti Paylaş</p>
                  <p className="text-xs text-muted-foreground mt-0.5">WhatsApp ile gönder</p>
                </div>
              </CardContent>
            </Card>
          </button>

          {/* Hızlı İzin Gir Modal */}
          <Dialog>
            <DialogTrigger className="block text-left w-full relative cursor-pointer">
              <Card className="hover:border-primary/50 transition-all h-full shadow-sm">
                <CardContent className="p-4 flex items-center gap-4">
                  <div className="p-3 bg-amber-100 text-amber-600 rounded-xl dark:bg-amber-900/50 dark:text-amber-400">
                    <CalendarPlus className="w-6 h-6" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <p className="font-semibold">Hızlı İzin Gir</p>
                    </div>
                    <div className="flex items-center gap-2 mt-0.5">
                      <p className="text-xs text-muted-foreground">Manuel ekle</p>
                      {pendingLeaves.length > 0 && (
                        <Badge variant="destructive" className="text-[10px] px-1.5 py-0 h-4 leading-none">
                          {pendingLeaves.length} Onay Bekliyor
                        </Badge>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>İzin İşlemleri</DialogTitle>
              </DialogHeader>
              <Tabs defaultValue="new" className="mt-4">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="new">Manuel İzin Ekle</TabsTrigger>
                  <TabsTrigger value="pending" className="relative">
                    Onay Bekleyenler
                    {pendingLeaves.length > 0 && (
                      <Badge variant="destructive" className="ml-2 h-5 w-5 p-0 flex items-center justify-center rounded-full text-[10px]">
                        {pendingLeaves.length}
                      </Badge>
                    )}
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="new" className="space-y-4 py-4">
                  <form onSubmit={handleSubmitManualLeave} className="space-y-4">
                    <div className="space-y-2 relative" ref={dropdownRef}>
                      <Label>Personel Seçin</Label>
                      <div 
                        className="flex h-10 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-900 transition-colors"
                        onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                      >
                        <span className={selectedPerson ? "text-foreground" : "text-muted-foreground"}>
                          {selectedPerson || "Personel ara veya seçin..."}
                        </span>
                        <ChevronDown className="w-4 h-4 opacity-50" />
                      </div>
                      
                      {isDropdownOpen && (
                        <div className="absolute z-50 w-full mt-1 bg-background border rounded-md shadow-lg overflow-hidden">
                          <div className="flex items-center border-b px-3 py-2 bg-slate-50 dark:bg-slate-900/50">
                            <Search className="w-4 h-4 text-muted-foreground mr-2" />
                            <input 
                              type="text" 
                              className="flex-1 bg-transparent outline-none text-sm" 
                              placeholder="İsim yazarak arayın..." 
                              value={searchQuery}
                              onChange={(e) => setSearchQuery(e.target.value)}
                              autoFocus
                            />
                          </div>
                          <div className="max-h-[180px] overflow-y-auto py-1">
                            {filteredPersonnel.length === 0 ? (
                              <div className="px-3 py-4 text-sm text-muted-foreground text-center">Sonuç bulunamadı</div>
                            ) : (
                              filteredPersonnel.map((person, idx) => (
                                <div 
                                  key={idx} 
                                  className={`px-3 py-2 text-sm cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-between ${selectedPerson === person ? 'bg-primary/5 font-medium text-primary' : ''}`}
                                  onClick={() => {
                                    setSelectedPerson(person);
                                    setIsDropdownOpen(false);
                                    setSearchQuery("");
                                  }}
                                >
                                  {person}
                                  {selectedPerson === person && <Check className="w-4 h-4" />}
                                </div>
                              ))
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                    <div className="space-y-2">
                      <Label>İzin Türü</Label>
                      <select className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2">
                        <option value="mazeret">Mazeret İzni</option>
                        <option value="yillik">Yıllık İzin</option>
                        <option value="rapor">Sağlık Raporu</option>
                      </select>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Başlangıç</Label>
                        <Input type="date" />
                      </div>
                      <div className="space-y-2">
                        <Label>Bitiş</Label>
                        <Input type="date" />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label>Açıklama / Not</Label>
                      <textarea 
                        className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2" 
                        placeholder="İzin nedeni veya eklemek istediğiniz notlar..."
                      ></textarea>
                    </div>
                    <Button type="submit" className="w-full">İzni Sisteme İşle</Button>
                  </form>
                </TabsContent>
                
                <TabsContent value="pending" className="space-y-4 py-4">
                  {pendingLeaves.length === 0 ? (
                    <p className="text-center text-muted-foreground py-8">Onay bekleyen izin talebi yok.</p>
                  ) : (
                    <div className="space-y-3">
                      {pendingLeaves.map(leave => (
                        <div key={leave.id} className="p-3 bg-slate-50 dark:bg-slate-900 rounded-lg border flex flex-col gap-3">
                          <div className="flex justify-between items-start">
                            <div>
                              <p className="font-semibold">{leave.user}</p>
                              <p className="text-sm text-muted-foreground">{leave.type} • {leave.date}</p>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline" className="flex-1 bg-emerald-50 text-emerald-600 border-emerald-200 hover:bg-emerald-100" onClick={() => handleApproveLeave(leave.id)}>
                              <Check className="w-4 h-4 mr-1" /> Onayla
                            </Button>
                            <Button size="sm" variant="outline" className="flex-1 bg-rose-50 text-rose-600 border-rose-200 hover:bg-rose-100" onClick={() => handleRejectLeave(leave.id)}>
                              <X className="w-4 h-4 mr-1" /> Reddet
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* BÖLÜM 4: Canlı Akış */}
      <Card className="shadow-sm">
        <CardHeader>
          <CardTitle className="text-lg">Bugünün Akışı</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {fullTimeline.slice(0, 5).map((item, i) => (
              <div key={i} className="flex gap-4 relative">
                {i !== 4 && (
                  <div className="absolute left-[11px] top-6 bottom-[-24px] w-[2px] bg-slate-100 dark:bg-slate-800"></div>
                )}
                <div className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 z-10 ${
                  item.type === 'in' ? 'bg-emerald-100 text-emerald-600 dark:bg-emerald-900/50 dark:text-emerald-400' :
                  item.type === 'late' ? 'bg-amber-100 text-amber-600 dark:bg-amber-900/50 dark:text-amber-400' :
                  item.type === 'leave' ? 'bg-blue-100 text-blue-600 dark:bg-blue-900/50 dark:text-blue-400' :
                  'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                }`}>
                  {item.type === 'in' ? <UserCheck className="w-3 h-3" /> :
                   item.type === 'late' ? <Clock className="w-3 h-3" /> :
                   item.type === 'leave' ? <CalendarPlus className="w-3 h-3" /> :
                   <ArrowRight className="w-3 h-3" />}
                </div>
                <div className="flex-1 pb-2">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium">{item.user}</p>
                    <span className="text-xs text-muted-foreground">{item.time}</span>
                  </div>
                  <p className="text-sm text-muted-foreground mt-0.5">
                    {item.action} {item.note && <span className="text-xs ml-1 opacity-70">({item.note})</span>}
                  </p>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 flex justify-center">
            <Dialog>
              <DialogTrigger className="text-sm font-medium text-muted-foreground hover:text-foreground px-4 py-2 rounded-md hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
                Tüm Akışı Detaylı Gör
              </DialogTrigger>
              <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                  <DialogTitle>Bugünün Tüm Akışı</DialogTitle>
                </DialogHeader>
                <div className="space-y-6 mt-4 max-h-[60vh] overflow-y-auto pr-4">
                  {currentTimelineItems.map((item, i) => (
                    <div key={i} className="flex gap-4 relative">
                      {i !== currentTimelineItems.length - 1 && (
                        <div className="absolute left-[11px] top-6 bottom-[-24px] w-[2px] bg-slate-100 dark:bg-slate-800"></div>
                      )}
                      <div className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 z-10 ${
                        item.type === 'in' ? 'bg-emerald-100 text-emerald-600 dark:bg-emerald-900/50 dark:text-emerald-400' :
                        item.type === 'late' ? 'bg-amber-100 text-amber-600 dark:bg-amber-900/50 dark:text-amber-400' :
                        item.type === 'leave' ? 'bg-blue-100 text-blue-600 dark:bg-blue-900/50 dark:text-blue-400' :
                        'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                      }`}>
                        {item.type === 'in' ? <UserCheck className="w-3 h-3" /> :
                         item.type === 'late' ? <Clock className="w-3 h-3" /> :
                         item.type === 'leave' ? <CalendarPlus className="w-3 h-3" /> :
                         <ArrowRight className="w-3 h-3" />}
                      </div>
                      <div className="flex-1 pb-2">
                        <div className="flex items-center justify-between">
                          <p className="text-sm font-medium">{item.user}</p>
                          <span className="text-xs text-muted-foreground">{item.time}</span>
                        </div>
                        <p className="text-sm text-muted-foreground mt-0.5">
                          {item.action} {item.note && <span className="text-xs ml-1 opacity-70">({item.note})</span>}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Sayfalama Kontrolleri */}
                {totalTimelinePages > 1 && (
                  <div className="flex items-center justify-center gap-2 mt-4 pt-4 border-t">
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => setCurrentTimelinePage(p => Math.max(1, p - 1))}
                      disabled={currentTimelinePage === 1}
                      className="w-9 h-9"
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </Button>
                    
                    {Array.from({ length: totalTimelinePages }).map((_, i) => {
                      const page = i + 1;
                      return (
                        <Button
                          key={page}
                          variant={currentTimelinePage === page ? "default" : "outline"}
                          className={`w-9 h-9 p-0 ${currentTimelinePage === page ? 'bg-primary text-primary-foreground' : ''}`}
                          onClick={() => setCurrentTimelinePage(page)}
                        >
                          {page}
                        </Button>
                      );
                    })}

                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => setCurrentTimelinePage(p => Math.min(totalTimelinePages, p + 1))}
                      disabled={currentTimelinePage === totalTimelinePages}
                      className="w-9 h-9"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </div>
                )}
              </DialogContent>
            </Dialog>
          </div>
        </CardContent>
      </Card>
      
      <PWAInstallButton />
    </div>
  );
}
