"use client";

import { useState } from "react";
import { Plus, MapPin, Clock, MoreHorizontal, QrCode, Trash2, Edit2, Navigation, CheckCircle2, MonitorSmartphone, Link as LinkIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { AlertCircle, Building2, HelpCircle } from "lucide-react";
import { InfoBubble } from "@/components/info-bubble";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { useRouter } from "next/navigation";

interface Branch {
  id: number;
  name: string;
  address: string;
  staffCount: number;
  workStart: string;
  workEnd: string;
  tolerance: number;
  latitude: number | null;
  longitude: number | null;
  radius: number;
}

const initialBranches: Branch[] = [
  { id: 1, name: "Merkez Şube", address: "Kadıköy, İstanbul", staffCount: 15, workStart: "09:00", workEnd: "18:00", tolerance: 15, latitude: 40.9901, longitude: 29.0235, radius: 100 },
  { id: 2, name: "Beşiktaş Şube", address: "Beşiktaş, İstanbul", staffCount: 9, workStart: "08:30", workEnd: "17:30", tolerance: 10, latitude: 41.0422, longitude: 29.0075, radius: 50 },
];

export default function BranchesPage() {
  const router = useRouter();
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isQrOpen, setIsQrOpen] = useState(false);
  const [selectedBranch, setSelectedBranch] = useState<Branch | null>(null);
  const [branches, setBranches] = useState<Branch[]>(initialBranches);
  const [isLocating, setIsLocating] = useState(false);
  const [formLat, setFormLat] = useState<number | null>(null);
  const [formLng, setFormLng] = useState<number | null>(null);
  const [selectedMobileBranchId, setSelectedMobileBranchId] = useState<number | null>(null);
  const [branchToDelete, setBranchToDelete] = useState<number | null>(null);

  const selectedMobileBranch = branches.find(b => b.id === selectedMobileBranchId);

  const handleAddBranch = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const newBranch: Branch = {
      id: Math.max(0, ...branches.map(b => b.id)) + 1,
      name: formData.get("name") as string,
      address: formData.get("address") as string,
      staffCount: 0,
      workStart: formData.get("start") as string,
      workEnd: formData.get("end") as string,
      tolerance: Number(formData.get("tolerance")),
      latitude: formData.get("latitude") ? Number(formData.get("latitude")) : null,
      longitude: formData.get("longitude") ? Number(formData.get("longitude")) : null,
      radius: Number(formData.get("radius")) || 100,
    };
    setBranches([...branches, newBranch]);
    setIsAddOpen(false);
    toast.success("Şube başarıyla eklendi.");
  };

  const handleEditBranch = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!selectedBranch) return;
    const formData = new FormData(e.currentTarget);
    const updatedBranch: Branch = {
      ...selectedBranch,
      name: formData.get("name") as string,
      address: formData.get("address") as string,
      workStart: formData.get("start") as string,
      workEnd: formData.get("end") as string,
      tolerance: Number(formData.get("tolerance")),
      latitude: formData.get("latitude") ? Number(formData.get("latitude")) : null,
      longitude: formData.get("longitude") ? Number(formData.get("longitude")) : null,
      radius: Number(formData.get("radius")) || 100,
    };
    setBranches(branches.map(b => b.id === selectedBranch.id ? updatedBranch : b));
    setIsEditOpen(false);
    setSelectedBranch(null);
    toast.success("Şube bilgileri güncellendi.");
  };

  const handleDeleteBranch = () => {
    if (branchToDelete !== null) {
      setBranches(branches.filter(b => b.id !== branchToDelete));
      toast.success("Şube silindi.");
      setBranchToDelete(null);
    }
  };

  const getCurrentLocation = () => {
    setIsLocating(true);
    if (!navigator.geolocation) {
      alert("Tarayıcınız konum servisini desteklemiyor.");
      setIsLocating(false);
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setFormLat(position.coords.latitude);
        setFormLng(position.coords.longitude);
        setIsLocating(false);
      },
      (error) => {
        alert("Konum alınamadı: " + error.message);
        setIsLocating(false);
      }
    );
  };

  const copyKioskLink = (branchId: number) => {
    const url = `${window.location.origin}/kiosk/${branchId}`;
    navigator.clipboard.writeText(url);
    toast.success("Tablet modu linki kopyalandı!");
  };

  return (
    <div className="space-y-6">
      {/* Boss Mode Hero Section */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-blue-900 via-blue-800 to-blue-900 p-6 sm:p-8 text-white shadow-lg">
        <div className="absolute top-0 right-0 -mt-4 -mr-4 w-32 h-32 bg-white/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 -mb-4 -ml-4 w-24 h-24 bg-blue-500/20 rounded-full blur-2xl"></div>
        
        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight">Şubeler</h2>
              <InfoBubble content="Şirketinizin farklı ofis, mağaza veya şantiyelerini buradan ekleyebilirsiniz. Personeller sadece atandıkları şubede giriş-çıkış yapabilir." className="w-6 h-6 hover:bg-white/10" iconClassName="text-blue-200 hover:text-white" />
            </div>
            <p className="text-blue-100/80 text-sm sm:text-base max-w-md">
              İşletmenize ait şubeleri ve mesai kurallarını yönetin.
            </p>
          </div>
          
          <div className="flex items-center gap-4 sm:gap-6 bg-white/10 p-4 rounded-2xl backdrop-blur-sm border border-white/10">
            <div className="flex flex-col">
              <span className="text-blue-200 text-xs font-medium uppercase tracking-wider mb-1">Toplam Şube</span>
              <span className="text-2xl font-bold">{branches.length}</span>
            </div>
            <div className="w-px h-10 bg-white/20"></div>
            <div className="flex flex-col">
              <span className="text-blue-200 text-xs font-medium uppercase tracking-wider mb-1">Toplam Kapasite</span>
              <span className="text-2xl font-bold">{branches.reduce((acc, b) => acc + b.staffCount, 0)}</span>
            </div>
          </div>
        </div>

        <div className="relative z-10 mt-6 flex justify-end">
          <Button className="gap-2 rounded-xl bg-white text-blue-900 hover:bg-blue-50 hover:text-blue-950 font-semibold shadow-sm" onClick={() => { setIsAddOpen(true); setFormLat(null); setFormLng(null); }}>
            <Plus className="h-4 w-4" />
            Yeni Şube Ekle
          </Button>
          <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
          <DialogContent className="sm:max-w-[425px] rounded-2xl">
            <DialogHeader>
              <DialogTitle className="text-xl">Yeni Şube Ekle</DialogTitle>
              <DialogDescription>
                Şube bilgilerini ve varsayılan mesai kurallarını belirleyin.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleAddBranch}>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Şube Adı</Label>
                  <Input id="name" name="name" placeholder="Örn: Merkez Şube" className="h-10 rounded-xl" required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="address">Açık Adres</Label>
                  <Input id="address" name="address" placeholder="Mahalle, Sokak, İlçe, İl" className="h-10 rounded-xl" required />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="start">Mesai Başlangıç</Label>
                    <Input id="start" name="start" type="time" defaultValue="09:00" className="h-10 rounded-xl" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="end">Mesai Bitiş</Label>
                    <Input id="end" name="end" type="time" defaultValue="18:00" className="h-10 rounded-xl" required />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="tolerance" className="flex items-center gap-1">
                      Tolerans (Dakika)
                      <Tooltip>
                        <TooltipTrigger>
                          <HelpCircle className="h-4 w-4 text-muted-foreground cursor-help" />
                        </TooltipTrigger>
                        <TooltipContent className="rounded-xl">
                          <p className="w-[200px]">Personelin mesaiye kaç dakika geç kalmasının sorun edilmeyeceğini belirler.</p>
                        </TooltipContent>
                      </Tooltip>
                    </Label>
                    <Input id="tolerance" name="tolerance" type="number" defaultValue="15" className="h-10 rounded-xl" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="radius" className="flex items-center gap-1">
                      Yarıçap (Metre)
                      <Tooltip>
                        <TooltipTrigger>
                          <HelpCircle className="h-4 w-4 text-muted-foreground cursor-help" />
                        </TooltipTrigger>
                        <TooltipContent className="rounded-xl">
                          <p className="w-[200px]">Personelin QR okutabilmesi için şubeye en fazla kaç metre uzakta olabileceğini belirler.</p>
                        </TooltipContent>
                      </Tooltip>
                    </Label>
                    <Input id="radius" name="radius" type="number" defaultValue="100" className="h-10 rounded-xl" required />
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Label>GPS Koordinatları</Label>
                    <InfoBubble content="Personelin sadece iş yerindeyken veya iş yerinin internetine bağlıyken giriş-çıkış yapabilmesini sağlayan güvenlik ayarıdır." />
                  </div>
                  <div className="flex flex-col gap-2">
                    {formLat && formLng ? (
                      <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-xl flex items-center justify-between border border-blue-100 dark:border-blue-800">
                        <span className="text-sm font-medium text-blue-700 dark:text-blue-300">
                          {formLat.toFixed(6)}, {formLng.toFixed(6)}
                        </span>
                        <Button type="button" variant="ghost" size="sm" className="h-8 rounded-lg text-blue-600 hover:text-blue-700 hover:bg-blue-100" onClick={() => { setFormLat(null); setFormLng(null); }}>
                          Temizle
                        </Button>
                      </div>
                    ) : (
                      <div className="p-3 bg-secondary/50 border border-dashed rounded-xl flex items-center justify-center text-sm text-muted-foreground">
                        Konum ayarlanmadı
                      </div>
                    )}
                    <Button type="button" variant="outline" className="w-full gap-2 rounded-xl h-10" onClick={getCurrentLocation} disabled={isLocating}>
                      <MapPin className={cn("h-4 w-4", isLocating && "animate-bounce")} />
                      {isLocating ? "Konum Bulunuyor..." : "Mevcut Konumu Al"}
                    </Button>
                    <input type="hidden" name="latitude" value={formLat || ""} />
                    <input type="hidden" name="longitude" value={formLng || ""} />
                  </div>
                  <p className="text-[10px] text-muted-foreground">Boş bırakılırsa konum doğrulaması yapılmaz.</p>
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" className="rounded-xl h-10" onClick={() => setIsAddOpen(false)}>İptal</Button>
                <Button type="submit" className="rounded-xl h-10 px-8 bg-blue-600 hover:bg-blue-700">Kaydet</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
        </div>
      </div>

      {/* Mobile Card View */}
      <div className="grid gap-3 md:hidden">
        {branches.length === 0 ? (
          <div className="text-center py-12 px-4 border-2 border-dashed rounded-2xl bg-muted/30">
            <div className="bg-blue-100 dark:bg-blue-900/30 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
              <Building2 className="h-6 w-6 text-blue-600 dark:text-blue-400" />
            </div>
            <h3 className="text-lg font-semibold mb-1">Şube Bulunamadı</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Sistemde henüz kayıtlı şube yok.
            </p>
            <Button onClick={() => setIsAddOpen(true)} className="rounded-xl bg-blue-600 hover:bg-blue-700">
              <Plus className="h-4 w-4 mr-2" /> İlk Şubeyi Ekle
            </Button>
          </div>
        ) : branches.map((branch) => (
          <div 
            key={branch.id} 
            className="border rounded-xl bg-card p-4 flex flex-col gap-3 shadow-sm cursor-pointer hover:border-blue-500/40 hover:bg-blue-50/50 dark:hover:bg-blue-900/10 active:scale-[0.98] transition-all duration-200"
            onClick={() => setSelectedMobileBranchId(branch.id)}
          >
            <div className="flex justify-between items-start gap-2">
              <div className="flex flex-col min-w-0">
                <span className="font-bold text-base truncate">{branch.name}</span>
                <div className="flex items-center gap-1 text-xs text-muted-foreground mt-1">
                  <MapPin className="h-3 w-3 flex-shrink-0" />
                  <span className="truncate">{branch.address}</span>
                </div>
              </div>
              <div className="bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 text-xs font-bold px-2.5 py-1 rounded-lg whitespace-nowrap">
                {branch.staffCount} Personel
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Desktop Grid View */}
      <div className="hidden md:grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {branches.length === 0 ? (
          <div className="col-span-full text-center py-16 border-2 border-dashed rounded-2xl bg-muted/30">
            <div className="bg-blue-100 dark:bg-blue-900/30 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <Building2 className="h-8 w-8 text-blue-600 dark:text-blue-400" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Şube Bulunamadı</h3>
            <p className="text-muted-foreground mb-6 max-w-md mx-auto">
              Sistemde henüz kayıtlı şube yok. Personellerinizin giriş yapabilmesi için en az bir şube eklemelisiniz.
            </p>
            <Button onClick={() => setIsAddOpen(true)} className="rounded-xl bg-blue-600 hover:bg-blue-700">
              <Plus className="h-4 w-4 mr-2" /> İlk Şubeyi Ekle
            </Button>
          </div>
        ) : branches.map((branch) => (
          <Card key={branch.id} className="relative overflow-hidden rounded-2xl shadow-sm hover:shadow-md transition-all duration-200 border-border/50 hover:border-blue-500/30 group">
            <div className="absolute top-0 left-0 w-1 h-full bg-blue-500 opacity-0 group-hover:opacity-100 transition-opacity"></div>
            <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-4">
              <div className="min-w-0 flex-1 pr-4">
                <CardTitle className="text-xl truncate font-bold">{branch.name}</CardTitle>
                <CardDescription className="flex items-center gap-1.5 mt-1.5 truncate text-xs">
                  <MapPin className="h-3.5 w-3.5 flex-shrink-0" />
                  {branch.address}
                </CardDescription>
              </div>
              <DropdownMenu>
                <DropdownMenuTrigger
                  render={
                    <Button variant="ghost" size="icon" className="-mr-2 rounded-lg opacity-50 group-hover:opacity-100 transition-opacity">
                      <MoreHorizontal className="h-4 w-4" />
                      <span className="sr-only">Menüyü aç</span>
                    </Button>
                  }
                />
                <DropdownMenuContent align="end" className="rounded-xl">
                  <DropdownMenuItem onClick={() => { 
                    setSelectedBranch(branch); 
                    setFormLat(branch.latitude);
                    setFormLng(branch.longitude);
                    setIsEditOpen(true); 
                  }} className="rounded-lg cursor-pointer">
                    <Edit2 className="h-4 w-4 mr-2" /> Düzenle
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => { setSelectedBranch(branch); setIsQrOpen(true); }} className="rounded-lg cursor-pointer">
                    <QrCode className="h-4 w-4 mr-2" /> QR Kod Oluştur
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => router.push(`/kiosk/${branch.id}`)} className="rounded-lg cursor-pointer">
                    <MonitorSmartphone className="h-4 w-4 mr-2" /> Tablet Modunu Aç
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => copyKioskLink(branch.id)} className="rounded-lg cursor-pointer">
                    <LinkIcon className="h-4 w-4 mr-2" /> Tablet Linkini Kopyala
                  </DropdownMenuItem>
                  <DropdownMenuItem className="text-destructive rounded-lg cursor-pointer" onClick={() => setBranchToDelete(branch.id)}>
                    <Trash2 className="h-4 w-4 mr-2" /> Sil
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </CardHeader>
            <CardContent className="pt-0 pb-6">
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-secondary/40 p-3 rounded-xl flex flex-col items-center justify-center text-center">
                    <span className="text-2xl font-bold text-foreground">{branch.staffCount}</span>
                    <span className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold mt-1">Personel</span>
                  </div>
                  <div className="bg-secondary/40 p-3 rounded-xl flex flex-col items-center justify-center text-center">
                    <span className="text-sm font-bold text-foreground flex items-center gap-1">
                      {branch.workStart} - {branch.workEnd}
                    </span>
                    <span className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold mt-1 flex items-center gap-1">
                      <Clock className="h-3 w-3" /> Mesai
                    </span>
                  </div>
                </div>
                
                <div className="space-y-2.5 pt-2 border-t border-border/50">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Tolerans Süresi</span>
                    <span className="font-semibold text-amber-600 bg-amber-50 dark:bg-amber-900/20 px-2 py-0.5 rounded-md">{branch.tolerance} dk</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">GPS Doğrulama</span>
                    {branch.latitude ? (
                      <span className="font-semibold text-emerald-600 bg-emerald-50 dark:bg-emerald-900/20 px-2 py-0.5 rounded-md flex items-center gap-1">
                        <CheckCircle2 className="h-3.5 w-3.5" />
                        {branch.radius}m Aktif
                      </span>
                    ) : (
                      <span className="font-medium text-muted-foreground bg-secondary/50 px-2 py-0.5 rounded-md">
                        Pasif
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Edit Dialog */}
      <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
        <DialogContent className="sm:max-w-[425px] rounded-2xl">
          <DialogHeader>
            <DialogTitle className="text-xl">Şubeyi Düzenle</DialogTitle>
            <DialogDescription>
              Şube bilgilerini ve mesai kurallarını güncelleyin.
            </DialogDescription>
          </DialogHeader>
          {selectedBranch && (
            <form onSubmit={handleEditBranch}>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-name">Şube Adı</Label>
                  <Input id="edit-name" name="name" defaultValue={selectedBranch.name} className="h-10 rounded-xl" required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-address">Açık Adres</Label>
                  <Input id="edit-address" name="address" defaultValue={selectedBranch.address} className="h-10 rounded-xl" required />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="edit-start">Mesai Başlangıç</Label>
                    <Input id="edit-start" name="start" type="time" defaultValue={selectedBranch.workStart} className="h-10 rounded-xl" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit-end">Mesai Bitiş</Label>
                    <Input id="edit-end" name="end" type="time" defaultValue={selectedBranch.workEnd} className="h-10 rounded-xl" required />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="edit-tolerance" className="flex items-center gap-1">
                      Tolerans (Dakika)
                      <Tooltip>
                        <TooltipTrigger>
                          <HelpCircle className="h-4 w-4 text-muted-foreground cursor-help" />
                        </TooltipTrigger>
                        <TooltipContent className="rounded-xl">
                          <p className="w-[200px]">Personelin mesaiye kaç dakika geç kalmasının sorun edilmeyeceğini belirler.</p>
                        </TooltipContent>
                      </Tooltip>
                    </Label>
                    <Input id="edit-tolerance" name="tolerance" type="number" defaultValue={selectedBranch.tolerance} className="h-10 rounded-xl" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit-radius" className="flex items-center gap-1">
                      Yarıçap (Metre)
                      <Tooltip>
                        <TooltipTrigger>
                          <HelpCircle className="h-4 w-4 text-muted-foreground cursor-help" />
                        </TooltipTrigger>
                        <TooltipContent className="rounded-xl">
                          <p className="w-[200px]">Personelin QR okutabilmesi için şubeye en fazla kaç metre uzakta olabileceğini belirler.</p>
                        </TooltipContent>
                      </Tooltip>
                    </Label>
                    <Input id="edit-radius" name="radius" type="number" defaultValue={selectedBranch.radius} className="h-10 rounded-xl" required />
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Label>GPS Koordinatları</Label>
                    <InfoBubble content="Personelin sadece iş yerindeyken veya iş yerinin internetine bağlıyken giriş-çıkış yapabilmesini sağlayan güvenlik ayarıdır." />
                  </div>
                  <div className="flex flex-col gap-2">
                    {formLat && formLng ? (
                      <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-xl flex items-center justify-between border border-blue-100 dark:border-blue-800">
                        <span className="text-sm font-medium text-blue-700 dark:text-blue-300">
                          {formLat.toFixed(6)}, {formLng.toFixed(6)}
                        </span>
                        <Button type="button" variant="ghost" size="sm" className="h-8 rounded-lg text-blue-600 hover:text-blue-700 hover:bg-blue-100" onClick={() => { setFormLat(null); setFormLng(null); }}>
                          Temizle
                        </Button>
                      </div>
                    ) : (
                      <div className="p-3 bg-secondary/50 border border-dashed rounded-xl flex items-center justify-center text-sm text-muted-foreground">
                        Konum ayarlanmadı
                      </div>
                    )}
                    <Button type="button" variant="outline" className="w-full gap-2 rounded-xl h-10" onClick={getCurrentLocation} disabled={isLocating}>
                      <MapPin className={cn("h-4 w-4", isLocating && "animate-bounce")} />
                      {isLocating ? "Konum Bulunuyor..." : "Mevcut Konumu Al"}
                    </Button>
                    <input type="hidden" name="latitude" value={formLat || ""} />
                    <input type="hidden" name="longitude" value={formLng || ""} />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" className="rounded-xl h-10" onClick={() => setIsEditOpen(false)}>İptal</Button>
                <Button type="submit" className="rounded-xl h-10 px-8 bg-blue-600 hover:bg-blue-700">Güncelle</Button>
              </DialogFooter>
            </form>
          )}
        </DialogContent>
      </Dialog>

      {/* QR Dialog */}
      <Dialog open={isQrOpen} onOpenChange={setIsQrOpen}>
        <DialogContent className="sm:max-w-[350px] rounded-2xl">
          <DialogHeader>
            <DialogTitle className="text-xl">QR Kod</DialogTitle>
            <DialogDescription>
              {selectedBranch?.name} için giriş kodu.
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col items-center justify-center p-6 space-y-4">
            <div className="w-48 h-48 bg-white border-8 border-slate-100 rounded-2xl flex items-center justify-center p-2 shadow-inner">
              {/* Simulated QR Code */}
              <div className="w-full h-full bg-slate-900 rounded-lg flex flex-wrap p-1 gap-1 opacity-90 overflow-hidden relative">
                {Array.from({ length: 64 }).map((_, i) => (
                  <div key={i} className={cn("w-[10%] h-[10%] bg-white", (i % 3 === 0 || i % 7 === 0) ? "opacity-100" : "opacity-0")} />
                ))}
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <div className="bg-white p-2 rounded-lg shadow-lg">
                    <QrCode className="h-8 w-8 text-blue-600" />
                  </div>
                </div>
              </div>
            </div>
            <p className="text-xs text-center text-muted-foreground">
              Bu kodu çıktı alıp şubenize asabilirsiniz. Personel bu kodu okutarak mesaiye başlar.
            </p>
            <Button className="w-full gap-2 rounded-xl h-10 bg-blue-600 hover:bg-blue-700 text-white">
              <Plus className="h-4 w-4" /> Yazdır / İndir
            </Button>
          </div>
        </DialogContent>
      </Dialog>
      {/* Mobile Detail Dialog */}
      <Dialog open={!!selectedMobileBranchId} onOpenChange={(open) => !open && setSelectedMobileBranchId(null)}>
        <DialogContent className="sm:max-w-[425px] w-[95vw] rounded-2xl">
          <DialogHeader>
            <DialogTitle className="text-xl">{selectedMobileBranch?.name}</DialogTitle>
            <DialogDescription className="flex items-center gap-1 mt-1">
              <MapPin className="h-3 w-3 flex-shrink-0" />
              {selectedMobileBranch?.address}
            </DialogDescription>
          </DialogHeader>
          {selectedMobileBranch && (
            <div className="space-y-4 py-2">
              <div className="grid grid-cols-2 gap-4 text-sm bg-secondary/30 p-4 rounded-xl">
                <div className="flex flex-col">
                  <span className="text-muted-foreground text-xs mb-1">Personel Sayısı</span>
                  <span className="font-semibold">{selectedMobileBranch.staffCount} Kişi</span>
                </div>
                <div className="flex flex-col">
                  <span className="text-muted-foreground text-xs mb-1">Mesai Saatleri</span>
                  <span className="font-semibold flex items-center gap-1 text-blue-600 dark:text-blue-400">
                    <Clock className="h-3.5 w-3.5" />
                    {selectedMobileBranch.workStart} - {selectedMobileBranch.workEnd}
                  </span>
                </div>
                <div className="flex flex-col">
                  <span className="text-muted-foreground text-xs mb-1">Tolerans</span>
                  <span className="font-semibold text-amber-600">{selectedMobileBranch.tolerance} dk</span>
                </div>
                {selectedMobileBranch.latitude && (
                  <div className="flex flex-col">
                    <span className="text-muted-foreground text-xs mb-1">GPS Doğrulama</span>
                    <span className="font-semibold text-emerald-600 flex items-center gap-1">
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      {selectedMobileBranch.radius}m Aktif
                    </span>
                  </div>
                )}
              </div>
              
              <div className="grid grid-cols-2 gap-3 pt-4 border-t">
                <Button 
                  variant="outline" 
                  className="w-full justify-start rounded-xl h-10" 
                  onClick={() => { 
                    setSelectedBranch(selectedMobileBranch); 
                    setFormLat(selectedMobileBranch.latitude);
                    setFormLng(selectedMobileBranch.longitude);
                    setIsEditOpen(true); 
                    setSelectedMobileBranchId(null); 
                  }}
                >
                  <Edit2 className="h-4 w-4 mr-2" /> Düzenle
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start rounded-xl h-10" 
                  onClick={() => { 
                    setSelectedBranch(selectedMobileBranch); 
                    setIsQrOpen(true); 
                    setSelectedMobileBranchId(null); 
                  }}
                >
                  <QrCode className="h-4 w-4 mr-2" /> QR Kod
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start rounded-xl h-10" 
                  onClick={() => router.push(`/kiosk/${selectedMobileBranch.id}`)}
                >
                  <MonitorSmartphone className="h-4 w-4 mr-2" /> Tablet Modu
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start rounded-xl h-10" 
                  onClick={() => {
                    copyKioskLink(selectedMobileBranch.id);
                    setSelectedMobileBranchId(null);
                  }}
                >
                  <LinkIcon className="h-4 w-4 mr-2" /> Link Kopyala
                </Button>
                <Button 
                  variant="destructive" 
                  className="w-full justify-start col-span-2 rounded-xl h-10" 
                  onClick={() => { 
                    setBranchToDelete(selectedMobileBranch.id); 
                    setSelectedMobileBranchId(null); 
                  }}
                >
                  <Trash2 className="h-4 w-4 mr-2" /> Sil
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
      {/* Delete Confirmation Dialog */}
      <Dialog open={branchToDelete !== null} onOpenChange={(open) => !open && setBranchToDelete(null)}>
        <DialogContent className="sm:max-w-[400px] rounded-2xl">
          <DialogHeader>
            <DialogTitle className="text-destructive flex items-center gap-2 text-xl">
              <AlertCircle className="h-5 w-5" />
              Emin misiniz?
            </DialogTitle>
            <DialogDescription className="pt-2">
              Bu şubeyi silmek istediğinize emin misiniz? Bu işlem geri alınamaz ve bu şubeye bağlı personellerin giriş/çıkış işlemleri etkilenebilir.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="mt-4">
            <Button variant="outline" className="rounded-xl h-10" onClick={() => setBranchToDelete(null)}>İptal Et</Button>
            <Button variant="destructive" className="rounded-xl h-10" onClick={handleDeleteBranch}>Evet, Sil</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

