"use client";

import { useState, useMemo } from "react";
import { Plus, Search, MoreHorizontal, Filter, Clock, Calendar, Edit2, Trash2, Smartphone, KeyRound, QrCode, RefreshCw, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { HelpCircle, Users, AlertCircle, UserCheck, UserMinus } from "lucide-react";
import { InfoBubble } from "@/components/info-bubble";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

interface Staff {
  id: number;
  name: string;
  phone: string;
  branch: string;
  role: string;
  customHours: string | null;
  status: "active" | "on_leave";
  loginMethod: "QR" | "PIN" | "BOTH";
  deviceStatus: "REGISTERED" | "PENDING";
}

const initialStaff: Staff[] = [
  { id: 1, name: "Ayşe Yılmaz", phone: "0532 111 2233", branch: "Merkez Şube", role: "Müdür", customHours: null, status: "active", loginMethod: "BOTH", deviceStatus: "REGISTERED" },
  { id: 2, name: "Mehmet Demir", phone: "0533 222 3344", branch: "Kadıköy Şube", role: "Personel", customHours: "10:00 - 19:00", status: "active", loginMethod: "QR", deviceStatus: "REGISTERED" },
  { id: 3, name: "Zeynep Kaya", phone: "0534 333 4455", branch: "Merkez Şube", role: "Personel", customHours: null, status: "on_leave", loginMethod: "PIN", deviceStatus: "PENDING" },
  { id: 4, name: "Ali Veli", phone: "0535 444 5566", branch: "Kadıköy Şube", role: "Personel", customHours: "08:00 - 16:00", status: "active", loginMethod: "BOTH", deviceStatus: "REGISTERED" },
];

export default function StaffPage() {
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isCustomHoursOpen, setIsCustomHoursOpen] = useState(false);
  const [isLeaveOpen, setIsLeaveOpen] = useState(false);
  const [selectedMobileStaffId, setSelectedMobileStaffId] = useState<number | null>(null);
  const [staffToDelete, setStaffToDelete] = useState<number | null>(null);

  const [staffList, setStaffList] = useState<Staff[]>(initialStaff);
  const [selectedStaff, setSelectedStaff] = useState<Staff | null>(null);

  const selectedMobileStaff = staffList.find(s => s.id === selectedMobileStaffId);
  
  const [searchQuery, setSearchQuery] = useState("");
  const [filterBranch, setFilterBranch] = useState<string>("tumu");

  // Sayfalama State'i
  const [currentPage, setCurrentPage] = useState(1);
  const ITEMS_PER_PAGE = 10;

  const formatPhoneNumber = (value: string) => {
    if (!value) return value;
    const phoneNumber = value.replace(/[^\d]/g, '');
    const phoneNumberLength = phoneNumber.length;
    if (phoneNumberLength < 4) return phoneNumber;
    if (phoneNumberLength < 7) {
      return `${phoneNumber.slice(0, 4)} ${phoneNumber.slice(4)}`;
    }
    if (phoneNumberLength < 9) {
      return `${phoneNumber.slice(0, 4)} ${phoneNumber.slice(4, 7)} ${phoneNumber.slice(7)}`;
    }
    return `${phoneNumber.slice(0, 4)} ${phoneNumber.slice(4, 7)} ${phoneNumber.slice(7, 9)} ${phoneNumber.slice(9, 11)}`;
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formattedNumber = formatPhoneNumber(e.target.value);
    e.target.value = formattedNumber;
  };

  const filteredStaff = useMemo(() => {
    return staffList.filter(staff => {
      const matchesSearch = staff.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            staff.phone.includes(searchQuery);
      const matchesBranch = filterBranch === "tumu" || staff.branch === filterBranch;
      return matchesSearch && matchesBranch;
    });
  }, [staffList, searchQuery, filterBranch]);

  // Sayfalama Hesaplamaları
  const totalPages = Math.ceil(filteredStaff.length / ITEMS_PER_PAGE);
  const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
  const currentStaff = filteredStaff.slice(startIndex, startIndex + ITEMS_PER_PAGE);

  const handleAddStaff = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const newStaff: Staff = {
      id: Math.max(0, ...staffList.map(s => s.id)) + 1,
      name: formData.get("name") as string,
      phone: formData.get("phone") as string,
      branch: formData.get("branch") as string,
      role: formData.get("role") as string,
      customHours: null,
      status: "active",
      loginMethod: (formData.get("loginMethod") as "QR" | "PIN" | "BOTH") || "BOTH",
      deviceStatus: "PENDING"
    };
    setStaffList([...staffList, newStaff]);
    setIsAddOpen(false);
    toast.success("Personel başarıyla eklendi.");
  };

  const handleEditStaff = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!selectedStaff) return;
    const formData = new FormData(e.currentTarget);
    const updatedStaff: Staff = {
      ...selectedStaff,
      name: formData.get("name") as string,
      phone: formData.get("phone") as string,
      branch: formData.get("branch") as string,
      role: formData.get("role") as string,
      loginMethod: (formData.get("loginMethod") as "QR" | "PIN" | "BOTH") || "BOTH",
    };
    setStaffList(staffList.map(s => s.id === selectedStaff.id ? updatedStaff : s));
    setIsEditOpen(false);
    setSelectedStaff(null);
    toast.success("Personel bilgileri güncellendi.");
  };

  const handleCustomHours = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!selectedStaff) return;
    const formData = new FormData(e.currentTarget);
    const start = formData.get("start") as string;
    const end = formData.get("end") as string;
    
    const updatedStaff: Staff = {
      ...selectedStaff,
      customHours: start && end ? `${start} - ${end}` : null,
    };
    setStaffList(staffList.map(s => s.id === selectedStaff.id ? updatedStaff : s));
    setIsCustomHoursOpen(false);
    setSelectedStaff(null);
    toast.success("Özel mesai saatleri atandı.");
  };

  const handleAddLeave = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!selectedStaff) return;
    
    const updatedStaff: Staff = {
      ...selectedStaff,
      status: "on_leave",
    };
    setStaffList(staffList.map(s => s.id === selectedStaff.id ? updatedStaff : s));
    setIsLeaveOpen(false);
    setSelectedStaff(null);
    toast.success("İzin kaydı oluşturuldu.");
  };

  const handleDeleteStaff = () => {
    if (staffToDelete !== null) {
      setStaffList(staffList.filter(s => s.id !== staffToDelete));
      toast.success("Personel silindi.");
      setStaffToDelete(null);
    }
  };

  const handleResetDevice = (staffId: number) => {
    setStaffList(staffList.map(s => s.id === staffId ? { ...s, deviceStatus: "PENDING" } : s));
    toast.success("Personelin cihaz kaydı sıfırlandı. Yeni cihazla giriş yapabilir.");
  };

  const openEdit = (staff: Staff) => { setSelectedStaff(staff); setIsEditOpen(true); };
  const openCustomHours = (staff: Staff) => { setSelectedStaff(staff); setIsCustomHoursOpen(true); };
  const openLeave = (staff: Staff) => { setSelectedStaff(staff); setIsLeaveOpen(true); };

  const totalStaff = staffList.length;
  const activeStaff = staffList.filter(s => s.status === "active").length;
  const onLeaveStaff = staffList.filter(s => s.status === "on_leave").length;

  return (
    <div className="space-y-6 pb-20 md:pb-0">
      
      {/* BÖLÜM 1: Kompakt Mavi Özet Alanı */}
      <div className="bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 text-white rounded-2xl p-6 flex flex-col gap-5 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 -mt-16 -mr-16 w-64 h-64 bg-white opacity-5 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 -mb-16 -ml-16 w-48 h-48 bg-blue-400 opacity-10 rounded-full blur-2xl pointer-events-none"></div>

        <div className="relative z-10 flex flex-col md:flex-row md:items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <h2 className="text-2xl font-bold">Personel Yönetimi</h2>
              <InfoBubble content="Sisteme kayıtlı tüm çalışanlarınızı buradan görebilir, yeni personel ekleyebilir veya bilgilerini güncelleyebilirsiniz." className="w-6 h-6 hover:bg-white/10" iconClassName="text-blue-200 hover:text-white" />
            </div>
            <p className="text-blue-100 text-sm md:text-base max-w-2xl">
              İşletmenize kayıtlı tüm çalışanları buradan yönetebilir, özel mesai saatleri ve izinler tanımlayabilirsiniz.
            </p>
          </div>
          
          <div className="shrink-0">
            <Button className="bg-white text-blue-700 hover:bg-blue-50 border-none shadow-lg gap-2 font-semibold rounded-xl h-10 px-5" onClick={() => setIsAddOpen(true)}>
              <Plus className="w-5 h-5" /> Yeni Personel
            </Button>
          </div>
        </div>

        <div className="flex flex-wrap gap-3 relative z-10">
          <div className="bg-white/10 border border-white/20 rounded-full px-4 py-2 backdrop-blur-sm flex items-center gap-2">
            <Users className="w-4 h-4 text-blue-300"/>
            <span className="text-sm font-medium text-white">{totalStaff} Toplam Personel</span>
          </div>
          <div className="bg-white/10 border border-white/20 rounded-full px-4 py-2 backdrop-blur-sm flex items-center gap-2">
            <UserCheck className="w-4 h-4 text-emerald-300"/>
            <span className="text-sm font-medium text-white">{activeStaff} Aktif Çalışan</span>
          </div>
          <div className="bg-white/10 border border-white/20 rounded-full px-4 py-2 backdrop-blur-sm flex items-center gap-2">
            <UserMinus className="w-4 h-4 text-rose-300"/>
            <span className="text-sm font-medium text-white">{onLeaveStaff} İzinli Personel</span>
          </div>
        </div>
      </div>

      <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
          <DialogContent className="sm:max-w-[425px] rounded-2xl">
            <DialogHeader>
              <DialogTitle className="text-xl">Yeni Personel Ekle</DialogTitle>
              <DialogDescription>
                Personel bilgilerini girin. Personel bu telefon numarası ve PIN ile giriş yapacaktır.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleAddStaff}>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Ad Soyad <span className="text-destructive">*</span></Label>
                  <Input id="name" name="name" placeholder="Örn: Ayşe Yılmaz" className="h-10 rounded-xl" required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Telefon Numarası <span className="text-destructive">*</span></Label>
                  <Input id="phone" name="phone" placeholder="05XX XXX XX XX" onChange={handlePhoneChange} maxLength={15} className="h-10 rounded-xl" required />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="pin">PIN Kodu <span className="text-destructive">*</span></Label>
                    <Input id="pin" name="pin" type="password" maxLength={4} placeholder="****" className="h-10 rounded-xl" required />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Label htmlFor="loginMethod">Giriş Yöntemi</Label>
                      <InfoBubble content="Personelin işe giriş-çıkış yaparken kullanacağı yöntemdir. QR kod okutarak veya şifre (PIN) girerek işlem yapmalarını seçebilirsiniz." />
                    </div>
                    <Select name="loginMethod" defaultValue="BOTH">
                      <SelectTrigger className="w-full h-10 rounded-xl bg-secondary/50 border-border">
                        <SelectValue placeholder="Giriş yöntemi seçin" />
                      </SelectTrigger>
                      <SelectContent className="rounded-xl">
                        <SelectItem value="BOTH" className="rounded-lg">QR Kod ve PIN</SelectItem>
                        <SelectItem value="QR" className="rounded-lg">Sadece QR Kod</SelectItem>
                        <SelectItem value="PIN" className="rounded-lg">Sadece PIN</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="startDate">Başlangıç <span className="text-destructive">*</span></Label>
                    <Input id="startDate" name="startDate" type="date" className="h-10 rounded-xl" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="leaveBalance">İzin Bakiyesi</Label>
                    <Input id="leaveBalance" name="leaveBalance" type="number" defaultValue="0" min="0" className="h-10 rounded-xl" required />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="branch">Şube</Label>
                    <Select name="branch" defaultValue="Merkez Şube">
                      <SelectTrigger className="w-full h-10 rounded-xl bg-secondary/50 border-border">
                        <SelectValue placeholder="Şube seçin" />
                      </SelectTrigger>
                      <SelectContent className="rounded-xl">
                        <SelectItem value="Merkez Şube" className="rounded-lg">Merkez Şube</SelectItem>
                        <SelectItem value="Kadıköy Şube" className="rounded-lg">Kadıköy Şube</SelectItem>
                        <SelectItem value="Beşiktaş Şube" className="rounded-lg">Beşiktaş Şube</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="role">Rol</Label>
                    <Select name="role" defaultValue="Personel">
                      <SelectTrigger className="w-full h-10 rounded-xl bg-secondary/50 border-border">
                        <SelectValue placeholder="Rol seçin" />
                      </SelectTrigger>
                      <SelectContent className="rounded-xl">
                        <SelectItem value="Müdür" className="rounded-lg">Şube Müdürü</SelectItem>
                        <SelectItem value="Personel" className="rounded-lg">Personel</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" className="rounded-xl h-10" onClick={() => setIsAddOpen(false)}>İptal</Button>
                <Button type="submit" className="rounded-xl h-10 px-8 bg-blue-600 hover:bg-blue-700">Kaydet</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

      <div className="bg-card border rounded-2xl p-4 flex flex-col sm:flex-row gap-4 items-center justify-between shadow-sm">
        <div className="relative w-full sm:max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            type="text"
            placeholder="İsim veya telefon ara..."
            className="pl-9 w-full rounded-xl h-10 bg-secondary/50 border-border"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentPage(1);
            }}
          />
        </div>
        
        <Select value={filterBranch} onValueChange={(val) => {
          setFilterBranch(val || "tumu");
          setCurrentPage(1);
        }}>
          <SelectTrigger className="w-full sm:w-[200px] rounded-xl h-10 bg-secondary/50 border-border">
            <Filter className="h-4 w-4 mr-2 text-muted-foreground" />
            <SelectValue placeholder="Şube Filtrele" />
          </SelectTrigger>
          <SelectContent className="rounded-xl">
            <SelectItem value="tumu" className="rounded-lg">Tüm Şubeler</SelectItem>
            <SelectItem value="Merkez Şube" className="rounded-lg">Merkez Şube</SelectItem>
            <SelectItem value="Kadıköy Şube" className="rounded-lg">Kadıköy Şube</SelectItem>
            <SelectItem value="Beşiktaş Şube" className="rounded-lg">Beşiktaş Şube</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Mobil Görünüm (Kartlar) */}
      <div className="grid gap-3 md:hidden">
        {filteredStaff.length === 0 ? (
          <div className="text-center py-12 px-4 border-2 border-dashed rounded-2xl bg-muted/30">
            <div className="bg-blue-100 dark:bg-blue-900/30 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
              <Users className="h-6 w-6 text-blue-600 dark:text-blue-400" />
            </div>
            <h3 className="text-lg font-semibold mb-1">Personel Bulunamadı</h3>
            <p className="text-sm text-muted-foreground mb-4">
              {searchQuery ? "Aramanıza uygun personel bulunamadı." : "Sistemde henüz kayıtlı personel yok."}
            </p>
            {!searchQuery && (
              <Button onClick={() => setIsAddOpen(true)} className="rounded-xl bg-blue-600 hover:bg-blue-700">
                <Plus className="h-4 w-4 mr-2" /> İlk Personeli Ekle
              </Button>
            )}
          </div>
        ) : currentStaff.map((staff) => (
          <div 
            key={staff.id} 
            className="border rounded-xl bg-card p-4 flex items-center gap-4 shadow-sm cursor-pointer hover:border-blue-500/40 hover:bg-blue-50/50 dark:hover:bg-blue-900/10 active:scale-[0.98] transition-all duration-200"
            onClick={() => setSelectedMobileStaffId(staff.id)}
          >
            <Avatar className="h-12 w-12 border-2 border-background shadow-sm">
              <AvatarFallback className="bg-blue-100 text-blue-700 font-semibold">{staff.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
            </Avatar>
            <div className="flex flex-col flex-1 min-w-0">
              <span className="font-semibold text-base truncate">{staff.name}</span>
              <span className="text-xs text-muted-foreground truncate">{staff.role} • {staff.branch}</span>
            </div>
            <div className="flex flex-col items-end gap-2">
              <Badge variant={staff.status === "active" ? "default" : "secondary"} className={staff.status === "active" ? "bg-emerald-500 hover:bg-emerald-600" : ""}>
                {staff.status === "active" ? "Aktif" : "İzinli"}
              </Badge>
              {staff.deviceStatus === "REGISTERED" && <Smartphone className="h-4 w-4 text-emerald-500" />}
            </div>
          </div>
        ))}
      </div>

      {/* Mobile Detail Dialog */}
      <Dialog open={!!selectedMobileStaffId} onOpenChange={(open) => !open && setSelectedMobileStaffId(null)}>
        <DialogContent className="sm:max-w-[425px] w-[95vw] rounded-2xl">
          <DialogHeader>
            <DialogTitle className="text-xl">{selectedMobileStaff?.name}</DialogTitle>
            <DialogDescription>{selectedMobileStaff?.role} - {selectedMobileStaff?.branch}</DialogDescription>
          </DialogHeader>
          {selectedMobileStaff && (
            <div className="space-y-4 py-2">
              <div className="grid grid-cols-2 gap-4 text-sm bg-secondary/30 p-4 rounded-xl">
                <div className="flex flex-col">
                  <span className="text-muted-foreground text-xs mb-1">Telefon</span>
                  <span className="font-semibold">{selectedMobileStaff.phone}</span>
                </div>
                <div className="flex flex-col">
                  <span className="text-muted-foreground text-xs mb-1">Mesai Saatleri</span>
                  {selectedMobileStaff.customHours ? (
                    <span className="font-semibold text-blue-600 dark:text-blue-400">{selectedMobileStaff.customHours}</span>
                  ) : (
                    <span className="font-medium text-muted-foreground">Şube Varsayılanı</span>
                  )}
                </div>
                <div className="flex flex-col col-span-2">
                  <span className="text-muted-foreground text-xs mb-1">Durum</span>
                  <div className="flex gap-2 mt-1">
                    <Badge variant={selectedMobileStaff.status === "active" ? "default" : "secondary"} className={selectedMobileStaff.status === "active" ? "bg-emerald-500 hover:bg-emerald-600" : ""}>
                      {selectedMobileStaff.status === "active" ? "Aktif" : "İzinli"}
                    </Badge>
                    <Badge variant="outline" className={selectedMobileStaff.deviceStatus === "REGISTERED" ? "text-emerald-600 border-emerald-200 bg-emerald-50" : "text-amber-600 border-amber-200 bg-amber-50"}>
                      {selectedMobileStaff.deviceStatus === "REGISTERED" ? "Cihaz Kayıtlı" : "Cihaz Bekliyor"}
                    </Badge>
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-3 pt-4 border-t">
                <Button 
                  variant="outline" 
                  className="w-full justify-start rounded-xl h-10" 
                  onClick={() => { openEdit(selectedMobileStaff); setSelectedMobileStaffId(null); }}
                >
                  <Edit2 className="h-4 w-4 mr-2" /> Düzenle
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start rounded-xl h-10" 
                  onClick={() => { openCustomHours(selectedMobileStaff); setSelectedMobileStaffId(null); }}
                >
                  <Clock className="h-4 w-4 mr-2" /> Özel Mesai
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start rounded-xl h-10" 
                  onClick={() => { openLeave(selectedMobileStaff); setSelectedMobileStaffId(null); }}
                >
                  <Calendar className="h-4 w-4 mr-2" /> İzin Ekle
                </Button>
                <Button 
                  variant="destructive" 
                  className="w-full justify-start rounded-xl h-10" 
                  onClick={() => { setStaffToDelete(selectedMobileStaff.id); setSelectedMobileStaffId(null); }}
                >
                  <Trash2 className="h-4 w-4 mr-2" /> Sil
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Masaüstü Görünüm (Tablo) */}
      <div className="hidden md:block border rounded-2xl bg-card overflow-hidden shadow-sm">
        <Table>
          <TableHeader className="bg-secondary/50">
            <TableRow className="hover:bg-transparent">
              <TableHead className="font-semibold">Personel</TableHead>
              <TableHead className="font-semibold">Şube & Rol</TableHead>
              <TableHead className="font-semibold">
                <div className="flex items-center gap-1">
                  Giriş Yöntemi
                  <InfoBubble content="Personelin işe giriş-çıkış yaparken kullanacağı yöntemdir." className="w-4 h-4" />
                </div>
              </TableHead>
              <TableHead className="font-semibold">
                <div className="flex items-center gap-1">
                  Cihaz Durumu
                  <InfoBubble content="Personelin kendi cep telefonunu sisteme tanıtıp tanıtmadığını gösterir. 'Bekliyor' ise personel henüz mobil uygulamaya giriş yapmamıştır." className="w-4 h-4" />
                </div>
              </TableHead>
              <TableHead className="font-semibold">
                <div className="flex items-center gap-1">
                  Mesai Saatleri
                  <InfoBubble content="Bu personele, şirketin genel çalışma saatlerinden farklı, kişiye özel bir mesai saati atamak için kullanın." className="w-4 h-4" />
                </div>
              </TableHead>
              <TableHead className="font-semibold">Durum</TableHead>
              <TableHead className="w-[50px]"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredStaff.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="h-64 text-center">
                  <div className="flex flex-col items-center justify-center">
                    <div className="bg-blue-100 dark:bg-blue-900/30 w-12 h-12 rounded-full flex items-center justify-center mb-4">
                      <Users className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                    </div>
                    <h3 className="text-lg font-semibold mb-1">Personel Bulunamadı</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      {searchQuery ? "Aramanıza uygun personel bulunamadı." : "Sistemde henüz kayıtlı personel yok."}
                    </p>
                    {!searchQuery && (
                      <Button onClick={() => setIsAddOpen(true)} className="rounded-xl bg-blue-600 hover:bg-blue-700">
                        <Plus className="h-4 w-4 mr-2" /> İlk Personeli Ekle
                      </Button>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ) : currentStaff.map((staff) => (
              <TableRow key={staff.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-900/50 transition-colors">
                <TableCell>
                  <div className="flex items-center gap-3">
                    <Avatar className="h-10 w-10 border border-border">
                      <AvatarFallback className="bg-blue-50 text-blue-700 font-medium">{staff.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                    </Avatar>
                    <div className="flex flex-col">
                      <span className="font-semibold">{staff.name}</span>
                      <span className="text-xs text-muted-foreground">{staff.phone}</span>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex flex-col">
                    <span className="font-medium">{staff.branch}</span>
                    <span className="text-xs text-muted-foreground">{staff.role}</span>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-1.5 text-sm">
                    {staff.loginMethod === "BOTH" && <><QrCode className="h-4 w-4 text-muted-foreground" /><KeyRound className="h-4 w-4 text-muted-foreground" /></>}
                    {staff.loginMethod === "QR" && <QrCode className="h-4 w-4 text-muted-foreground" />}
                    {staff.loginMethod === "PIN" && <KeyRound className="h-4 w-4 text-muted-foreground" />}
                    <span className="text-muted-foreground font-medium">
                      {staff.loginMethod === "BOTH" ? "QR + PIN" : staff.loginMethod === "QR" ? "Sadece QR" : "Sadece PIN"}
                    </span>
                  </div>
                </TableCell>
                <TableCell>
                  {staff.deviceStatus === "REGISTERED" ? (
                    <Badge variant="outline" className="text-emerald-600 border-emerald-200 bg-emerald-50 flex w-fit items-center gap-1.5 px-2.5 py-0.5">
                      <Smartphone className="h-3.5 w-3.5" /> Kayıtlı
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="text-amber-600 border-amber-200 bg-amber-50 flex w-fit items-center gap-1.5 px-2.5 py-0.5">
                      <Smartphone className="h-3.5 w-3.5" /> Bekliyor
                    </Badge>
                  )}
                </TableCell>
                <TableCell>
                  {staff.customHours ? (
                    <div className="flex flex-col">
                      <span className="font-semibold text-blue-600 dark:text-blue-400">{staff.customHours}</span>
                      <span className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">Özel Saat</span>
                    </div>
                  ) : (
                    <span className="text-sm text-muted-foreground">Şube Varsayılanı</span>
                  )}
                </TableCell>
                <TableCell>
                  {staff.status === "active" ? (
                    <Badge variant="default" className="bg-emerald-500 hover:bg-emerald-600">Aktif</Badge>
                  ) : (
                    <Badge variant="secondary">İzinli</Badge>
                  )}
                </TableCell>
                <TableCell>
                  <DropdownMenu>
                    <DropdownMenuTrigger
                      render={
                        <Button variant="ghost" size="icon" className="rounded-lg">
                          <MoreHorizontal className="h-4 w-4" />
                          <span className="sr-only">Menüyü aç</span>
                        </Button>
                      }
                    />
                    <DropdownMenuContent align="end" className="rounded-xl">
                      <DropdownMenuItem onClick={() => openEdit(staff)} className="rounded-lg cursor-pointer">
                        <Edit2 className="h-4 w-4 mr-2" /> Düzenle
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => openCustomHours(staff)} className="rounded-lg cursor-pointer">
                        <Clock className="h-4 w-4 mr-2" /> Özel Mesai Ata
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => openLeave(staff)} className="rounded-lg cursor-pointer">
                        <Calendar className="h-4 w-4 mr-2" /> İzin Ekle
                      </DropdownMenuItem>
                      <DropdownMenuItem className="text-destructive rounded-lg cursor-pointer" onClick={() => setStaffToDelete(staff.id)}>
                        <Trash2 className="h-4 w-4 mr-2" /> Sil
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Sayfalama Kontrolleri */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2 mt-4">
          <Button
            variant="outline"
            size="icon"
            onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            className="w-9 h-9"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          
          {Array.from({ length: totalPages }).map((_, i) => {
            const page = i + 1;
            return (
              <Button
                key={page}
                variant={currentPage === page ? "default" : "outline"}
                className={`w-9 h-9 p-0 ${currentPage === page ? 'bg-primary text-primary-foreground' : ''}`}
                onClick={() => setCurrentPage(page)}
              >
                {page}
              </Button>
            );
          })}

          <Button
            variant="outline"
            size="icon"
            onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
            className="w-9 h-9"
          >
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      )}

      {/* Edit Dialog */}
      <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
        <DialogContent className="sm:max-w-[425px] rounded-2xl">
          <DialogHeader>
            <DialogTitle className="text-xl">Personeli Düzenle</DialogTitle>
            <DialogDescription>
              Personel bilgilerini güncelleyin.
            </DialogDescription>
          </DialogHeader>
          {selectedStaff && (
            <form onSubmit={handleEditStaff}>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-name">Ad Soyad <span className="text-destructive">*</span></Label>
                  <Input id="edit-name" name="name" defaultValue={selectedStaff.name} className="h-10 rounded-xl" required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-phone">Telefon Numarası <span className="text-destructive">*</span></Label>
                  <Input id="edit-phone" name="phone" defaultValue={selectedStaff.phone} onChange={handlePhoneChange} maxLength={15} className="h-10 rounded-xl" required />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="edit-startDate">Başlangıç <span className="text-destructive">*</span></Label>
                    <Input id="edit-startDate" name="startDate" type="date" defaultValue="2023-01-15" className="h-10 rounded-xl" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit-leaveBalance">İzin Bakiyesi</Label>
                    <Input id="edit-leaveBalance" name="leaveBalance" type="number" defaultValue="14" min="0" className="h-10 rounded-xl" required />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="edit-branch">Şube</Label>
                    <Select name="branch" defaultValue={selectedStaff.branch}>
                      <SelectTrigger className="w-full h-10 rounded-xl bg-secondary/50 border-border">
                        <SelectValue placeholder="Şube seçin" />
                      </SelectTrigger>
                      <SelectContent className="rounded-xl">
                        <SelectItem value="Merkez Şube" className="rounded-lg">Merkez Şube</SelectItem>
                        <SelectItem value="Kadıköy Şube" className="rounded-lg">Kadıköy Şube</SelectItem>
                        <SelectItem value="Beşiktaş Şube" className="rounded-lg">Beşiktaş Şube</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit-role">Rol</Label>
                    <Select name="role" defaultValue={selectedStaff.role}>
                      <SelectTrigger className="w-full h-10 rounded-xl bg-secondary/50 border-border">
                        <SelectValue placeholder="Rol seçin" />
                      </SelectTrigger>
                      <SelectContent className="rounded-xl">
                        <SelectItem value="Müdür" className="rounded-lg">Şube Müdürü</SelectItem>
                        <SelectItem value="Personel" className="rounded-lg">Personel</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Label htmlFor="edit-loginMethod">Giriş Yöntemi</Label>
                    <InfoBubble content="Personelin işe giriş-çıkış yaparken kullanacağı yöntemdir. QR kod okutarak veya şifre (PIN) girerek işlem yapmalarını seçebilirsiniz." />
                  </div>
                  <Select name="loginMethod" defaultValue={selectedStaff.loginMethod}>
                    <SelectTrigger className="w-full h-10 rounded-xl bg-secondary/50 border-border">
                      <SelectValue placeholder="Giriş yöntemi seçin" />
                    </SelectTrigger>
                    <SelectContent className="rounded-xl">
                      <SelectItem value="BOTH" className="rounded-lg">QR Kod ve PIN</SelectItem>
                      <SelectItem value="QR" className="rounded-lg">Sadece QR Kod</SelectItem>
                      <SelectItem value="PIN" className="rounded-lg">Sadece PIN</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" className="rounded-xl h-10" onClick={() => setIsEditOpen(false)}>İptal</Button>
                <Button type="submit" className="rounded-xl h-10 px-8 bg-blue-600 hover:bg-blue-700">Güncelle</Button>
              </DialogFooter>
            </form>
          )}
        </DialogContent>
      </Dialog>

      {/* Custom Hours Dialog */}
      <Dialog open={isCustomHoursOpen} onOpenChange={setIsCustomHoursOpen}>
        <DialogContent className="sm:max-w-[425px] rounded-2xl">
          <DialogHeader>
            <DialogTitle className="text-xl">Özel Mesai Ata</DialogTitle>
            <DialogDescription>
              <span className="font-semibold text-foreground">{selectedStaff?.name}</span> için şube varsayılanından farklı mesai saatleri belirleyin.
            </DialogDescription>
          </DialogHeader>
          {selectedStaff && (
            <form onSubmit={handleCustomHours}>
              <div className="grid grid-cols-2 gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="custom-start">Mesai Başlangıç</Label>
                  <Input 
                    id="custom-start" 
                    name="start" 
                    type="time" 
                    className="h-10 rounded-xl"
                    defaultValue={selectedStaff.customHours ? selectedStaff.customHours.split(" - ")[0] : "09:00"} 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="custom-end">Mesai Bitiş</Label>
                  <Input 
                    id="custom-end" 
                    name="end" 
                    type="time" 
                    className="h-10 rounded-xl"
                    defaultValue={selectedStaff.customHours ? selectedStaff.customHours.split(" - ")[1] : "18:00"} 
                  />
                </div>
              </div>
              <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-xl mb-4 flex items-start gap-3">
                <AlertCircle className="h-5 w-5 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
                <p className="text-sm text-blue-800 dark:text-blue-300">
                  Özel mesaiyi kaldırmak için saatleri boş bırakıp kaydedin. Personel tekrar şube varsayılan saatlerine dönecektir.
                </p>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" className="rounded-xl h-10" onClick={() => setIsCustomHoursOpen(false)}>İptal</Button>
                <Button type="submit" className="rounded-xl h-10 px-8 bg-blue-600 hover:bg-blue-700">Kaydet</Button>
              </DialogFooter>
            </form>
          )}
        </DialogContent>
      </Dialog>

      {/* Add Leave Dialog */}
      <Dialog open={isLeaveOpen} onOpenChange={setIsLeaveOpen}>
        <DialogContent className="sm:max-w-[425px] rounded-2xl">
          <DialogHeader>
            <DialogTitle className="text-xl">İzin Ekle</DialogTitle>
            <DialogDescription>
              <span className="font-semibold text-foreground">{selectedStaff?.name}</span> için izin kaydı oluşturun.
            </DialogDescription>
          </DialogHeader>
          {selectedStaff && (
            <form onSubmit={handleAddLeave}>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="leave-type">İzin Türü</Label>
                  <Select name="type" defaultValue="yillik">
                    <SelectTrigger className="w-full h-10 rounded-xl bg-secondary/50 border-border">
                      <SelectValue placeholder="İzin türü seçin" />
                    </SelectTrigger>
                    <SelectContent className="rounded-xl">
                      <SelectItem value="yillik" className="rounded-lg">Yıllık İzin</SelectItem>
                      <SelectItem value="hastalik" className="rounded-lg">Hastalık İzni</SelectItem>
                      <SelectItem value="mazeret" className="rounded-lg">Mazeret İzni</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="leave-start">Başlangıç</Label>
                    <Input id="leave-start" name="start" type="date" className="h-10 rounded-xl" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="leave-end">Bitiş</Label>
                    <Input id="leave-end" name="end" type="date" className="h-10 rounded-xl" required />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="leave-reason">Açıklama (İsteğe bağlı)</Label>
                  <Input id="leave-reason" name="reason" placeholder="İzin nedeni..." className="h-10 rounded-xl" />
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" className="rounded-xl h-10" onClick={() => setIsLeaveOpen(false)}>İptal</Button>
                <Button type="submit" className="rounded-xl h-10 px-8 bg-blue-600 hover:bg-blue-700">İzni Onayla</Button>
              </DialogFooter>
            </form>
          )}
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={staffToDelete !== null} onOpenChange={(open) => !open && setStaffToDelete(null)}>
        <DialogContent className="sm:max-w-[400px] rounded-2xl">
          <DialogHeader>
            <DialogTitle className="text-destructive flex items-center gap-2 text-xl">
              <AlertCircle className="h-6 w-6" />
              Emin misiniz?
            </DialogTitle>
            <DialogDescription className="pt-2 text-base">
              Bu personeli silmek istediğinize emin misiniz? Bu işlem geri alınamaz ve personelin tüm geçmiş puantaj kayıtları etkilenebilir.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="mt-4 gap-2 sm:gap-0">
            <Button variant="outline" className="rounded-xl h-10" onClick={() => setStaffToDelete(null)}>İptal Et</Button>
            <Button variant="destructive" className="rounded-xl h-10" onClick={handleDeleteStaff}>Evet, Sil</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
