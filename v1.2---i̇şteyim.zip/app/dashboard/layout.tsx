"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { 
  LayoutDashboard, 
  Users, 
  Store, 
  CalendarDays, 
  Settings, 
  LogOut, 
  Menu,
  QrCode,
  Bell,
  FileSpreadsheet,
  Smartphone,
  Check,
  Clock,
  X as CloseIcon
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from "@/components/ui/sheet";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger, DropdownMenuGroup } from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const sidebarLinks = [
  { name: "Genel Bakış", href: "/dashboard", icon: LayoutDashboard },
  { name: "Şubeler", href: "/dashboard/branches", icon: Store },
  { name: "Personel", href: "/dashboard/staff", icon: Users },
  { name: "Vardiyalar", href: "/dashboard/shifts", icon: Clock },
  { name: "İzinler", href: "/dashboard/leaves", icon: CalendarDays },
  { name: "Puantaj & Rapor", href: "/dashboard/reports", icon: FileSpreadsheet },
  { name: "Ayarlar", href: "/dashboard/settings", icon: Settings },
];

interface ResetRequest {
  id: number;
  staffName: string;
  phone: string;
  timestamp: string;
  status: string;
}

function SidebarContent({ pathname, setIsMobileMenuOpen }: { pathname: string, setIsMobileMenuOpen: (val: boolean) => void }) {
  const router = useRouter();

  const handleLogout = () => {
    // Çıkış yapma simülasyonu
    router.push("/");
  };

  return (
    <div className="flex flex-col h-full">
      <div className="h-16 flex items-center px-6 border-b">
        <Link href="/dashboard" className="flex items-center gap-2">
          <div className="bg-primary text-primary-foreground p-1.5 rounded-lg">
            <QrCode className="h-5 w-5" />
          </div>
          <span className="font-bold text-xl tracking-tight">İşteyim</span>
        </Link>
      </div>
      <div className="flex-1 py-6 px-4 space-y-1 overflow-y-auto">
        {sidebarLinks.map((link) => {
          const Icon = link.icon;
          const isActive = pathname === link.href || (link.href !== '/dashboard' && pathname.startsWith(link.href));
          
          return (
            <Link key={link.href} href={link.href} onClick={() => setIsMobileMenuOpen(false)}>
              <span className={cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors",
                isActive 
                  ? "bg-primary/10 text-primary" 
                  : "text-muted-foreground hover:bg-muted hover:text-foreground"
              )}>
                <Icon className="h-5 w-5" />
                {link.name}
              </span>
            </Link>
          );
        })}
      </div>
      <div className="p-4 border-t">
        <Button 
          variant="ghost" 
          className="w-full justify-start gap-3 text-muted-foreground hover:text-destructive"
          onClick={handleLogout}
        >
          <LogOut className="h-5 w-5" />
          Çıkış Yap
        </Button>
      </div>
    </div>
  );
}

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [resetRequests, setResetRequests] = useState<ResetRequest[]>([]);

  useEffect(() => {
    const loadRequests = () => {
      const requests = JSON.parse(localStorage.getItem("device_reset_requests") || "[]");
      setResetRequests(requests.filter((r: ResetRequest) => r.status === "pending"));
    };

    loadRequests();
    // Poll for new requests every 5 seconds for demo purposes
    const interval = setInterval(loadRequests, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleAction = (id: number, action: "reset" | "cancel") => {
    const allRequests = JSON.parse(localStorage.getItem("device_reset_requests") || "[]");
    const updatedRequests = allRequests.map((r: ResetRequest) => 
      r.id === id ? { ...r, status: action === "reset" ? "approved" : "rejected" } : r
    );
    localStorage.setItem("device_reset_requests", JSON.stringify(updatedRequests));
    setResetRequests(updatedRequests.filter((r: ResetRequest) => r.status === "pending"));

    if (action === "reset") {
      toast.success("Cihaz kaydı başarıyla sıfırlandı.");
    } else {
      toast.info("Sıfırlama isteği reddedildi.");
    }
  };

  return (
    <div className="min-h-screen bg-slate-50/50 flex">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex w-64 flex-col fixed inset-y-0 z-50 bg-background border-r">
        <SidebarContent pathname={pathname} setIsMobileMenuOpen={setIsMobileMenuOpen} />
      </aside>

      {/* Main Content */}
      <main className="flex-1 md:pl-64 flex flex-col min-h-screen w-full max-w-full overflow-x-hidden">
        {/* Header */}
        <header className="h-16 flex items-center justify-between px-4 sm:px-6 border-b bg-background sticky top-0 z-40">
          <div className="flex items-center gap-4">
            <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
              <SheetTrigger
                render={
                  <Button variant="ghost" size="icon" className="md:hidden">
                    <Menu className="h-5 w-5" />
                    <span className="sr-only">Menüyü aç</span>
                  </Button>
                }
              />
              <SheetContent side="left" className="p-0 w-72">
                <SheetTitle className="sr-only">Navigasyon Menüsü</SheetTitle>
                <SidebarContent pathname={pathname} setIsMobileMenuOpen={setIsMobileMenuOpen} />
              </SheetContent>
            </Sheet>
            <h1 className="text-lg font-semibold hidden sm:block">
              {sidebarLinks.find(l => l.href === pathname)?.name || "Dashboard"}
            </h1>
          </div>

          <div className="flex items-center gap-2 sm:gap-4">
            <DropdownMenu>
              <DropdownMenuTrigger
                render={
                  <Button variant="ghost" size="icon" className="relative">
                    <Bell className="h-5 w-5 text-muted-foreground" />
                    {resetRequests.length > 0 && (
                      <span className="absolute top-2 right-2.5 w-2 h-2 bg-destructive rounded-full border-2 border-background"></span>
                    )}
                  </Button>
                }
              />
              <DropdownMenuContent align="end" className="w-80">
                <DropdownMenuGroup>
                  <DropdownMenuLabel className="flex items-center justify-between">
                    Bildirimler
                    {resetRequests.length > 0 && (
                      <span className="bg-destructive text-destructive-foreground text-[10px] px-1.5 py-0.5 rounded-full">
                        {resetRequests.length} Yeni
                      </span>
                    )}
                  </DropdownMenuLabel>
                </DropdownMenuGroup>
                <DropdownMenuSeparator />
                <div className="max-h-[400px] overflow-y-auto">
                  {resetRequests.length > 0 ? (
                    resetRequests.map((request) => (
                      <div key={request.id} className="p-4 border-b last:border-0 hover:bg-muted/30 transition-colors">
                        <div className="flex items-start gap-3">
                          <div className="bg-amber-100 p-2 rounded-full">
                            <Smartphone className="h-4 w-4 text-amber-600" />
                          </div>
                          <div className="flex-1 space-y-1">
                            <div className="flex items-center justify-between">
                              <span className="font-semibold text-sm">Cihaz Sıfırlama İsteği</span>
                              <span className="text-[10px] text-muted-foreground">Şimdi</span>
                            </div>
                            <p className="text-xs text-muted-foreground leading-relaxed">
                              <span className="font-medium text-foreground">{request.staffName}</span> ({request.phone}) farklı bir cihazdan giriş yapmak için onay bekliyor.
                            </p>
                            <div className="flex gap-2 pt-2">
                              <Button 
                                size="sm" 
                                variant="outline" 
                                className="h-8 flex-1 text-xs gap-1 border-destructive/20 text-destructive hover:bg-destructive/10"
                                onClick={() => handleAction(request.id, "cancel")}
                              >
                                <CloseIcon className="h-3 w-3" /> İptal Et
                              </Button>
                              <Button 
                                size="sm" 
                                className="h-8 flex-1 text-xs gap-1 bg-emerald-600 hover:bg-emerald-700"
                                onClick={() => handleAction(request.id, "reset")}
                              >
                                <Check className="h-3 w-3" /> Sıfırla
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <>
                      <DropdownMenuItem className="flex flex-col items-start gap-1 p-3 cursor-pointer">
                        <div className="flex items-center gap-2 w-full justify-between">
                          <span className="font-medium text-sm">Yeni İzin Talebi</span>
                          <span className="text-xs text-muted-foreground">5 dk önce</span>
                        </div>
                        <p className="text-xs text-muted-foreground">Zeynep Kaya yıllık izin talebinde bulundu.</p>
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem className="flex flex-col items-start gap-1 p-3 cursor-pointer">
                        <div className="flex items-center gap-2 w-full justify-between">
                          <span className="font-medium text-sm">Sistem Güncellemesi</span>
                          <span className="text-xs text-muted-foreground">1 saat önce</span>
                        </div>
                        <p className="text-xs text-muted-foreground">Sistem başarıyla güncellendi.</p>
                      </DropdownMenuItem>
                    </>
                  )}
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="w-full text-center justify-center text-primary cursor-pointer">
                  Tümünü Okundu İşaretle
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <Button 
              variant="ghost" 
              size="icon" 
              className="text-muted-foreground hover:text-destructive transition-colors"
              onClick={() => router.push("/")}
            >
              <LogOut className="h-5 w-5" />
              <span className="sr-only">Çıkış Yap</span>
            </Button>
          </div>
        </header>

        {/* Page Content */}
        <div className="flex-1 p-4 sm:p-6 lg:p-8">
          {children}
        </div>
      </main>
    </div>
  );
}
