"use client";

import { useState } from "react";
import { Building, Bell, Lock, CreditCard, Save, CalendarDays, Clock, UserCheck, ShieldCheck, Zap, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { InfoBubble } from "@/components/info-bubble";
import { toast } from "sonner";

export default function SettingsPage() {
  const [activeDialog, setActiveDialog] = useState<string | null>(null);

  const handleSave = () => {
    toast.success("Değişiklikler başarıyla kaydedildi.");
    setActiveDialog(null);
  };

  const settingsCards = [
    {
      id: "business",
      title: "İşletme Profili",
      icon: Building,
      color: "text-blue-500",
      bgColor: "bg-blue-500/10",
      description: "Firma adı, yetkili kişi, iletişim ve adres bilgilerinizi güncelleyin."
    },
    {
      id: "rules",
      title: "Mesai ve Kurallar",
      icon: Clock,
      color: "text-indigo-500",
      bgColor: "bg-indigo-500/10",
      description: "Geç kalma toleransı, standart mesai saatleri ve çalışma günlerini belirleyin."
    },
    {
      id: "leaves",
      title: "İzin Politikaları",
      icon: CalendarDays,
      color: "text-emerald-500",
      bgColor: "bg-emerald-500/10",
      description: "Personel kıdemine göre yıllık izin hakediş günlerini otomatik ayarlayın."
    },
    {
      id: "notifications",
      title: "Bildirim Ayarları",
      icon: Bell,
      color: "text-amber-500",
      bgColor: "bg-amber-500/10",
      description: "Günlük özetler, geç kalma uyarıları ve sistem mesajları için tercihlerinizi yönetin."
    },
    {
      id: "security",
      title: "Güvenlik",
      icon: Lock,
      color: "text-rose-500",
      bgColor: "bg-rose-500/10",
      description: "Hesap şifrenizi değiştirin ve ekstra güvenlik önlemlerinizi güncelleyin."
    },
    {
      id: "billing",
      title: "Abonelik ve Plan",
      icon: CreditCard,
      color: "text-purple-500",
      bgColor: "bg-purple-500/10",
      description: "Mevcut paketinizi, faturalarınızı ve personel kotanızı görüntüleyin."
    }
  ];

  return (
    <div className="space-y-6 pb-20 md:pb-0">
      
      {/* BÖLÜM 1: Kompakt Mavi Özet Alanı */}
      <div className="bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 text-white rounded-2xl p-6 flex flex-col gap-5 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 -mt-16 -mr-16 w-64 h-64 bg-white opacity-5 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 -mb-16 -ml-16 w-48 h-48 bg-blue-400 opacity-10 rounded-full blur-2xl pointer-events-none"></div>

        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-2">
            <h2 className="text-2xl font-bold">Ayarlar ve Sistem Yönetimi</h2>
            <InfoBubble content="Şirketinizin genel mesai kurallarını, izin politikalarını ve bildirim tercihlerini buradan yapılandırabilirsiniz." className="w-6 h-6 hover:bg-white/10" iconClassName="text-blue-200 hover:text-white" />
          </div>
          <p className="text-blue-100 text-sm md:text-base max-w-2xl">
            İşletmenizin temel kurallarını, bildirim tercihlerini ve abonelik durumunu bu panelden kolayca yönetebilirsiniz.
          </p>
        </div>

        <div className="flex flex-wrap gap-3 relative z-10">
          <div className="bg-white/10 border border-white/20 rounded-full px-4 py-2 backdrop-blur-sm flex items-center gap-2">
            <Zap className="w-4 h-4 text-amber-300"/>
            <span className="text-sm font-medium text-white">KOBİ Pro Plan</span>
          </div>
          <div className="bg-white/10 border border-white/20 rounded-full px-4 py-2 backdrop-blur-sm flex items-center gap-2">
            <UserCheck className="w-4 h-4 text-emerald-300"/>
            <span className="text-sm font-medium text-white">24 / 50 Personel</span>
          </div>
          <div className="bg-white/10 border border-white/20 rounded-full px-4 py-2 backdrop-blur-sm flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-blue-300"/>
            <span className="text-sm font-medium text-white">Sistem Aktif</span>
          </div>
        </div>
      </div>

      {/* BÖLÜM 2: Ayar Kartları (Grid) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {settingsCards.map((card) => {
          const Icon = card.icon;
          return (
            <button 
              key={card.id}
              onClick={() => setActiveDialog(card.id)}
              className="bg-card border border-border hover:border-blue-500/40 hover:bg-blue-50/50 dark:hover:bg-blue-900/10 hover:shadow-sm active:scale-[0.98] transition-all duration-200 rounded-xl p-4 cursor-pointer group flex items-start gap-3 text-left w-full"
            >
              <div className={`p-2.5 rounded-lg shrink-0 ${card.bgColor} ${card.color} transition-transform group-hover:scale-105`}>
                <Icon className="w-5 h-5" />
              </div>
              <div className="flex-1 space-y-1">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold text-base text-foreground group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">{card.title}</h3>
                  <ChevronRight className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-all -translate-x-2 group-hover:translate-x-0" />
                </div>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  {card.description}
                </p>
              </div>
            </button>
          );
        })}
      </div>

      {/* BÖLÜM 3: Açılır Pencereler (Dialogs) */}
      <Dialog open={activeDialog !== null} onOpenChange={(open) => !open && setActiveDialog(null)}>
        <DialogContent className="sm:max-w-[500px] w-[95vw] rounded-2xl max-h-[90vh] overflow-y-auto">
          
          {/* İŞLETME PROFİLİ */}
          {activeDialog === "business" && (
            <>
              <DialogHeader>
                <DialogTitle className="text-xl">İşletme Profili</DialogTitle>
                <DialogDescription>İşletmenizin temel bilgilerini buradan güncelleyebilirsiniz.</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="companyName">İşletme Adı</Label>
                  <Input id="companyName" defaultValue="ABC Kafe & Restoran" className="h-10 rounded-xl" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="contactName">Yetkili Kişi</Label>
                    <Input id="contactName" defaultValue="Ahmet Yılmaz" className="h-10 rounded-xl" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Telefon Numarası</Label>
                    <Input id="phone" defaultValue="0532 123 45 67" className="h-10 rounded-xl" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">E-posta Adresi</Label>
                  <Input id="email" type="email" defaultValue="ahmet@abckafe.com" className="h-10 rounded-xl" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="address">Merkez Adres</Label>
                  <Input id="address" defaultValue="Kadıköy, İstanbul" className="h-10 rounded-xl" />
                </div>
              </div>
              <DialogFooter>
                <Button onClick={handleSave} className="w-full sm:w-auto rounded-xl h-10 px-8 bg-blue-600 hover:bg-blue-700">Kaydet</Button>
              </DialogFooter>
            </>
          )}

          {/* MESAİ VE KURALLAR */}
          {activeDialog === "rules" && (
            <>
              <DialogHeader>
                <DialogTitle className="text-xl">Mesai ve Kurallar</DialogTitle>
                <DialogDescription>Puantaj hesaplamalarında kullanılacak temel kuralları belirleyin.</DialogDescription>
              </DialogHeader>
              <div className="space-y-5 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Mesai Başlangıç</Label>
                    <Input type="time" defaultValue="09:00" className="h-10 rounded-xl" />
                  </div>
                  <div className="space-y-2">
                    <Label>Mesai Bitiş</Label>
                    <Input type="time" defaultValue="18:00" className="h-10 rounded-xl" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="flex items-center gap-2">
                    Geç Kalma Toleransı (Dakika)
                    <InfoBubble content="Bu süreyi aşmayan geç girişler sistemde 'Geç Kaldı' olarak işaretlenmez." />
                  </Label>
                  <div className="flex items-center gap-3">
                    <Input type="number" defaultValue="15" className="h-10 rounded-xl flex-1" />
                    <span className="text-sm text-muted-foreground w-24">dk&apos;ya kadar geç sayma</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="flex items-center gap-2">
                    Günlük Standart Çalışma
                    <InfoBubble content="Puantaj ve fazla mesai hesaplamalarında baz alınacak günlük çalışma süresi." />
                  </Label>
                  <div className="flex items-center gap-3">
                    <Input type="number" defaultValue="8" className="h-10 rounded-xl flex-1" />
                    <span className="text-sm text-muted-foreground w-24">saat</span>
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button onClick={handleSave} className="w-full sm:w-auto rounded-xl h-10 px-8 bg-blue-600 hover:bg-blue-700">Kuralları Kaydet</Button>
              </DialogFooter>
            </>
          )}

          {/* İZİN POLİTİKALARI */}
          {activeDialog === "leaves" && (
            <>
              <DialogHeader>
                <DialogTitle className="text-xl">İzin Politikaları</DialogTitle>
                <DialogDescription>Personel kıdemine göre yıllık izin hakediş günlerini belirleyin.</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="flex items-center justify-between gap-4 p-4 border rounded-xl bg-slate-50/50 dark:bg-slate-900/50">
                  <div className="flex-1">
                    <Label className="text-base">1 - 5 Yıl Arası</Label>
                    <p className="text-xs text-muted-foreground mt-1">1 yıldan 5 yıla kadar çalışanlar</p>
                  </div>
                  <div className="w-24 flex items-center gap-2">
                    <Input type="number" defaultValue="14" className="text-center h-10 rounded-lg" />
                    <span className="text-sm font-medium">Gün</span>
                  </div>
                </div>
                <div className="flex items-center justify-between gap-4 p-4 border rounded-xl bg-slate-50/50 dark:bg-slate-900/50">
                  <div className="flex-1">
                    <Label className="text-base">5 - 15 Yıl Arası</Label>
                    <p className="text-xs text-muted-foreground mt-1">5 yıldan 15 yıla kadar çalışanlar</p>
                  </div>
                  <div className="w-24 flex items-center gap-2">
                    <Input type="number" defaultValue="20" className="text-center h-10 rounded-lg" />
                    <span className="text-sm font-medium">Gün</span>
                  </div>
                </div>
                <div className="flex items-center justify-between gap-4 p-4 border rounded-xl bg-slate-50/50 dark:bg-slate-900/50">
                  <div className="flex-1">
                    <Label className="text-base">15 Yıl ve Üzeri</Label>
                    <p className="text-xs text-muted-foreground mt-1">15 yıldan fazla çalışanlar</p>
                  </div>
                  <div className="w-24 flex items-center gap-2">
                    <Input type="number" defaultValue="26" className="text-center h-10 rounded-lg" />
                    <span className="text-sm font-medium">Gün</span>
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button onClick={handleSave} className="w-full sm:w-auto rounded-xl h-10 px-8 bg-blue-600 hover:bg-blue-700">Politikaları Kaydet</Button>
              </DialogFooter>
            </>
          )}

          {/* BİLDİRİMLER */}
          {activeDialog === "notifications" && (
            <>
              <DialogHeader>
                <DialogTitle className="text-xl">Bildirim Ayarları</DialogTitle>
                <DialogDescription>Hangi durumlarda bildirim almak istediğinizi seçin.</DialogDescription>
              </DialogHeader>
              <div className="space-y-3 py-4">
                <div className="flex items-start sm:items-center justify-between p-4 border rounded-xl gap-4 hover:bg-slate-50 dark:hover:bg-slate-900/50 transition-colors cursor-pointer">
                  <div className="space-y-1 flex-1">
                    <Label className="text-base cursor-pointer flex items-center gap-2">
                      Günlük Özet Raporu
                      <InfoBubble content="Her gün saat 18:00'da o günün giriş-çıkış özetini e-posta ile alırsınız." />
                    </Label>
                    <p className="text-xs text-muted-foreground">Her gün mesai bitiminde personel durum özetini e-posta ile al.</p>
                  </div>
                  <input type="checkbox" className="w-5 h-5 accent-blue-600 flex-shrink-0 mt-1 sm:mt-0 cursor-pointer" defaultChecked />
                </div>
                <div className="flex items-start sm:items-center justify-between p-4 border rounded-xl gap-4 hover:bg-slate-50 dark:hover:bg-slate-900/50 transition-colors cursor-pointer">
                  <div className="space-y-1 flex-1">
                    <Label className="text-base cursor-pointer flex items-center gap-2">
                      İzin Talepleri
                      <InfoBubble content="Personel yeni bir izin talebi oluşturduğunda anında bildirim alırsınız." />
                    </Label>
                    <p className="text-xs text-muted-foreground">Yeni bir izin talebi oluşturulduğunda anında bildirim al.</p>
                  </div>
                  <input type="checkbox" className="w-5 h-5 accent-blue-600 flex-shrink-0 mt-1 sm:mt-0 cursor-pointer" defaultChecked />
                </div>
                <div className="flex items-start sm:items-center justify-between p-4 border rounded-xl gap-4 hover:bg-slate-50 dark:hover:bg-slate-900/50 transition-colors cursor-pointer">
                  <div className="space-y-1 flex-1">
                    <Label className="text-base cursor-pointer flex items-center gap-2">
                      Geç Kalma Uyarıları
                      <InfoBubble content="Bir personel belirlediğiniz tolerans süresini aştığında anında bildirim alırsınız." />
                    </Label>
                    <p className="text-xs text-muted-foreground">Bir personel tolerans süresinden daha geç giriş yaptığında uyar.</p>
                  </div>
                  <input type="checkbox" className="w-5 h-5 accent-blue-600 flex-shrink-0 mt-1 sm:mt-0 cursor-pointer" defaultChecked />
                </div>
              </div>
              <DialogFooter>
                <Button onClick={handleSave} className="w-full sm:w-auto rounded-xl h-10 px-8 bg-blue-600 hover:bg-blue-700">Tercihleri Kaydet</Button>
              </DialogFooter>
            </>
          )}

          {/* GÜVENLİK */}
          {activeDialog === "security" && (
            <>
              <DialogHeader>
                <DialogTitle className="text-xl">Güvenlik</DialogTitle>
                <DialogDescription>Hesap şifrenizi ve güvenlik önlemlerinizi güncelleyin.</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Label htmlFor="qrRefreshRate">QR Kod Yenileme Süresi (Saniye)</Label>
                    <InfoBubble content="Güvenlik amacıyla tablet/telefondaki QR kodun kaç saniyede bir değişeceğini belirler. Başkalarının kodu fotoğraf çekip kopyalamasını engeller." />
                  </div>
                  <Input id="qrRefreshRate" type="number" defaultValue="15" className="h-10 rounded-xl" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="currentPassword">Mevcut Şifre</Label>
                  <Input id="currentPassword" type="password" className="h-10 rounded-xl" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="newPassword">Yeni Şifre</Label>
                  <Input id="newPassword" type="password" className="h-10 rounded-xl" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="confirmPassword">Yeni Şifre (Tekrar)</Label>
                  <Input id="confirmPassword" type="password" className="h-10 rounded-xl" />
                </div>
              </div>
              <DialogFooter>
                <Button onClick={handleSave} className="w-full sm:w-auto rounded-xl h-10 px-8 bg-blue-600 hover:bg-blue-700">Şifreyi Güncelle</Button>
              </DialogFooter>
            </>
          )}

          {/* ABONELİK VE PLAN */}
          {activeDialog === "billing" && (
            <>
              <DialogHeader>
                <DialogTitle className="text-xl">Abonelik ve Plan</DialogTitle>
                <DialogDescription>Mevcut abonelik planınızı ve faturalarınızı görüntüleyin.</DialogDescription>
              </DialogHeader>
              <div className="space-y-5 py-4">
                <div className="p-5 bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-800 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div>
                    <h3 className="font-bold text-xl text-blue-700 dark:text-blue-400 mb-1">KOBİ Pro Planı</h3>
                    <p className="text-sm text-blue-600/80 dark:text-blue-300/80">50 Personele kadar yönetim imkanı.</p>
                  </div>
                  <Badge className="bg-emerald-500 hover:bg-emerald-600 text-white border-none px-3 py-1 text-sm">Aktif</Badge>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1 p-4 border rounded-2xl bg-card">
                    <span className="text-sm text-muted-foreground font-medium">Kayıtlı Personel</span>
                    <p className="font-bold text-2xl">24 <span className="text-base text-muted-foreground font-normal">/ 50</span></p>
                  </div>
                  <div className="space-y-1 p-4 border rounded-2xl bg-card">
                    <span className="text-sm text-muted-foreground font-medium">Yenilenme Tarihi</span>
                    <p className="font-bold text-xl">15.06.2026</p>
                  </div>
                </div>
              </div>
              <DialogFooter className="flex-col sm:flex-row gap-2">
                <Button variant="outline" onClick={() => setActiveDialog(null)} className="w-full sm:w-auto rounded-xl h-10">Kapat</Button>
                <Button className="w-full sm:w-auto rounded-xl h-10 px-8 bg-blue-600 hover:bg-blue-700">Planı Yükselt</Button>
              </DialogFooter>
            </>
          )}

        </DialogContent>
      </Dialog>
    </div>
  );
}
