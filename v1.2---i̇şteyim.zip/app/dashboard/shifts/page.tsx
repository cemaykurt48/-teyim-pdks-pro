"use client";

import { useState, useMemo } from "react";
import { 
  CalendarDays, Clock, Settings2, Users, Sun, Sunset, Moon, Coffee, 
  ArrowRightLeft, Save, AlertCircle, CheckCircle2, ChevronRight, ChevronLeft, Edit2,
  Plus, Trash2, Search, MapPin, ChevronDown, ChevronUp, Bell, CheckSquare
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { InfoBubble } from "@/components/info-bubble";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

// --- MOCK DATA ---
const branches = ["Tümü", "Merkez", "Kadıköy", "Şişli"];

const initialShiftTemplates = [
  { id: "morning", name: "Sabah", time: "08:00 - 16:00", color: "bg-blue-100 text-blue-700 border-blue-200", icon: Sun, iconColor: "text-blue-500" },
  { id: "evening", name: "Akşam", time: "16:00 - 00:00", color: "bg-orange-100 text-orange-700 border-orange-200", icon: Sunset, iconColor: "text-orange-500" },
  { id: "night", name: "Gece", time: "00:00 - 08:00", color: "bg-purple-100 text-purple-700 border-purple-200", icon: Moon, iconColor: "text-purple-500" },
  { id: "off", name: "Tatil", time: "İzinli", color: "bg-rose-100 text-rose-700 border-rose-200", icon: Coffee, iconColor: "text-rose-500" },
];

const initialRotations = [
  { 
    id: "rot_1", name: "Sabit Sabah", desc: "Sürekli sabah vardiyası", 
    rules: [{ id: 1, days: 6, shiftId: "morning" }, { id: 2, days: 1, shiftId: "off" }] 
  },
  { 
    id: "rot_2", name: "2 Gündüz 2 Gece", desc: "Güvenlik özel döngüsü", 
    rules: [{ id: 1, days: 2, shiftId: "morning" }, { id: 2, days: 2, shiftId: "night" }, { id: 3, days: 2, shiftId: "off" }] 
  },
];

const initialStaff = [
  { id: 1, name: "Ahmet Yılmaz", rotation: "rot_1", branch: "Merkez" },
  { id: 2, name: "Ayşe Kaya", rotation: "rot_2", branch: "Merkez" },
  { id: 3, name: "Mehmet Demir", rotation: "rot_2", branch: "Kadıköy" },
  { id: 4, name: "Fatma Çelik", rotation: "rot_1", branch: "Merkez" },
  { id: 5, name: "Ali Veli", rotation: "rot_2", branch: "Kadıköy" },
  { id: 6, name: "Zeynep Can", rotation: "rot_1", branch: "Şişli" },
  { id: 7, name: "Burak Yılmaz", rotation: "rot_2", branch: "Şişli" },
  { id: 8, name: "Cemre Su", rotation: "rot_1", branch: "Merkez" },
  { id: 9, name: "Deniz Arslan", rotation: "rot_2", branch: "Kadıköy" },
  { id: 10, name: "Efe Korkmaz", rotation: "rot_1", branch: "Şişli" },
  { id: 11, name: "Gizem Şahin", rotation: "rot_2", branch: "Merkez" },
  { id: 12, name: "Hakan Yıldız", rotation: "rot_1", branch: "Kadıköy" },
];

const daysOfWeek = ["Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz"];

// Mock schedule: staffId -> day -> { shiftId, branch }
const initialSchedule: Record<number, Record<string, { shiftId: string, branch: string }>> = {};
initialStaff.forEach(staff => {
  initialSchedule[staff.id] = {};
  daysOfWeek.forEach((day, idx) => {
    // Simple mock logic
    let shiftId = "morning";
    if (staff.rotation === "rot_2") {
      shiftId = idx % 3 === 0 ? "night" : idx % 3 === 1 ? "morning" : "off";
    } else {
      shiftId = day === "Paz" ? "off" : "morning";
    }
    initialSchedule[staff.id][day] = { shiftId, branch: staff.branch };
  });
});

export default function ShiftsPage() {
  const [schedule, setSchedule] = useState(initialSchedule);
  
  // Calendar Context
  const [currentWeekStart, setCurrentWeekStart] = useState(() => {
    const d = new Date();
    const day = d.getDay();
    const diff = d.getDate() - day + (day === 0 ? -6 : 1); // adjust when day is sunday
    return new Date(d.setDate(diff));
  });

  const weekDays = Array.from({ length: 7 }).map((_, i) => {
    const d = new Date(currentWeekStart);
    d.setDate(d.getDate() + i);
    return d;
  });

  const [selectedDay, setSelectedDay] = useState(() => {
    const today = new Date();
    const dayIndex = today.getDay() === 0 ? 6 : today.getDay() - 1;
    return daysOfWeek[dayIndex];
  });
  const [selectedBranch, setSelectedBranch] = useState("Tümü");
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("daily");

  const handlePrevWeek = () => {
    const newDate = new Date(currentWeekStart);
    newDate.setDate(newDate.getDate() - 7);
    setCurrentWeekStart(newDate);
  };

  const handleNextWeek = () => {
    const newDate = new Date(currentWeekStart);
    newDate.setDate(newDate.getDate() + 7);
    setCurrentWeekStart(newDate);
  };

  const handleToday = () => {
    const d = new Date();
    const day = d.getDay();
    const diff = d.getDate() - day + (day === 0 ? -6 : 1);
    setCurrentWeekStart(new Date(d.setDate(diff)));
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('tr-TR', { day: 'numeric', month: 'short' });
  };

  const formatDayName = (date: Date) => {
    return date.toLocaleDateString('tr-TR', { weekday: 'short' });
  };

  // Settings State
  const [shiftTemplates, setShiftTemplates] = useState(initialShiftTemplates);
  const [rotations, setRotations] = useState(initialRotations);
  
  // Dialog States
  const [isShiftSettingsOpen, setIsShiftSettingsOpen] = useState(false);
  const [isRotationSettingsOpen, setIsRotationSettingsOpen] = useState(false);
  const [editingRotation, setEditingRotation] = useState<any>(null);
  
  // Override Dialog State
  const [isOverrideOpen, setIsOverrideOpen] = useState(false);
  const [overrideStaff, setOverrideStaff] = useState<{id: number, name: string} | null>(null);
  const [overrideDay, setOverrideDay] = useState<string>("");
  const [overrideShift, setOverrideShift] = useState<string>("");
  const [overrideBranch, setOverrideBranch] = useState<string>("");

  // Bulk Assign Dialog State
  const [isBulkAssignOpen, setIsBulkAssignOpen] = useState(false);
  const [bulkAssignRotation, setBulkAssignRotation] = useState<any>(null);
  const [selectedStaffIds, setSelectedStaffIds] = useState<number[]>([]);
  const [bulkAssignSearchQuery, setBulkAssignSearchQuery] = useState("");
  const [bulkAssignBranchFilter, setBulkAssignBranchFilter] = useState("Tümü");

  // Accordion State for Daily View
  const [expandedShifts, setExpandedShifts] = useState<Record<string, boolean>>({
    "morning": true, "evening": true, "night": true, "off": false
  });

  const toggleAccordion = (shiftId: string) => {
    setExpandedShifts(prev => ({ ...prev, [shiftId]: !prev[shiftId] }));
  };

  const handleOverrideSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (overrideStaff && overrideDay && overrideShift && overrideBranch) {
      setSchedule(prev => ({
        ...prev,
        [overrideStaff.id]: {
          ...prev[overrideStaff.id],
          [overrideDay]: { shiftId: overrideShift, branch: overrideBranch }
        }
      }));
      toast.success(`${overrideStaff.name} için ${overrideDay} günü vardiyası güncellendi.`, {
        description: "Personele mobil bildirim gönderildi."
      });
      setIsOverrideOpen(false);
    }
  };

  const openOverrideDialog = (staffId: number, name: string, day: string, currentShift: string, currentBranch: string) => {
    setOverrideStaff({ id: staffId, name });
    setOverrideDay(day);
    setOverrideShift(currentShift);
    setOverrideBranch(currentBranch);
    setIsOverrideOpen(true);
  };

  const getShiftDetails = (shiftId: string) => {
    return shiftTemplates.find(s => s.id === shiftId) || shiftTemplates[0];
  };

  const handleAddShiftTemplate = () => {
    const newId = `shift_${Date.now()}`;
    setShiftTemplates([...shiftTemplates, {
      id: newId,
      name: "Yeni Vardiya",
      time: "08:00 - 16:00",
      color: "bg-slate-100 text-slate-700 border-slate-200",
      icon: Sun,
      iconColor: "text-slate-500"
    }]);
  };

  const handleUpdateShiftTemplate = (id: string, field: string, value: string) => {
    setShiftTemplates(shiftTemplates.map(s => s.id === id ? { ...s, [field]: value } : s));
  };

  // Rotation Builder Logic
  const handleAddRule = () => {
    if (!editingRotation) return;
    const newRule = { id: Date.now(), days: 1, shiftId: "morning" };
    setEditingRotation({ ...editingRotation, rules: [...editingRotation.rules, newRule] });
  };

  const handleRemoveRule = (ruleId: number) => {
    if (!editingRotation) return;
    setEditingRotation({ ...editingRotation, rules: editingRotation.rules.filter((r: any) => r.id !== ruleId) });
  };

  const handleUpdateRule = (ruleId: number, field: string, value: any) => {
    if (!editingRotation) return;
    setEditingRotation({
      ...editingRotation,
      rules: editingRotation.rules.map((r: any) => r.id === ruleId ? { ...r, [field]: value } : r)
    });
  };

  const handleSaveRotation = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingRotation.id) {
      setRotations(rotations.map(r => r.id === editingRotation.id ? editingRotation : r));
    } else {
      setRotations([...rotations, { ...editingRotation, id: `rot_${Date.now()}` }]);
    }
    toast.success("Döngü kuralı başarıyla kaydedildi.");
    setIsRotationSettingsOpen(false);
  };

  const openRotationDialog = (rot: any = null) => {
    // Prevent React events from being treated as rotation objects
    if (rot && (rot.nativeEvent || rot.target)) {
      rot = null;
    }

    if (rot) {
      try {
        setEditingRotation(JSON.parse(JSON.stringify(rot))); // Deep copy
      } catch (e) {
        console.error("Circular stringify error:", e);
        setEditingRotation({ name: String(rot.name || ""), desc: String(rot.desc || ""), rules: [{ id: Date.now(), days: 1, shiftId: "morning" }] });
      }
    } else {
      setEditingRotation({ name: "", desc: "", rules: [{ id: Date.now(), days: 1, shiftId: "morning" }] });
    }
    setIsRotationSettingsOpen(true);
  };

  // Bulk Assign Logic
  const openBulkAssignDialog = (rot: any) => {
    setBulkAssignRotation(rot);
    // Pre-select staff already in this rotation
    const currentlyAssigned = initialStaff.filter(s => s.rotation === rot.id).map(s => s.id);
    setSelectedStaffIds(currentlyAssigned);
    setIsBulkAssignOpen(true);
  };

  const toggleStaffSelection = (staffId: number) => {
    setSelectedStaffIds(prev => 
      prev.includes(staffId) ? prev.filter(id => id !== staffId) : [...prev, staffId]
    );
  };

  const handleBulkAssignSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success(`${selectedStaffIds.length} personel ${bulkAssignRotation.name} döngüsüne atandı.`, {
      description: "Sistem yeni takvimi otomatik olarak oluşturdu."
    });
    setIsBulkAssignOpen(false);
  };

  const handleSelectAllFiltered = () => {
    const filteredStaffIds = initialStaff.filter(staff => {
      if (bulkAssignBranchFilter !== "Tümü" && staff.branch !== bulkAssignBranchFilter) return false;
      if (bulkAssignSearchQuery && !staff.name.toLowerCase().includes(bulkAssignSearchQuery.toLowerCase())) return false;
      return true;
    }).map(s => s.id);

    const allSelected = filteredStaffIds.every(id => selectedStaffIds.includes(id));

    if (allSelected) {
      // Deselect all filtered
      setSelectedStaffIds(prev => prev.filter(id => !filteredStaffIds.includes(id)));
    } else {
      // Select all filtered
      setSelectedStaffIds(prev => {
        const newIds = new Set([...prev, ...filteredStaffIds]);
        return Array.from(newIds);
      });
    }
  };

  // Filtered Staff for Daily View
  const getFilteredStaffForShift = (shiftId: string) => {
    return initialStaff.filter(staff => {
      const staffDayInfo = schedule[staff.id][selectedDay];
      if (staffDayInfo.shiftId !== shiftId) return false;
      if (selectedBranch !== "Tümü" && staffDayInfo.branch !== selectedBranch) return false;
      if (searchQuery && !staff.name.toLowerCase().includes(searchQuery.toLowerCase())) return false;
      return true;
    });
  };

  return (
    <div className="space-y-6 pb-20 md:pb-0">
      
      {/* HEADER */}
      <div className="bg-gradient-to-br from-indigo-600 via-indigo-700 to-blue-800 text-white rounded-2xl p-6 flex flex-col gap-5 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 -mt-16 -mr-16 w-64 h-64 bg-white opacity-5 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 -mb-16 -ml-16 w-48 h-48 bg-indigo-400 opacity-10 rounded-full blur-2xl pointer-events-none"></div>

        <div className="relative z-10 flex flex-col md:flex-row md:items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <h2 className="text-2xl font-bold">Akıllı Vardiya Planlama</h2>
              <InfoBubble content="Personellerin çalışma döngülerini bir kez ayarlayın, sistem tüm takvimi otomatik oluştursun. Şubeler arası görevlendirme yapabilirsiniz." className="w-6 h-6 hover:bg-white/10" iconClassName="text-indigo-200 hover:text-white" />
            </div>
            <p className="text-indigo-100 text-sm md:text-base max-w-2xl">
              Dönüşümlü vardiyaları otomatik yönetin. Sadece gelmeyen veya başka şubeye kaydırılan personeller için istisna ekleyin.
            </p>
          </div>
          
          <div className="shrink-0">
            <Button className="bg-white text-indigo-700 hover:bg-indigo-50 border-none shadow-lg gap-2 font-semibold rounded-xl h-10 px-5" onClick={() => toast.success("Değişiklikler kaydedildi ve personellere bildirim gönderildi.")}>
              <Bell className="w-5 h-5" /> Planı Kaydet & Bildir
            </Button>
          </div>
        </div>
      </div>

      {activeTab !== "settings" && (
        <div className="flex flex-col gap-4 mb-4">
          {/* Week Navigator */}
          <div className="flex items-center justify-between bg-white dark:bg-slate-950 p-2 rounded-xl border shadow-sm">
            <Button variant="ghost" size="sm" onClick={handlePrevWeek} className="h-8 px-2 text-muted-foreground hover:text-slate-900 dark:hover:text-slate-100">
              <ChevronLeft className="w-4 h-4 mr-1" /> Önceki Hafta
            </Button>
            <div className="flex items-center gap-2">
              <CalendarDays className="w-4 h-4 text-indigo-600" />
              <span className="text-sm font-semibold">
                {formatDate(weekDays[0])} - {formatDate(weekDays[6])}
              </span>
            </div>
            <div className="flex items-center gap-1">
              <Button variant="ghost" size="sm" onClick={handleToday} className="h-8 px-2 text-indigo-600 hover:text-indigo-700 hover:bg-indigo-50 hidden sm:flex">
                Bugün
              </Button>
              <Button variant="ghost" size="sm" onClick={handleNextWeek} className="h-8 px-2 text-muted-foreground hover:text-slate-900 dark:hover:text-slate-100">
                Sonraki Hafta <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </div>
          </div>

          {/* Filters */}
          <div className="flex flex-col sm:flex-row gap-3 bg-card p-3 rounded-xl border shadow-sm">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input 
                placeholder="Personel Ara..." 
                className="pl-9 h-10 rounded-lg bg-slate-50 dark:bg-slate-900/50"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="w-full sm:w-48">
              <Select value={selectedBranch} onValueChange={(val) => val && setSelectedBranch(val)}>
                <SelectTrigger className="h-10 rounded-lg bg-slate-50 dark:bg-slate-900/50">
                  <MapPin className="w-4 h-4 mr-2 text-muted-foreground" />
                  <SelectValue placeholder="Şube Seç" />
                </SelectTrigger>
                <SelectContent>
                  {branches.map(b => <SelectItem key={b} value={b}>{b}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      )}

      <Tabs value={activeTab} onValueChange={(val) => val && setActiveTab(val as string)} className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-6 bg-slate-100/50 dark:bg-slate-800/50 p-1 rounded-xl">
          <TabsTrigger value="daily" className="rounded-lg data-[state=active]:bg-white dark:data-[state=active]:bg-slate-950 data-[state=active]:shadow-sm">
            <CalendarDays className="w-4 h-4 mr-2" />
            <span className="hidden sm:inline">Günlük Görünüm</span>
            <span className="sm:hidden">Günlük</span>
          </TabsTrigger>
          <TabsTrigger value="weekly" className="rounded-lg data-[state=active]:bg-white dark:data-[state=active]:bg-slate-950 data-[state=active]:shadow-sm">
            <Clock className="w-4 h-4 mr-2" />
            <span className="hidden sm:inline">Haftalık Tablo</span>
            <span className="sm:hidden">Haftalık</span>
          </TabsTrigger>
          <TabsTrigger value="settings" className="rounded-lg data-[state=active]:bg-white dark:data-[state=active]:bg-slate-950 data-[state=active]:shadow-sm">
            <Settings2 className="w-4 h-4 mr-2" />
            <span className="hidden sm:inline">Döngü Ayarları</span>
            <span className="sm:hidden">Ayarlar</span>
          </TabsTrigger>
        </TabsList>

        {/* DAILY VIEW (LARGE ENTERPRISE READY) */}
        <TabsContent value="daily" className="space-y-4 animate-in fade-in-50 duration-300">
          
          {/* Day Selector */}
          <div className="flex items-center justify-between bg-card p-2 rounded-xl border shadow-sm overflow-x-auto">
            {weekDays.map((date, idx) => {
              const dayKey = daysOfWeek[idx];
              return (
                <button
                  key={dayKey}
                  onClick={() => setSelectedDay(dayKey)}
                  className={cn(
                    "flex flex-col items-center justify-center flex-1 py-2 px-2 rounded-lg transition-all min-w-[60px]",
                    selectedDay === dayKey 
                      ? "bg-indigo-100 text-indigo-700 dark:bg-indigo-900/50 dark:text-indigo-300" 
                      : "text-muted-foreground hover:bg-slate-100 dark:hover:bg-slate-800"
                  )}
                >
                  <span className="text-xs font-medium uppercase">{formatDayName(date)}</span>
                  <span className="text-lg font-bold leading-none mt-1">{date.getDate()}</span>
                </button>
              );
            })}
          </div>

          {/* Accordion Shift Lists */}
          <div className="space-y-3">
            {shiftTemplates.map(shift => {
              const staffInThisShift = getFilteredStaffForShift(shift.id);
              const Icon = shift.icon;
              const isExpanded = expandedShifts[shift.id];

              return (
                <Card key={shift.id} className="border-l-4 shadow-sm overflow-hidden transition-all" style={{ borderLeftColor: shift.id === 'morning' ? '#3b82f6' : shift.id === 'evening' ? '#f97316' : shift.id === 'night' ? '#a855f7' : '#f43f5e' }}>
                  <div 
                    className="flex items-center justify-between p-4 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-900/50 transition-colors"
                    onClick={() => toggleAccordion(shift.id)}
                  >
                    <div className="flex items-center gap-3">
                      <div className={cn("w-10 h-10 rounded-full flex items-center justify-center", shift.color.split(' ')[0])}>
                        <Icon className={cn("w-5 h-5", shift.iconColor)} />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg flex items-center gap-2">
                          {shift.name} Vardiyası
                          <Badge variant="secondary" className="ml-2">{staffInThisShift.length} Kişi</Badge>
                        </h3>
                        <p className="text-sm text-muted-foreground">{shift.time}</p>
                      </div>
                    </div>
                    {isExpanded ? <ChevronUp className="w-5 h-5 text-muted-foreground" /> : <ChevronDown className="w-5 h-5 text-muted-foreground" />}
                  </div>

                  {isExpanded && (
                    <div className="border-t bg-slate-50/30 dark:bg-slate-900/10 p-4">
                      {staffInThisShift.length === 0 ? (
                        <p className="text-sm text-muted-foreground text-center py-4">Bu vardiyada/şubede personel bulunamadı.</p>
                      ) : (
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                          {staffInThisShift.map(staff => {
                            const staffDayInfo = schedule[staff.id][selectedDay];
                            const isTransferred = staff.branch !== staffDayInfo.branch;
                            return (
                              <div key={staff.id} className="flex items-center justify-between p-3 bg-white dark:bg-slate-950 rounded-xl border shadow-sm">
                                <div>
                                  <p className="font-medium text-sm">{staff.name}</p>
                                  <div className="flex items-center gap-1 mt-1">
                                    <MapPin className={cn("w-3 h-3", isTransferred ? "text-amber-500" : "text-muted-foreground")} />
                                    <span className={cn("text-xs", isTransferred ? "text-amber-600 font-medium" : "text-muted-foreground")}>
                                      {staffDayInfo.branch} {isTransferred && "(Joker)"}
                                    </span>
                                  </div>
                                </div>
                                <Button 
                                  variant="ghost" 
                                  size="sm" 
                                  className="h-8 w-8 p-0 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50"
                                  onClick={() => openOverrideDialog(staff.id, staff.name, selectedDay, shift.id, staffDayInfo.branch)}
                                >
                                  <ArrowRightLeft className="w-4 h-4" />
                                </Button>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  )}
                </Card>
              );
            })}
          </div>
        </TabsContent>

        {/* WEEKLY VIEW (DESKTOP MATRIX) */}
        <TabsContent value="weekly" className="animate-in fade-in-50 duration-300">
          <Card className="shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="text-xs text-muted-foreground uppercase bg-slate-50 dark:bg-slate-900/50 border-b">
                  <tr>
                    <th className="px-4 py-3 font-medium">Personel</th>
                    {weekDays.map((date, idx) => (
                      <th key={idx} className="px-4 py-3 font-medium text-center">
                        <div className="flex flex-col items-center">
                          <span className="text-[10px]">{formatDayName(date)}</span>
                          <span className="text-sm font-bold text-slate-700 dark:text-slate-300">{date.getDate()}</span>
                        </div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {initialStaff.filter(staff => {
                    if (selectedBranch !== "Tümü" && staff.branch !== selectedBranch) return false;
                    if (searchQuery && !staff.name.toLowerCase().includes(searchQuery.toLowerCase())) return false;
                    return true;
                  }).map(staff => (
                    <tr key={staff.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/50 transition-colors">
                      <td className="px-4 py-3 font-medium">
                        {staff.name}
                        <div className="text-[10px] text-muted-foreground font-normal">{staff.branch}</div>
                      </td>
                      {daysOfWeek.map(day => {
                        const dayInfo = schedule[staff.id][day];
                        const shift = getShiftDetails(dayInfo.shiftId);
                        const Icon = shift.icon;
                        const isTransferred = staff.branch !== dayInfo.branch;
                        
                        return (
                          <td key={day} className="px-2 py-2 text-center">
                            <button
                              onClick={() => openOverrideDialog(staff.id, staff.name, day, dayInfo.shiftId, dayInfo.branch)}
                              className={cn(
                                "w-full flex flex-col items-center justify-center gap-1 p-2 rounded-lg border transition-all hover:opacity-80 relative",
                                shift.color,
                                isTransferred && "ring-2 ring-amber-400 ring-offset-1"
                              )}
                            >
                              {isTransferred && <div className="absolute -top-1 -right-1 w-3 h-3 bg-amber-500 rounded-full border-2 border-white"></div>}
                              <Icon className="w-4 h-4" />
                              <span className="text-[10px] font-semibold leading-none">{shift.name}</span>
                            </button>
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                  {initialStaff.filter(staff => {
                    if (selectedBranch !== "Tümü" && staff.branch !== selectedBranch) return false;
                    if (searchQuery && !staff.name.toLowerCase().includes(searchQuery.toLowerCase())) return false;
                    return true;
                  }).length === 0 && (
                    <tr>
                      <td colSpan={8} className="px-4 py-8 text-center text-muted-foreground">
                        Bu kriterlere uygun personel bulunamadı.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </Card>
          <div className="mt-4 flex items-center gap-2 text-sm text-muted-foreground">
            <InfoBubble content="Tablodaki herhangi bir güne tıklayarak sadece o gün için personelin vardiyasını veya şubesini değiştirebilirsiniz." />
            <span>İstisna eklemek veya şube değiştirmek için tablodaki kutucuklara tıklayın. Sarı noktalı kutular, personelin başka şubeye kaydırıldığını gösterir.</span>
          </div>
        </TabsContent>

        {/* SETTINGS VIEW */}
        <TabsContent value="settings" className="space-y-6 animate-in fade-in-50 duration-300">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* Shift Templates */}
            <Card className="shadow-sm">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-lg">Vardiya Şablonları</CardTitle>
                    <CardDescription>İşletmenizdeki temel çalışma saatleri</CardDescription>
                  </div>
                  <Button variant="outline" size="sm" className="h-8 gap-1 rounded-lg" onClick={() => setIsShiftSettingsOpen(true)}>
                    <Edit2 className="w-3 h-3" /> Düzenle
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {shiftTemplates.map(shift => {
                  const Icon = shift.icon;
                  return (
                    <div key={shift.id} className="flex items-center justify-between p-3 border rounded-xl">
                      <div className="flex items-center gap-3">
                        <div className={cn("w-10 h-10 rounded-full flex items-center justify-center", shift.color.split(' ')[0])}>
                          <Icon className={cn("w-5 h-5", shift.iconColor)} />
                        </div>
                        <div>
                          <p className="font-semibold">{shift.name}</p>
                          <p className="text-sm text-muted-foreground">{shift.time}</p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </CardContent>
            </Card>

            {/* Rotation Rules */}
            <Card className="shadow-sm">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <CardTitle className="text-lg">Otomatik Döngüler</CardTitle>
                      <InfoBubble content="Personelleri bu döngülere atadığınızda, sistem haftalık/aylık takvimlerini otomatik olarak çizer." />
                    </div>
                    <CardDescription>Personellerin çalışma rotasyonları</CardDescription>
                  </div>
                  <Button variant="outline" size="sm" className="h-8 gap-1 rounded-lg" onClick={() => openRotationDialog()}>
                    <Plus className="w-3 h-3" /> Yeni Döngü
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {rotations.map(rot => (
                  <div key={rot.id} className="p-4 border rounded-xl hover:bg-slate-50 dark:hover:bg-slate-900/50 transition-colors flex flex-col gap-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-semibold text-base">{rot.name}</p>
                        <p className="text-xs text-muted-foreground mt-0.5">{rot.desc}</p>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="ghost" size="sm" className="h-8 px-2 text-indigo-600 bg-indigo-50 hover:bg-indigo-100" onClick={() => openBulkAssignDialog(rot)}>
                          <Users className="w-4 h-4 mr-1" /> Kişiler
                        </Button>
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={() => openRotationDialog(rot)}>
                          <Edit2 className="w-4 h-4 text-slate-400" />
                        </Button>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {rot.rules.map((rule, idx) => {
                        const shift = getShiftDetails(rule.shiftId);
                        return (
                          <div key={idx} className="flex items-center gap-1">
                            <Badge variant="outline" className={cn("text-xs font-normal", shift.color)}>
                              {rule.days} Gün {shift.name}
                            </Badge>
                            {idx < rot.rules.length - 1 && <ArrowRightLeft className="w-3 h-3 text-slate-300 mx-0.5" />}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

          </div>
        </TabsContent>
      </Tabs>

      {/* OVERRIDE DIALOG (WITH BRANCH SELECTION) */}
      <Dialog open={isOverrideOpen} onOpenChange={setIsOverrideOpen}>
        <DialogContent className="sm:max-w-[400px] rounded-2xl">
          <DialogHeader>
            <DialogTitle>Vardiya & Şube Değişikliği</DialogTitle>
            <DialogDescription>
              {overrideStaff?.name} için <strong>{overrideDay}</strong> gününün planını değiştiriyorsunuz. Bu değişiklik otomatik döngüyü bozmaz.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleOverrideSubmit} className="space-y-4 mt-4">
            <div className="space-y-3">
              <Label>Hangi Şubede Çalışacak?</Label>
              <Select value={overrideBranch} onValueChange={(val) => val && setOverrideBranch(val)}>
                <SelectTrigger className="h-10 rounded-xl">
                  <MapPin className="w-4 h-4 mr-2 text-muted-foreground" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {branches.filter(b => b !== "Tümü").map(b => <SelectItem key={b} value={b}>{b}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-3 pt-2">
              <Label>Hangi Vardiyada Çalışacak?</Label>
              <div className="grid grid-cols-2 gap-2">
                {shiftTemplates.map(shift => {
                  const Icon = shift.icon;
                  const isSelected = overrideShift === shift.id;
                  return (
                    <div 
                      key={shift.id}
                      onClick={() => setOverrideShift(shift.id)}
                      className={cn(
                        "flex flex-col items-center justify-center gap-2 p-3 rounded-xl border-2 cursor-pointer transition-all",
                        isSelected ? "border-indigo-600 bg-indigo-50 dark:bg-indigo-900/20" : "border-transparent bg-slate-50 dark:bg-slate-900/50 hover:bg-slate-100 dark:hover:bg-slate-800"
                      )}
                    >
                      <Icon className={cn("w-6 h-6", isSelected ? "text-indigo-600" : "text-slate-400")} />
                      <span className={cn("text-sm font-medium", isSelected ? "text-indigo-700 dark:text-indigo-300" : "text-slate-600 dark:text-slate-400")}>
                        {shift.name}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
            <DialogFooter className="pt-4">
              <Button type="button" variant="outline" className="rounded-xl h-10" onClick={() => setIsOverrideOpen(false)}>İptal</Button>
              <Button type="submit" className="rounded-xl h-10 bg-indigo-600 hover:bg-indigo-700 text-white">Değişikliği Kaydet</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* SHIFT SETTINGS DIALOG */}
      <Dialog open={isShiftSettingsOpen} onOpenChange={setIsShiftSettingsOpen}>
        <DialogContent className="sm:max-w-[500px] rounded-2xl">
          <DialogHeader>
            <DialogTitle>Vardiya Şablonlarını Düzenle</DialogTitle>
            <DialogDescription>
              İşletmenizdeki temel vardiya saatlerini buradan güncelleyebilirsiniz.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={(e) => { e.preventDefault(); setIsShiftSettingsOpen(false); toast.success("Şablonlar güncellendi."); }} className="space-y-4 mt-4">
            <div className="space-y-4 max-h-[50vh] overflow-y-auto pr-2">
              {shiftTemplates.map((shift) => {
                const Icon = shift.icon;
                return (
                  <div key={shift.id} className="p-4 border rounded-xl space-y-3 bg-slate-50/50 dark:bg-slate-900/20">
                    <div className="flex items-center gap-2 mb-2">
                      <div className={cn("w-8 h-8 rounded-full flex items-center justify-center", shift.color.split(' ')[0])}>
                        <Icon className={cn("w-4 h-4", shift.iconColor)} />
                      </div>
                      <Input 
                        value={shift.name} 
                        onChange={(e) => handleUpdateShiftTemplate(shift.id, 'name', e.target.value)}
                        className="font-semibold h-8"
                      />
                    </div>
                    {shift.id !== "off" && (
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <Label className="text-xs">Başlangıç Saati</Label>
                          <Input 
                            type="time" 
                            value={shift.time.split(" - ")[0] || "08:00"} 
                            onChange={(e) => handleUpdateShiftTemplate(shift.id, 'time', `${e.target.value} - ${shift.time.split(" - ")[1] || "16:00"}`)}
                            className="h-9" 
                          />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs">Bitiş Saati</Label>
                          <Input 
                            type="time" 
                            value={shift.time.split(" - ")[1] || "16:00"} 
                            onChange={(e) => handleUpdateShiftTemplate(shift.id, 'time', `${shift.time.split(" - ")[0] || "08:00"} - ${e.target.value}`)}
                            className="h-9" 
                          />
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
              <Button type="button" variant="outline" className="w-full h-10 border-dashed gap-2 text-indigo-600 border-indigo-200 hover:bg-indigo-50" onClick={handleAddShiftTemplate}>
                <Plus className="w-4 h-4" /> Yeni Şablon Ekle
              </Button>
            </div>
            <DialogFooter className="pt-4">
              <Button type="button" variant="outline" className="rounded-xl h-10" onClick={() => setIsShiftSettingsOpen(false)}>İptal</Button>
              <Button type="submit" className="rounded-xl h-10 bg-indigo-600 hover:bg-indigo-700 text-white">Şablonları Kaydet</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* ROTATION SETTINGS DIALOG (RULE BASED) */}
      <Dialog open={isRotationSettingsOpen} onOpenChange={setIsRotationSettingsOpen}>
        <DialogContent className="sm:max-w-[500px] rounded-2xl max-h-[90vh] flex flex-col">
          <DialogHeader className="shrink-0">
            <DialogTitle>{editingRotation?.id ? "Döngüyü Düzenle" : "Yeni Döngü Oluştur"}</DialogTitle>
            <DialogDescription>
              Personellerin çalışma düzenini belirleyen kuralları ekleyin.
            </DialogDescription>
          </DialogHeader>
          {editingRotation && (
            <form onSubmit={handleSaveRotation} className="flex flex-col overflow-hidden mt-2">
              <div className="space-y-4 overflow-y-auto pr-2 pb-2">
                <div className="space-y-2">
                  <Label>Döngü Adı</Label>
                  <Input 
                    value={editingRotation.name} 
                    onChange={e => setEditingRotation({...editingRotation, name: e.target.value})}
                    placeholder="Örn: 2 Gündüz 2 Gece" required className="h-10 rounded-xl" 
                  />
                </div>
                <div className="space-y-2">
                  <Label>Açıklama (İsteğe Bağlı)</Label>
                  <Input 
                    value={editingRotation.desc} 
                    onChange={e => setEditingRotation({...editingRotation, desc: e.target.value})}
                    placeholder="Örn: Güvenlik personeli için özel döngü" className="h-10 rounded-xl" 
                  />
                </div>
                
                <div className="space-y-3 pt-2">
                  <div className="flex items-center justify-between">
                    <Label>Döngü Kuralları</Label>
                    <InfoBubble content="Sırasıyla kaç gün hangi vardiyada çalışılacağını ekleyin. Kurallar bittiğinde sistem otomatik başa sarar." />
                  </div>
                  
                  <div className="space-y-2 bg-slate-50 dark:bg-slate-900/50 p-3 rounded-xl border">
                    {editingRotation.rules.map((rule: any, index: number) => (
                      <div key={rule.id} className="flex items-center gap-2 bg-white dark:bg-slate-950 p-2 rounded-lg border shadow-sm">
                        <Badge variant="secondary" className="w-6 h-6 rounded-full flex items-center justify-center p-0 shrink-0">{index + 1}</Badge>
                        <Input 
                          type="number" 
                          min="1" 
                          value={rule.days} 
                          onChange={e => handleUpdateRule(rule.id, 'days', parseInt(e.target.value) || 1)}
                          className="w-16 h-9 text-center" 
                        />
                        <span className="text-sm font-medium text-muted-foreground">Gün</span>
                        <Select value={rule.shiftId} onValueChange={val => val && handleUpdateRule(rule.id, 'shiftId', val)}>
                          <SelectTrigger className="h-9 flex-1">
                            {getShiftDetails(rule.shiftId).name}
                          </SelectTrigger>
                          <SelectContent>
                            {shiftTemplates.map(s => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                          </SelectContent>
                        </Select>
                        <Button type="button" variant="ghost" size="icon" className="h-9 w-9 text-rose-500 shrink-0 hover:bg-rose-50" onClick={() => handleRemoveRule(rule.id)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                    
                    <Button type="button" variant="outline" className="w-full h-9 mt-2 border-dashed gap-2 text-indigo-600 border-indigo-200 hover:bg-indigo-50" onClick={handleAddRule}>
                      <Plus className="w-4 h-4" /> Yeni Kural Ekle
                    </Button>
                  </div>
                  
                  {/* Preview Text */}
                  <div className="text-xs text-muted-foreground bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg border border-blue-100 dark:border-blue-800">
                    <strong>Sistem Özeti: </strong>
                    Personel sırasıyla {editingRotation.rules.map((r:any) => `${r.days} gün ${getShiftDetails(r.shiftId).name}`).join(', ')} yapacak ve bu döngü sürekli tekrarlanacak.
                  </div>
                </div>
              </div>
              <DialogFooter className="pt-4 shrink-0 flex items-center justify-between sm:justify-between border-t mt-2">
                {editingRotation.id ? (
                  <Button type="button" variant="ghost" className="text-rose-600 hover:text-rose-700 hover:bg-rose-50 px-2">
                    <Trash2 className="w-4 h-4 mr-2" /> Döngüyü Sil
                  </Button>
                ) : <div></div>}
                <div className="flex gap-2">
                  <Button type="button" variant="outline" className="rounded-xl h-10" onClick={() => setIsRotationSettingsOpen(false)}>İptal</Button>
                  <Button type="submit" className="rounded-xl h-10 bg-indigo-600 hover:bg-indigo-700 text-white">Kaydet</Button>
                </div>
              </DialogFooter>
            </form>
          )}
        </DialogContent>
      </Dialog>

      {/* BULK ASSIGN DIALOG (WHATSAPP STYLE) */}
      <Dialog open={isBulkAssignOpen} onOpenChange={setIsBulkAssignOpen}>
        <DialogContent className="sm:max-w-[500px] rounded-2xl max-h-[90vh] flex flex-col">
          <DialogHeader className="shrink-0">
            <DialogTitle>Personel Ata: {bulkAssignRotation?.name}</DialogTitle>
            <DialogDescription>
              Bu döngüde çalışacak personelleri seçin. Seçilen personellerin takvimi otomatik olarak bu döngüye göre yeniden oluşturulacaktır.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleBulkAssignSubmit} className="flex flex-col overflow-hidden mt-2">
            <div className="flex gap-2 shrink-0 mb-3">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input 
                  placeholder="Personel Ara..." 
                  className="pl-9 h-10 rounded-xl bg-slate-50 dark:bg-slate-900/50" 
                  value={bulkAssignSearchQuery}
                  onChange={(e) => setBulkAssignSearchQuery(e.target.value)}
                />
              </div>
              <Select value={bulkAssignBranchFilter} onValueChange={(val) => val && setBulkAssignBranchFilter(val)}>
                <SelectTrigger className="w-[140px] h-10 rounded-xl bg-slate-50 dark:bg-slate-900/50">
                  <SelectValue placeholder="Şube" />
                </SelectTrigger>
                <SelectContent>
                  {branches.map(b => <SelectItem key={b} value={b}>{b}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-center justify-between px-1 mb-2 shrink-0">
              <span className="text-xs font-medium text-muted-foreground">Personel Listesi</span>
              <Button type="button" variant="ghost" size="sm" className="h-7 text-xs text-indigo-600 hover:text-indigo-700 hover:bg-indigo-50" onClick={handleSelectAllFiltered}>
                Tümünü Seç / Kaldır
              </Button>
            </div>

            <div className="border rounded-xl overflow-hidden overflow-y-auto flex-1 mb-3">
              {initialStaff.filter(staff => {
                if (bulkAssignBranchFilter !== "Tümü" && staff.branch !== bulkAssignBranchFilter) return false;
                if (bulkAssignSearchQuery && !staff.name.toLowerCase().includes(bulkAssignSearchQuery.toLowerCase())) return false;
                return true;
              }).map(staff => {
                const isSelected = selectedStaffIds.includes(staff.id);
                return (
                  <div 
                    key={staff.id} 
                    className={cn(
                      "flex items-center gap-3 p-3 border-b last:border-0 cursor-pointer transition-colors",
                      isSelected ? "bg-indigo-50/50 dark:bg-indigo-900/10" : "hover:bg-slate-50 dark:hover:bg-slate-900/50"
                    )}
                    onClick={() => toggleStaffSelection(staff.id)}
                  >
                    <div className={cn(
                      "w-5 h-5 rounded border flex items-center justify-center shrink-0 transition-colors",
                      isSelected ? "bg-indigo-600 border-indigo-600 text-white" : "border-slate-300 dark:border-slate-600"
                    )}>
                      {isSelected && <CheckSquare className="w-3.5 h-3.5" />}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-sm">{staff.name}</p>
                      <p className="text-xs text-muted-foreground">{staff.branch}</p>
                    </div>
                    {staff.rotation === bulkAssignRotation?.id && (
                      <Badge variant="secondary" className="text-[10px]">Mevcut</Badge>
                    )}
                  </div>
                );
              })}
              {initialStaff.filter(staff => {
                if (bulkAssignBranchFilter !== "Tümü" && staff.branch !== bulkAssignBranchFilter) return false;
                if (bulkAssignSearchQuery && !staff.name.toLowerCase().includes(bulkAssignSearchQuery.toLowerCase())) return false;
                return true;
              }).length === 0 && (
                <div className="p-8 text-center text-muted-foreground text-sm">
                  Kriterlere uygun personel bulunamadı.
                </div>
              )}
            </div>
            
            <div className="flex items-center justify-between shrink-0 pt-2 border-t">
              <span className="text-sm font-medium text-indigo-600 dark:text-indigo-400">
                {selectedStaffIds.length} Personel Seçildi
              </span>
              <div className="flex gap-2">
                <Button type="button" variant="outline" className="rounded-xl h-10" onClick={() => setIsBulkAssignOpen(false)}>İptal</Button>
                <Button type="submit" className="rounded-xl h-10 bg-indigo-600 hover:bg-indigo-700 text-white">Uygula</Button>
              </div>
            </div>
          </form>
        </DialogContent>
      </Dialog>

    </div>
  );
}
