"use client";

import React, { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CalendarPlus, History, Search, Check, X, ChevronDown, Edit2, CalendarDays, AlertCircle, Clock, FileText, ChevronLeft, ChevronRight, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { InfoBubble } from "@/components/info-bubble";
import { toast } from "sonner";

// --- MOCK DATA ---
const allPersonnel = [
  "Ahmet Yılmaz", "Ali Demir", "Ayşe Kaya", "Ayşe Yılmaz", "Burak Yılmaz", "Canan Öz", 
  "Elif Demir", "Fatma Kaya", "Hasan Kaya", "Hüseyin Demir", "Kemal Yılmaz", "Lale Öz", 
  "Mehmet Demir", "Murat Kaya", "Mustafa Demir", "Nedim Demir", "Orhan Yılmaz", "Pelin Öz", 
  "Rıza Kaya", "Sevgi Demir", "Tarkan Yılmaz", "Veli Yılmaz", "Zeynep Kaya"
];

const pendingLeaves = [
  { id: 1, user: "Burak Yılmaz", type: "Mazeret İzni", date: "Yarın (Yarım Gün)", note: "Hastane randevusu" },
  { id: 2, user: "Elif Demir", type: "Yıllık İzin", date: "12-15 Nisan (3 Gün)", note: "Şehir dışı seyahat" },
];

const personnelBalances = allPersonnel.map((name, index) => ({
  id: index + 1,
  name,
  remainingDays: Math.floor(Math.random() * 20) + 1, // 1 ile 20 arası rastgele gün
  usedDays: Math.floor(Math.random() * 10),
}));

const pastLeavesData = [
  { id: 1, user: "Ahmet Yılmaz", type: "Yıllık İzin", date: "1-5 Mart 2026", days: 5, status: "Kullanıldı" },
  { id: 2, user: "Canan Öz", type: "Mazeret İzni", date: "10 Mart 2026", days: 1, status: "Kullanıldı" },
  { id: 3, user: "Mehmet Demir", type: "Sağlık Raporu", date: "15-16 Mart 2026", days: 2, status: "Kullanıldı" },
  { id: 4, user: "Ayşe Kaya", type: "Yıllık İzin", date: "20-25 Mart 2026", days: 6, status: "Kullanıldı" },
];

export default function LeavesManagementPage() {
  // Arama State'leri
  const [mainSearchQuery, setMainSearchQuery] = useState("");
  
  // Sayfalama State'i
  const [currentPage, setCurrentPage] = useState(1);
  const ITEMS_PER_PAGE = 6; // Her sayfada 6 personel kartı gösterilecek (2 satır x 3 sütun)
  
  // Yeni İzin Modal State'leri
  const [newLeaveSearchQuery, setNewLeaveSearchQuery] = useState("");
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [selectedPerson, setSelectedPerson] = useState("");
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Hakkı Düzenle State'i
  const [editBalanceValue, setEditBalanceValue] = useState("");

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const filteredMainPersonnel = personnelBalances.filter(p => p.name.toLowerCase().includes(mainSearchQuery.toLowerCase()));

  // Sayfalama Hesaplamaları
  const totalPages = Math.ceil(filteredMainPersonnel.length / ITEMS_PER_PAGE);
  const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
  const currentPersonnel = filteredMainPersonnel.slice(startIndex, startIndex + ITEMS_PER_PAGE);

  const filteredDropdownPersonnel = allPersonnel.filter(p => p.toLowerCase().includes(newLeaveSearchQuery.toLowerCase()));

  const handleApproveLeave = (id: number) => {
    toast.success("İzin başarıyla onaylandı.");
  };

  const handleRejectLeave = (id: number) => {
    toast.error("İzin reddedildi.");
  };

  const handleSubmitManualLeave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPerson) {
      toast.error("Lütfen bir personel seçin.");
      return;
    }
    toast.success(`${selectedPerson} için izin sisteme işlendi.`);
    setSelectedPerson("");
  };

  const handleUpdateBalance = (e: React.FormEvent, name: string) => {
    e.preventDefault();
    toast.success(`${name} adlı personelin izin hakkı güncellendi.`);
  };

  return (
    <div className="space-y-8 pb-20 md:pb-0">
      
      {/* BÖLÜM 1: Üst Kısım (Özet ve Hızlı Aksiyonlar) */}
      <div className="bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 text-white rounded-2xl p-6 md:p-8 flex flex-col gap-6 shadow-xl relative overflow-hidden">
        {/* Dekoratif Arka Plan Efektleri */}
        <div className="absolute top-0 right-0 -mt-16 -mr-16 w-64 h-64 bg-white opacity-5 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 -mb-16 -ml-16 w-48 h-48 bg-blue-400 opacity-10 rounded-full blur-2xl pointer-events-none"></div>

        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-2">
            <h2 className="text-2xl md:text-3xl font-bold">İzin Yönetimi</h2>
            <InfoBubble content="Personellerinizin izin taleplerini onaylayabilir, reddedebilir veya manuel olarak yeni izin ekleyebilirsiniz." className="w-6 h-6 hover:bg-white/10" iconClassName="text-blue-200 hover:text-white" />
          </div>
          <p className="text-blue-100 text-base md:text-lg max-w-2xl">
            Şu an <strong className="text-white font-semibold">2 personel</strong> izinli. Onayınızı bekleyen <strong className="text-amber-300 font-semibold">{pendingLeaves.length} yeni talep</strong> var.
          </p>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 md:gap-4 relative z-10 mt-2">
          {/* Yeni İzin Gir Butonu & Modalı */}
          <Dialog>
            <DialogTrigger className="flex items-center justify-center gap-3 bg-white text-blue-700 hover:bg-blue-50 transition-colors rounded-xl p-4 text-left cursor-pointer shadow-lg font-semibold text-lg">
              <CalendarPlus className="w-6 h-6" />
              Yeni İzin Gir
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>Manuel İzin Ekle</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmitManualLeave} className="space-y-4 mt-4">
                <div className="space-y-2 relative" ref={dropdownRef}>
                  <Label>Personel Seçin</Label>
                  <div 
                    className="flex h-10 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-900 transition-colors"
                    onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                  >
                    <span className={selectedPerson ? "text-foreground font-medium" : "text-muted-foreground"}>
                      {selectedPerson || "Personel ara veya seçin..."}
                    </span>
                    <ChevronDown className="w-4 h-4 opacity-50" />
                  </div>
                  
                  {isDropdownOpen && (
                    <div className="absolute z-50 w-full mt-1 bg-background border rounded-md shadow-lg overflow-hidden">
                      <div className="flex items-center border-b px-3 py-2 bg-slate-50 dark:bg-slate-900/50">
                        <Search className="w-4 h-4 text-muted-foreground mr-2" />
                        <input 
                          type="text" 
                          className="flex-1 bg-transparent outline-none text-sm" 
                          placeholder="İsim yazarak arayın..." 
                          value={newLeaveSearchQuery}
                          onChange={(e) => setNewLeaveSearchQuery(e.target.value)}
                          autoFocus
                        />
                      </div>
                      <div className="max-h-[180px] overflow-y-auto py-1">
                        {filteredDropdownPersonnel.length === 0 ? (
                          <div className="px-3 py-4 text-sm text-muted-foreground text-center">Sonuç bulunamadı</div>
                        ) : (
                          filteredDropdownPersonnel.map((person, idx) => (
                            <div 
                              key={idx} 
                              className={`px-3 py-2 text-sm cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-between ${selectedPerson === person ? 'bg-primary/5 font-medium text-primary' : ''}`}
                              onClick={() => {
                                setSelectedPerson(person);
                                setIsDropdownOpen(false);
                                setNewLeaveSearchQuery("");
                              }}
                            >
                              {person}
                              {selectedPerson === person && <Check className="w-4 h-4" />}
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  )}
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Label>İzin Türü</Label>
                    <InfoBubble content="Yıllık izinler personelin yasal hakkından düşerken, mazeret izinleri (hastalık, evlilik vb.) özel durumlarda verilir." />
                  </div>
                  <select className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2">
                    <option value="yillik">Yıllık İzin</option>
                    <option value="mazeret">Mazeret İzni</option>
                    <option value="rapor">Sağlık Raporu</option>
                    <option value="ucretsiz">Ücretsiz İzin</option>
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Başlangıç</Label>
                    <Input type="date" />
                  </div>
                  <div className="space-y-2">
                    <Label>Bitiş</Label>
                    <Input type="date" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Açıklama / Not</Label>
                  <textarea 
                    className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2" 
                    placeholder="İzin nedeni veya eklemek istediğiniz notlar..."
                  ></textarea>
                </div>
                <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white">İzni Sisteme İşle</Button>
              </form>
            </DialogContent>
          </Dialog>

          {/* Tüm Geçmiş İzinler Modalı */}
          <Dialog>
            <DialogTrigger className="flex items-center justify-center gap-3 bg-white/10 hover:bg-white/20 border border-white/20 transition-colors rounded-xl p-4 text-left cursor-pointer backdrop-blur-sm font-semibold text-lg">
              <History className="w-6 h-6 text-blue-200" />
              Geçmiş İzinler
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>Tüm İzin Geçmişi</DialogTitle>
              </DialogHeader>
              <div className="space-y-3 mt-4 max-h-[60vh] overflow-y-auto pr-2">
                {pastLeavesData.map(leave => (
                  <div key={leave.id} className="p-3 bg-slate-50 dark:bg-slate-900 rounded-lg border flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <p className="font-semibold">{leave.user}</p>
                      <p className="text-sm text-muted-foreground">{leave.type} • {leave.date}</p>
                    </div>
                    <Badge variant="outline" className="bg-slate-100 text-slate-600 border-slate-200 w-fit">
                      {leave.days} Gün
                    </Badge>
                  </div>
                ))}
              </div>
            </DialogContent>
          </Dialog>

          {/* İzin Politikaları Modalı */}
          <Dialog>
            <DialogTrigger className="flex items-center justify-center gap-3 bg-white/10 hover:bg-white/20 border border-white/20 transition-colors rounded-xl p-4 text-left cursor-pointer backdrop-blur-sm font-semibold text-lg">
              <Settings className="w-6 h-6 text-blue-200" />
              İzin Politikaları
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px] rounded-2xl">
              <DialogHeader>
                <DialogTitle className="text-xl">İzin Politikaları</DialogTitle>
                <DialogDescription>Personel kıdemine göre yıllık izin hakediş günlerini belirleyin.</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="flex items-center justify-between gap-4 p-4 border rounded-xl bg-slate-50/50 dark:bg-slate-900/50">
                  <div className="flex-1">
                    <Label className="text-base">1 - 5 Yıl Arası</Label>
                    <p className="text-xs text-muted-foreground mt-1">1 yıldan 5 yıla kadar çalışanlar</p>
                  </div>
                  <div className="w-24 flex items-center gap-2">
                    <Input type="number" defaultValue="14" className="text-center h-10 rounded-lg" />
                    <span className="text-sm font-medium">Gün</span>
                  </div>
                </div>
                <div className="flex items-center justify-between gap-4 p-4 border rounded-xl bg-slate-50/50 dark:bg-slate-900/50">
                  <div className="flex-1">
                    <Label className="text-base">5 - 15 Yıl Arası</Label>
                    <p className="text-xs text-muted-foreground mt-1">5 yıldan 15 yıla kadar çalışanlar</p>
                  </div>
                  <div className="w-24 flex items-center gap-2">
                    <Input type="number" defaultValue="20" className="text-center h-10 rounded-lg" />
                    <span className="text-sm font-medium">Gün</span>
                  </div>
                </div>
                <div className="flex items-center justify-between gap-4 p-4 border rounded-xl bg-slate-50/50 dark:bg-slate-900/50">
                  <div className="flex-1">
                    <Label className="text-base">15 Yıl ve Üzeri</Label>
                    <p className="text-xs text-muted-foreground mt-1">15 yıldan fazla çalışanlar</p>
                  </div>
                  <div className="w-24 flex items-center gap-2">
                    <Input type="number" defaultValue="26" className="text-center h-10 rounded-lg" />
                    <span className="text-sm font-medium">Gün</span>
                  </div>
                </div>
              </div>
              <div className="flex justify-end">
                <Button onClick={() => toast.success("Politikalar başarıyla kaydedildi.")} className="w-full sm:w-auto rounded-xl h-10 px-8 bg-blue-600 hover:bg-blue-700 text-white">Politikaları Kaydet</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* BÖLÜM 2: Onay Bekleyenler (Acil İşler) */}
      {pendingLeaves.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-amber-600 dark:text-amber-500">
            <AlertCircle className="w-5 h-5" />
            Onay Bekleyen Talepler
            <InfoBubble content="Personellerin talep ettiği ve henüz onaylanmamış izinler burada listelenir." className="w-5 h-5" iconClassName="text-amber-400 hover:text-amber-600" />
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {pendingLeaves.map(leave => (
              <Card key={leave.id} className="border-amber-200 bg-amber-50/30 dark:border-amber-900/30 dark:bg-amber-900/10 shadow-sm">
                <CardContent className="p-4 flex flex-col gap-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-bold text-lg">{leave.user}</p>
                      <p className="text-sm font-medium text-amber-700 dark:text-amber-400 mt-1">{leave.type} • {leave.date}</p>
                      <p className="text-sm text-muted-foreground mt-1 flex items-start gap-1">
                        <FileText className="w-4 h-4 mt-0.5 shrink-0" />
                        {leave.note}
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-2 pt-2 border-t border-amber-100 dark:border-amber-900/50">
                    <Button className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-white" onClick={() => handleApproveLeave(leave.id)}>
                      <Check className="w-4 h-4 mr-2" /> Onayla
                    </Button>
                    <Button variant="outline" className="flex-1 bg-white hover:bg-rose-50 text-rose-600 border-rose-200 hover:text-rose-700" onClick={() => handleRejectLeave(leave.id)}>
                      <X className="w-4 h-4 mr-2" /> Reddet
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* BÖLÜM 3: Personel İzin Hakları ve Hızlı Arama */}
      <div>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <CalendarDays className="w-5 h-5 text-blue-600" />
            Personel İzin Hakları
            <InfoBubble content="Tüm personellerin kalan yıllık izin günlerini buradan takip edebilir ve düzenleyebilirsiniz." />
          </h3>
          
          {/* Dev Arama Çubuğu */}
          <div className="relative w-full sm:w-72">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input 
              placeholder="Personel ara..." 
              className="pl-9 bg-white dark:bg-slate-900 border-slate-200 shadow-sm"
              value={mainSearchQuery}
              onChange={(e) => {
                setMainSearchQuery(e.target.value);
                setCurrentPage(1); // Arama yapıldığında 1. sayfaya dön
              }}
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredMainPersonnel.length === 0 ? (
            <div className="col-span-full py-12 text-center text-muted-foreground bg-slate-50 dark:bg-slate-900/50 rounded-xl border border-dashed">
              &quot;{mainSearchQuery}&quot; aramasıyla eşleşen personel bulunamadı.
            </div>
          ) : (
            currentPersonnel.map(person => (
              <Card key={person.id} className="shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-4">
                    <p className="font-semibold text-lg">{person.name}</p>
                    <div className="flex flex-col items-end">
                      <div className="flex items-center gap-1 mb-1">
                        <span className="text-xs text-muted-foreground">Kalan Yıllık İzin</span>
                        <InfoBubble content="Personelin bu yıl içinde kullanabileceği kalan toplam ücretli izin gün sayısıdır." className="w-3 h-3" iconClassName="text-slate-400" />
                      </div>
                      <Badge variant={person.remainingDays < 5 ? "destructive" : "default"} className={person.remainingDays >= 5 ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-200 border-emerald-200" : ""}>
                        {person.remainingDays} Gün
                      </Badge>
                    </div>
                  </div>
                  
                  <div className="flex gap-2">
                    {/* Hakkı Düzenle Modalı */}
                    <Dialog>
                      <DialogTrigger className="flex-1 inline-flex items-center justify-center whitespace-nowrap rounded-md text-xs font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground h-8 px-3">
                        <Edit2 className="w-3 h-3 mr-1.5" /> Hakkı Düzenle
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-[400px]">
                        <DialogHeader>
                          <DialogTitle>{person.name} - İzin Hakkı Düzenle</DialogTitle>
                        </DialogHeader>
                        <form onSubmit={(e) => handleUpdateBalance(e, person.name)} className="space-y-4 mt-4">
                          <div className="space-y-2">
                            <Label>Kalan Yıllık İzin (Gün)</Label>
                            <Input 
                              type="number" 
                              defaultValue={person.remainingDays} 
                              onChange={(e) => setEditBalanceValue(e.target.value)}
                              min="0"
                            />
                          </div>
                          <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white">Güncelle</Button>
                        </form>
                      </DialogContent>
                    </Dialog>

                    {/* Kişisel İzin Geçmişi Modalı */}
                    <Dialog>
                      <DialogTrigger className="flex-1 inline-flex items-center justify-center whitespace-nowrap rounded-md text-xs font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground h-8 px-3">
                        <Clock className="w-3 h-3 mr-1.5" /> İzin Geçmişi
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-[500px]">
                        <DialogHeader>
                          <DialogTitle>{person.name} - İzin Geçmişi</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-3 mt-4 max-h-[60vh] overflow-y-auto pr-2">
                          {/* Sadece bu kişiye ait geçmiş izinleri filtrele (Mock data olduğu için rastgele 1-2 tane gösteriyoruz) */}
                          <div className="p-3 bg-slate-50 dark:bg-slate-900 rounded-lg border flex justify-between items-center">
                            <div>
                              <p className="font-medium">Yıllık İzin</p>
                              <p className="text-xs text-muted-foreground">10-15 Ağustos 2025</p>
                            </div>
                            <Badge variant="outline">5 Gün</Badge>
                          </div>
                          <div className="p-3 bg-slate-50 dark:bg-slate-900 rounded-lg border flex justify-between items-center">
                            <div>
                              <p className="font-medium">Mazeret İzni</p>
                              <p className="text-xs text-muted-foreground">3 Kasım 2025</p>
                            </div>
                            <Badge variant="outline">1 Gün</Badge>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>

        {/* Sayfalama Kontrolleri */}
        {totalPages > 1 && (
          <div className="flex items-center justify-center gap-2 mt-8">
            <Button
              variant="outline"
              size="icon"
              onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="w-9 h-9"
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            
            {Array.from({ length: totalPages }).map((_, i) => {
              const page = i + 1;
              return (
                <Button
                  key={page}
                  variant={currentPage === page ? "default" : "outline"}
                  className={`w-9 h-9 p-0 ${currentPage === page ? 'bg-blue-600 text-white hover:bg-blue-700' : ''}`}
                  onClick={() => setCurrentPage(page)}
                >
                  {page}
                </Button>
              );
            })}

            <Button
              variant="outline"
              size="icon"
              onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="w-9 h-9"
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        )}
      </div>

    </div>
  );
}
