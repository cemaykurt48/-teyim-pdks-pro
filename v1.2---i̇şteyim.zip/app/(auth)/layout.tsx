import Link from 'next/link';
import { QrCode, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function AuthLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen grid lg:grid-cols-2">
      {/* Left Side - Brand/Marketing */}
      <div className="hidden lg:flex flex-col justify-between bg-slate-900 text-white p-12">
        <Link href="/" className="flex items-center gap-2 w-fit">
          <div className="bg-primary text-primary-foreground p-2 rounded-xl">
            <QrCode className="h-6 w-6" />
          </div>
          <span className="font-bold text-2xl tracking-tight">İşteyim</span>
        </Link>
        
        <div className="space-y-6 max-w-lg">
          <h1 className="text-4xl font-bold leading-tight">
            Personel takibini dert etmeyin, işinize odaklanın.
          </h1>
          <p className="text-slate-400 text-lg">
            Donanım maliyeti olmadan, saniyeler içinde personellerinizin giriş çıkışlarını takip edin, puantajı otomatik hesaplayın.
          </p>
        </div>
        
        <div className="text-sm text-slate-500">
          &copy; {new Date().getFullYear()} İşteyim. Tüm hakları saklıdır.
        </div>
      </div>

      {/* Right Side - Auth Forms */}
      <div className="flex flex-col p-4 sm:p-8 relative bg-background lg:bg-slate-50 dark:lg:bg-slate-900 min-h-[100dvh] lg:min-h-screen overflow-y-auto">
        <Link href="/" className="absolute top-4 left-4 sm:top-8 sm:left-8 z-10">
          <Button variant="ghost" size="sm" className="gap-2 text-muted-foreground hover:text-foreground rounded-full sm:rounded-md h-10 w-10 sm:w-auto sm:px-4 p-0 flex items-center justify-center bg-muted/50 sm:bg-transparent">
            <ArrowLeft className="w-5 h-5 sm:w-4 sm:h-4" />
            <span className="hidden sm:inline">Ana Sayfa</span>
          </Button>
        </Link>
        <div className="flex-1 flex flex-col justify-center w-full max-w-md mx-auto pt-12 pb-8">
          <div className="w-full space-y-8">
            <div className="flex lg:hidden items-center justify-center gap-3">
              <div className="bg-primary text-primary-foreground p-2 rounded-xl shadow-sm">
                <QrCode className="h-7 w-7" />
              </div>
              <span className="font-extrabold text-3xl tracking-tight">İşteyim</span>
            </div>
            {children}
          </div>
        </div>
      </div>
    </div>
  );
}
