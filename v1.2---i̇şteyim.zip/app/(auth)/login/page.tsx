"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, Smartphone, AlertCircle } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { toast } from "sonner";

import { auth, googleProvider } from "@/lib/firebase";
import { signInWithPopup } from "firebase/auth";

export default function LoginPage() {
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(false);
  const [showDeviceError, setShowDeviceError] = useState(false);
  const [phone, setPhone] = useState("");

  const handleGoogleSignIn = async () => {
    setIsLoading(true);
    try {
      await signInWithPopup(auth, googleProvider);
      toast.success("Google ile giriş başarılı!");
      router.push("/dashboard");
    } catch (error: any) {
      console.error("Google login error:", error);
      toast.error("Google ile giriş yapılırken bir hata oluştu.");
    } finally {
      setIsLoading(false);
    }
  };

  const onAdminSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Mock login delay
    setTimeout(() => {
      setIsLoading(false);
      router.push("/dashboard");
    }, 1000);
  };

  const onStaffSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Mock login delay - simulate "different device" error for a specific phone number or just randomly
    setTimeout(() => {
      setIsLoading(false);
      // For demo purposes, let's say if phone is "0555 555 55 55", it shows device error
      if (phone === "0555 555 55 55") {
        setShowDeviceError(true);
      } else {
        router.push("/staff-app");
      }
    }, 1000);
  };

  const handleRequestReset = () => {
    // Simulate sending request to manager
    const requests = JSON.parse(localStorage.getItem("device_reset_requests") || "[]");
    const newRequest = {
      id: Date.now(),
      staffName: "Mehmet Demir", // In a real app, this would come from the backend based on the phone number
      phone: phone,
      timestamp: new Date().toISOString(),
      status: "pending"
    };
    localStorage.setItem("device_reset_requests", JSON.stringify([...requests, newRequest]));
    
    toast.success("Cihaz sıfırlama isteği yöneticinize gönderildi.");
    setShowDeviceError(false);
  };

  return (
    <div className="w-full flex flex-col">
      <Tabs defaultValue="admin" className="w-full flex-col">
        <TabsList className="grid w-full grid-cols-2 h-14 rounded-full p-1.5 bg-muted/50 mb-8">
          <TabsTrigger value="admin" className="rounded-full text-base font-medium h-full">Yönetici</TabsTrigger>
          <TabsTrigger value="staff" className="rounded-full text-base font-medium h-full">Personel</TabsTrigger>
        </TabsList>
        
        <div className="flex flex-col space-y-2 text-center mb-8">
          <h1 className="text-3xl font-bold tracking-tight">Tekrar Hoş Geldiniz</h1>
          <p className="text-muted-foreground">
            Hesabınıza giriş yapmak için bilgilerinizi girin
          </p>
        </div>

        <TabsContent value="admin" className="mt-0 outline-none">
          <form onSubmit={onAdminSubmit} className="flex flex-col space-y-5">
            <div className="space-y-2 text-left">
              <Label htmlFor="email">E-posta</Label>
              <Input id="email" type="email" placeholder="ornek@sirket.com" className="h-14 px-4 text-base rounded-xl" required />
            </div>
            <div className="space-y-2 text-left">
              <div className="flex items-center justify-between">
                <Label htmlFor="password">Şifre</Label>
                <Link href="#" className="text-sm text-primary hover:underline font-medium">
                  Şifremi unuttum
                </Link>
              </div>
              <Input id="password" type="password" className="h-14 px-4 text-base rounded-xl" required />
            </div>
            <Button type="submit" className="w-full h-14 text-lg font-medium mt-4 rounded-xl" disabled={isLoading}>
              {isLoading && <Loader2 className="mr-2 h-5 w-5 animate-spin" />}
              Giriş Yap
            </Button>

            <div className="relative my-2">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t border-slate-200" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-white px-2 text-muted-foreground whitespace-nowrap">veya</span>
              </div>
            </div>

            <Button 
              type="button" 
              variant="outline" 
              className="w-full h-14 text-lg font-medium rounded-xl gap-3 border-slate-200 hover:bg-slate-50 transition-colors" 
              onClick={handleGoogleSignIn}
              disabled={isLoading}
            >
              <svg className="h-5 w-5" viewBox="0 0 24 24">
                <path
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  fill="#4285F4"
                />
                <path
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  fill="#34A853"
                />
                <path
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"
                  fill="#FBBC05"
                />
                <path
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                  fill="#EA4335"
                />
              </svg>
              Google ile Giriş Yap
            </Button>
          </form>
        </TabsContent>
        
        <TabsContent value="staff" className="mt-0 outline-none">
          <form onSubmit={onStaffSubmit} className="flex flex-col space-y-5">
            <div className="space-y-2 text-left">
              <Label htmlFor="phone">Telefon Numarası</Label>
              <Input 
                id="phone" 
                type="tel" 
                placeholder="05XX XXX XX XX" 
                className="h-14 px-4 text-base rounded-xl" 
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                required 
              />
              <p className="text-[10px] text-muted-foreground mt-1">Demo: &quot;0555 555 55 55&quot; yazarak cihaz hatasını görebilirsiniz.</p>
            </div>
            <div className="space-y-2 text-left">
              <Label htmlFor="pin">PIN Kodu</Label>
              <Input id="pin" type="password" placeholder="****" maxLength={4} className="h-14 text-center text-3xl tracking-[0.5em] rounded-xl font-mono" required />
            </div>
            <Button type="submit" className="w-full h-14 text-lg font-medium mt-4 rounded-xl" disabled={isLoading}>
              {isLoading && <Loader2 className="mr-2 h-5 w-5 animate-spin" />}
              Giriş Yap
            </Button>
          </form>
        </TabsContent>
      </Tabs>

      <Dialog open={showDeviceError} onOpenChange={setShowDeviceError}>
        <DialogContent className="sm:max-w-[400px] w-[90vw] rounded-2xl">
          <DialogHeader className="flex flex-col items-center text-center">
            <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mb-4">
              <Smartphone className="h-8 w-8 text-amber-600" />
            </div>
            <DialogTitle className="text-xl">Farklı Cihaz Algılandı</DialogTitle>
            <DialogDescription className="text-base pt-2">
              Hesabınız zaten başka bir cihaza kayıtlı görünüyor. Güvenliğiniz için her personel sadece bir cihazdan giriş yapabilir.
            </DialogDescription>
          </DialogHeader>
          <div className="bg-slate-50 p-4 rounded-xl border flex gap-3 items-start">
            <AlertCircle className="h-5 w-5 text-amber-500 shrink-0 mt-0.5" />
            <p className="text-sm text-slate-600 leading-relaxed">
              Bu cihazdan giriş yapabilmek için mevcut cihaz kaydınızın sıfırlanması gerekmektedir.
            </p>
          </div>
          <DialogFooter className="flex-col sm:flex-row gap-2 mt-4">
            <Button variant="outline" className="flex-1 h-12 rounded-xl" onClick={() => setShowDeviceError(false)}>Vazgeç</Button>
            <Button variant="default" className="flex-1 h-12 rounded-xl bg-primary" onClick={handleRequestReset}>Sıfırlama İsteği Gönder</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <div className="mt-10 text-center text-sm text-muted-foreground">
        Hesabınız yok mu?{" "}
        <Link href="/register" className="text-primary hover:underline font-semibold">
          Ücretsiz Kayıt Olun
        </Link>
      </div>
    </div>
  );
}
