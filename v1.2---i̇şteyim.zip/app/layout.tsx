import type { Metadata, Viewport } from 'next';
import './globals.css';
import { Inter } from "next/font/google";
import { cn } from "@/lib/utils";
import { Toaster } from "sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import PWAHead from "@/components/PWAHead";

import { PointerCapturePolyfill } from "@/components/pointer-capture-polyfill";
import { ScreenshotButton } from "@/components/ScreenshotButton";

const inter = Inter({subsets:['latin'],variable:'--font-sans'});

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  themeColor: '#0f172a',
};

export const metadata: Metadata = {
  title: 'İşteyim - Personel Takip Sistemi',
  description: 'KOBİ\'ler için QR ve konum doğrulamalı personel takip ve hafif İK yönetimi uygulaması.',
  appleWebApp: {
    capable: true,
    statusBarStyle: 'default',
    title: 'İşteyim',
  },
  formatDetection: {
    telephone: false,
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="tr" className={cn("font-sans antialiased", inter.variable)}>
      <head>
        <PWAHead />
      </head>
      <body className="min-h-screen bg-background" suppressHydrationWarning>
        <TooltipProvider>
          <PointerCapturePolyfill />
          {children}
          <ScreenshotButton />
          <Toaster position="top-center" richColors />
        </TooltipProvider>
      </body>
    </html>
  );
}
