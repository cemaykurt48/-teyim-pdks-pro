"use client";

import { useState } from "react";
import { CalendarClock, Plus, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const mockLeaves = [
  { id: 1, type: "Yıllık İzin", startDate: "12 Mayıs 2026", endDate: "15 Mayıs 2026", days: 3, status: "approved" },
  { id: 2, type: "Mazeret İzni", startDate: "01 Nisan 2026", endDate: "01 Nisan 2026", days: 1, status: "rejected" },
  { id: 3, type: "Hastalık İzni", startDate: "20 Mart 2026", endDate: "21 Mart 2026", days: 2, status: "approved" },
];

export default function LeavesPage() {
  const [isNewRequestOpen, setIsNewRequestOpen] = useState(false);

  const handleNewRequest = (e: React.FormEvent) => {
    e.preventDefault();
    // Here we would normally save the request to the backend
    setIsNewRequestOpen(false);
  };

  return (
    <div className="flex flex-col h-full bg-slate-50">
      <header className="bg-white px-6 py-4 border-b sticky top-0 z-10 flex items-center justify-between">
        <h1 className="text-xl font-bold">İzinlerim</h1>
        <Sheet open={isNewRequestOpen} onOpenChange={setIsNewRequestOpen}>
          <SheetTrigger render={
            <Button size="sm" className="gap-1 rounded-full">
              <Plus className="h-4 w-4" />
              Yeni Talep
            </Button>
          } />
          <SheetContent side="bottom" className="h-[85vh] sm:h-full sm:w-[400px] sm:side-right rounded-t-2xl sm:rounded-none px-4 pt-6">
            <SheetHeader className="mb-6 text-left">
              <SheetTitle>Yeni İzin Talebi</SheetTitle>
            </SheetHeader>
            <form onSubmit={handleNewRequest} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="leave-type">İzin Türü</Label>
                <Select name="type" defaultValue="yillik">
                  <SelectTrigger className="h-12">
                    <SelectValue placeholder="İzin türü seçin" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="yillik">Yıllık İzin</SelectItem>
                    <SelectItem value="hastalik">Hastalık İzni</SelectItem>
                    <SelectItem value="mazeret">Mazeret İzni</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="leave-start">Başlangıç</Label>
                  <Input id="leave-start" name="start" type="date" className="h-12" required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="leave-end">Bitiş</Label>
                  <Input id="leave-end" name="end" type="date" className="h-12" required />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="leave-reason">Açıklama (İsteğe bağlı)</Label>
                <Input id="leave-reason" name="reason" placeholder="İzin nedeni..." className="h-12" />
              </div>
              <Button type="submit" className="w-full h-12 mt-4 text-base">Talebi Gönder</Button>
            </form>
          </SheetContent>
        </Sheet>
      </header>

      <div className="p-4 space-y-4 pb-24">
        {/* Summary Card */}
        <Card className="border-none shadow-sm bg-primary text-primary-foreground">
          <CardContent className="p-5">
            <div className="flex justify-between items-center mb-4">
              <div className="space-y-1">
                <p className="text-primary-foreground/80 text-sm">İşe Başlangıç Tarihi</p>
                <p className="font-semibold">15 Ocak 2023</p>
              </div>
              <div className="text-right space-y-1">
                <p className="text-primary-foreground/80 text-sm">Kıdem</p>
                <p className="font-semibold">3 Yıl</p>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-4 pt-4 border-t border-primary-foreground/20">
              <div className="text-center">
                <p className="text-2xl font-bold">42</p>
                <p className="text-xs text-primary-foreground/80 mt-1">Toplam Hakediş</p>
              </div>
              <div className="text-center border-l border-r border-primary-foreground/20">
                <p className="text-2xl font-bold">28</p>
                <p className="text-xs text-primary-foreground/80 mt-1">Kullanılan</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold">14</p>
                <p className="text-xs text-primary-foreground/80 mt-1">Kalan Bakiye</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <h2 className="font-semibold text-sm text-muted-foreground uppercase tracking-wider pt-2 px-1">
          Geçmiş Talepler
        </h2>

        <div className="space-y-3">
          {mockLeaves.map((leave) => (
            <Card key={leave.id} className="border-none shadow-sm">
              <CardContent className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-semibold">{leave.type}</h3>
                  <Badge 
                    variant={leave.status === "approved" ? "default" : leave.status === "rejected" ? "destructive" : "secondary"}
                    className={leave.status === "approved" ? "bg-emerald-500" : ""}
                  >
                    {leave.status === "approved" ? "Onaylandı" : leave.status === "rejected" ? "Reddedildi" : "Bekliyor"}
                  </Badge>
                </div>
                <div className="flex items-center text-sm text-muted-foreground gap-2">
                  <CalendarClock className="h-4 w-4" />
                  <span>{leave.startDate} - {leave.endDate}</span>
                  <span className="mx-1">•</span>
                  <span>{leave.days} Gün</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
