import { Loader2 } from "lucide-react";

export default function StaffAppLoading() {
  return (
    <div className="h-full w-full flex flex-col items-center justify-center space-y-4 py-20">
      <Loader2 className="h-8 w-8 animate-spin text-primary" />
      <p className="text-muted-foreground text-sm font-medium animate-pulse">Yükleniyor...</p>
    </div>
  );
}
