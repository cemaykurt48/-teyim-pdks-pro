"use client";

import { User, LogOut, Shield, ChevronRight, Info, Smartphone, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { useState } from "react";

export default function ProfilePage() {
  const router = useRouter();

  const handlePinChange = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("PIN kodunuz başarıyla güncellendi.");
    // Close sheet logic would go here in a real app
  };

  return (
    <div className="flex flex-col h-full bg-slate-50">
      <header className="bg-white px-6 py-4 border-b sticky top-0 z-10">
        <h1 className="text-xl font-bold">Profil</h1>
      </header>

      <div className="p-4 space-y-6 pb-24">
        <div className="flex flex-col items-center justify-center py-6">
          <h2 className="text-2xl font-bold">Mehmet Demir</h2>
          <p className="text-muted-foreground">Personel • Merkez Şube</p>
        </div>

        <div className="space-y-3">
          <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wider px-1">
            Hesap Ayarları
          </h3>
          <Card className="border-none shadow-sm overflow-hidden">
            <div className="divide-y">
              {/* Kişisel Bilgiler (Read-Only) */}
              <Sheet>
                <SheetTrigger
                  render={
                    <button className="w-full flex items-center justify-between p-4 bg-white hover:bg-slate-50 transition-colors">
                      <div className="flex items-center gap-3">
                        <User className="h-5 w-5 text-muted-foreground" />
                        <span className="font-medium">Kişisel Bilgiler</span>
                      </div>
                      <ChevronRight className="h-5 w-5 text-muted-foreground" />
                    </button>
                  }
                />
                <SheetContent side="bottom" className="h-[85vh] sm:h-full sm:w-[400px] sm:side-right rounded-t-2xl sm:rounded-none px-4 pt-6">
                  <SheetHeader className="mb-6 text-left">
                    <SheetTitle>Kişisel Bilgiler</SheetTitle>
                  </SheetHeader>
                  <div className="space-y-5">
                    <div className="bg-blue-50 text-blue-800 p-4 rounded-lg flex gap-3 text-sm">
                      <Info className="h-5 w-5 shrink-0" />
                      <p>Bilgilerinizde bir hata olduğunu düşünüyorsanız lütfen yöneticinizle (şube müdürüyle) iletişime geçin.</p>
                    </div>
                    
                    <div className="space-y-2">
                      <Label className="text-muted-foreground">Ad Soyad</Label>
                      <div className="p-3 bg-slate-100 rounded-md font-medium">Mehmet Demir</div>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-muted-foreground">Telefon Numarası</Label>
                      <div className="p-3 bg-slate-100 rounded-md font-medium">0555 123 45 67</div>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-muted-foreground">Kayıtlı Şube</Label>
                      <div className="p-3 bg-slate-100 rounded-md font-medium">Merkez Şube</div>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-muted-foreground">İşe Başlama Tarihi</Label>
                      <div className="p-3 bg-slate-100 rounded-md font-medium">15 Ocak 2023</div>
                    </div>
                  </div>
                </SheetContent>
              </Sheet>

              {/* Güvenlik & PIN */}
              <Sheet>
                <SheetTrigger
                  render={
                    <button className="w-full flex items-center justify-between p-4 bg-white hover:bg-slate-50 transition-colors">
                      <div className="flex items-center gap-3">
                        <Shield className="h-5 w-5 text-muted-foreground" />
                        <span className="font-medium">PIN Değiştir</span>
                      </div>
                      <ChevronRight className="h-5 w-5 text-muted-foreground" />
                    </button>
                  }
                />
                <SheetContent side="bottom" className="h-[85vh] sm:h-full sm:w-[400px] sm:side-right rounded-t-2xl sm:rounded-none px-4 pt-6">
                  <SheetHeader className="mb-6 text-left">
                    <SheetTitle>PIN Kodunu Değiştir</SheetTitle>
                  </SheetHeader>
                  <form onSubmit={handlePinChange} className="space-y-5">
                    <div className="space-y-2">
                      <Label htmlFor="current-pin">Mevcut PIN Kodu</Label>
                      <Input id="current-pin" type="password" placeholder="****" maxLength={4} required className="h-12 text-center text-2xl tracking-[0.5em] font-mono" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="new-pin">Yeni PIN Kodu</Label>
                      <Input id="new-pin" type="password" placeholder="****" maxLength={4} required className="h-12 text-center text-2xl tracking-[0.5em] font-mono" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="confirm-pin">Yeni PIN Kodu (Tekrar)</Label>
                      <Input id="confirm-pin" type="password" placeholder="****" maxLength={4} required className="h-12 text-center text-2xl tracking-[0.5em] font-mono" />
                    </div>
                    <Button type="submit" className="w-full h-12 mt-4 text-base">PIN Kodunu Güncelle</Button>
                  </form>
                </SheetContent>
              </Sheet>
            </div>
          </Card>
        </div>

        <div className="space-y-3">
          <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wider px-1">
            Cihaz Yönetimi
          </h3>
          <Card className="border-none shadow-sm overflow-hidden">
            <div className="divide-y">
              <div className="p-4 flex items-center justify-between bg-white">
                <div className="flex items-center gap-3 text-muted-foreground">
                  <Smartphone className="h-5 w-5" />
                  <span className="font-medium text-foreground">Mevcut Cihaz</span>
                </div>
                <Badge variant="outline" className="text-emerald-600 border-emerald-200 bg-emerald-50">
                  Kayıtlı
                </Badge>
              </div>
            </div>
          </Card>
        </div>

        <div className="pt-4">
          <Button 
            variant="destructive" 
            className="w-full h-14 gap-2 text-lg font-semibold shadow-sm" 
            onClick={() => router.push("/login")}
          >
            <LogOut className="h-6 w-6" />
            Çıkış Yap
          </Button>
        </div>
      </div>
    </div>
  );
}
