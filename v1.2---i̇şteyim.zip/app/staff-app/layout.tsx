"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, QrCode, CalendarClock, User } from "lucide-react";
import { cn } from "@/lib/utils";

const navItems = [
  { name: "Ana Sayfa", href: "/staff-app", icon: Home },
  { name: "QR Okut", href: "/staff-app/qr", icon: QrCode },
  { name: "İzinlerim", href: "/staff-app/leaves", icon: CalendarClock },
  { name: "Profil", href: "/staff-app/profile", icon: User },
];

export default function StaffAppLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();

  return (
    <div className="min-h-screen bg-slate-50 flex justify-center">
      {/* Mobile App Container */}
      <div className="w-full max-w-md bg-background h-[100dvh] shadow-2xl relative flex flex-col overflow-hidden">
        
        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto bg-slate-50">
          {children}
        </main>

        {/* Bottom Navigation */}
        <nav className="w-full bg-background border-t flex justify-around items-center h-16 px-2 pb-safe z-50 shrink-0">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = pathname === item.href;
            
            return (
              <Link 
                key={item.href} 
                href={item.href}
                className={cn(
                  "flex flex-col items-center justify-center w-full h-full space-y-1 transition-colors",
                  isActive ? "text-primary" : "text-muted-foreground hover:text-foreground"
                )}
              >
                <Icon className={cn("h-5 w-5", isActive && "fill-primary/20")} />
                <span className="text-[10px] font-medium">{item.name}</span>
              </Link>
            );
          })}
        </nav>
      </div>
    </div>
  );
}
