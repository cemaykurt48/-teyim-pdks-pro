"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { Clock, MapPin, CheckCircle2, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useRouter } from "next/navigation";
import PWAInstallButton from "@/components/PWAInstallButton";

export default function StaffHomePage() {
  const router = useRouter();
  const [currentTime, setCurrentTime] = useState<string>("");
  const [currentDate, setCurrentDate] = useState<string>("");

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(now.toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" }));
      setCurrentDate(now.toLocaleDateString("tr-TR", { weekday: "long", day: "numeric", month: "long" }));
    };
    
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <header className="bg-primary text-primary-foreground p-6 rounded-b-3xl shadow-sm">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div>
              <p className="text-sm text-primary-foreground/80">Günaydın,</p>
              <h1 className="font-semibold text-lg">Mehmet Demir</h1>
            </div>
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            className="text-primary-foreground hover:bg-primary-foreground/10 rounded-full"
            onClick={() => router.push("/login")}
          >
            <LogOut className="h-5 w-5" />
            <span className="sr-only">Çıkış Yap</span>
          </Button>
        </div>
        
        <div className="text-center space-y-1 my-4">
          <p className="text-primary-foreground/80 text-sm">{currentDate}</p>
          <div className="text-5xl font-bold tracking-tighter">{currentTime || "00:00"}</div>
        </div>
      </header>

      <div className="p-6 space-y-6 flex-1 pb-24">
        {/* Action Card */}
        <Card className="border-none shadow-md bg-gradient-to-br from-white to-slate-50">
          <CardContent className="p-6 text-center space-y-4">
            <div className="mx-auto w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-2">
              <MapPin className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold text-lg">Mesaiye Başla</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Şubedesiniz. Giriş yapmak için QR kodu okutun.
              </p>
            </div>
            <Link href="/staff-app/qr" className="block w-full">
              <Button className="w-full h-12 text-base gap-2 rounded-xl shadow-lg shadow-primary/25">
                <QrCodeIcon className="h-5 w-5" />
                QR Okut
              </Button>
            </Link>
          </CardContent>
        </Card>

        {/* Today's Status */}
        <div className="space-y-3">
          <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wider">Bugünkü Durum</h3>
          
          <div className="bg-card border rounded-xl p-4 flex items-center justify-between shadow-sm">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center">
                <CheckCircle2 className="h-5 w-5 text-emerald-600" />
              </div>
              <div>
                <p className="text-sm font-medium">Giriş Yapıldı</p>
                <p className="text-xs text-muted-foreground">Merkez Şube</p>
              </div>
            </div>
            <span className="font-semibold">08:55</span>
          </div>

          <div className="bg-card border rounded-xl p-4 flex items-center justify-between shadow-sm opacity-50">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center">
                <Clock className="h-5 w-5 text-slate-500" />
              </div>
              <div>
                <p className="text-sm font-medium">Çıkış Bekleniyor</p>
                <p className="text-xs text-muted-foreground">Mesai bitimi: 18:00</p>
              </div>
            </div>
            <span className="font-semibold text-muted-foreground">--:--</span>
          </div>
        </div>
      </div>
      <PWAInstallButton />
    </div>
  );
}

function QrCodeIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect width="5" height="5" x="3" y="3" rx="1" />
      <rect width="5" height="5" x="16" y="3" rx="1" />
      <rect width="5" height="5" x="3" y="16" rx="1" />
      <path d="M21 16h-3a2 2 0 0 0-2 2v3" />
      <path d="M21 21v.01" />
      <path d="M12 7v3a2 2 0 0 1-2 2H7" />
      <path d="M3 12h.01" />
      <path d="M12 3h.01" />
      <path d="M12 16v.01" />
      <path d="M16 12h1" />
      <path d="M21 12v.01" />
      <path d="M12 21v-1" />
    </svg>
  )
}
