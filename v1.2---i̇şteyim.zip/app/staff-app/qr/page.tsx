"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Camera, MapPin, CheckCircle2, XCircle, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";

type ScanState = "locating" | "scanning" | "success" | "error" | "location_error";

export default function QrScanPage() {
  const router = useRouter();
  const [scanState, setScanState] = useState<ScanState>("locating");

  useEffect(() => {
    // Simulate location check
    const locationTimer = setTimeout(() => {
      setScanState("scanning");
    }, 2000);

    return () => clearTimeout(locationTimer);
  }, []);

  const handleSimulateScan = (success: boolean) => {
    setScanState(success ? "success" : "error");
    
    if (success) {
      setTimeout(() => {
        router.push("/staff-app");
      }, 2000);
    }
  };

  const handleSimulateLocationError = () => {
    setScanState("location_error");
  };

  return (
    <div className="flex flex-col h-full bg-black text-white">
      {/* Header */}
      <header className="p-4 flex items-center justify-between z-10 bg-gradient-to-b from-black/80 to-transparent">
        <Button variant="ghost" size="icon" className="text-white hover:bg-white/20" onClick={() => router.back()}>
          <XCircle className="h-6 w-6" />
        </Button>
        <span className="font-medium">QR Okut</span>
        <div className="w-10" /> {/* Spacer */}
      </header>

      {/* Camera Area */}
      <div className="flex-1 relative flex items-center justify-center overflow-hidden">
        {scanState === "locating" && (
          <div className="flex flex-col items-center gap-4 animate-pulse">
            <MapPin className="h-12 w-12 text-primary" />
            <p className="text-lg font-medium">Konum doğrulanıyor...</p>
          </div>
        )}

        {scanState === "scanning" && (
          <div className="relative w-64 h-64">
            {/* Viewfinder brackets */}
            <div className="absolute top-0 left-0 w-12 h-12 border-t-4 border-l-4 border-primary rounded-tl-lg"></div>
            <div className="absolute top-0 right-0 w-12 h-12 border-t-4 border-r-4 border-primary rounded-tr-lg"></div>
            <div className="absolute bottom-0 left-0 w-12 h-12 border-b-4 border-l-4 border-primary rounded-bl-lg"></div>
            <div className="absolute bottom-0 right-0 w-12 h-12 border-b-4 border-r-4 border-primary rounded-br-lg"></div>
            
            {/* Scanning line animation */}
            <div className="absolute top-0 left-0 w-full h-1 bg-primary shadow-[0_0_10px_#0ea5e9] animate-[scan_2s_ease-in-out_infinite]"></div>
            
            <div className="absolute inset-0 flex items-center justify-center">
              <Camera className="h-12 w-12 text-white/20" />
            </div>
          </div>
        )}

        {scanState === "success" && (
          <div className="flex flex-col items-center gap-4 text-emerald-400">
            <CheckCircle2 className="h-20 w-20" />
            <p className="text-xl font-bold">Giriş Başarılı!</p>
            <p className="text-sm text-white/70">Yönlendiriliyorsunuz...</p>
          </div>
        )}

        {scanState === "error" && (
          <div className="flex flex-col items-center gap-4 text-destructive">
            <XCircle className="h-20 w-20" />
            <p className="text-xl font-bold">Geçersiz QR Kod</p>
            <Button variant="outline" className="mt-4 text-white border-white/20 hover:bg-white/10" onClick={() => setScanState("scanning")}>
              Tekrar Dene
            </Button>
          </div>
        )}

        {scanState === "location_error" && (
          <div className="flex flex-col items-center gap-4 text-amber-400 px-10 text-center">
            <MapPin className="h-20 w-20" />
            <p className="text-xl font-bold">Şube Dışındasınız</p>
            <p className="text-sm text-white/70">Giriş yapabilmek için şube sınırları içerisinde olmanız gerekmektedir.</p>
            <Button variant="outline" className="mt-4 text-white border-white/20 hover:bg-white/10" onClick={() => setScanState("locating")}>
              Konumu Yenile
            </Button>
          </div>
        )}
      </div>

      {/* Bottom Controls (Simulation only) */}
      {(scanState === "scanning" || scanState === "location_error") && (
        <div className="p-6 bg-black/80 pb-24">
          <p className="text-center text-sm text-white/70 mb-6">
            Kameranızı şubedeki QR koda hizalayın.
          </p>
          
          <div className="bg-white/10 p-4 rounded-xl space-y-3">
            <p className="text-xs text-center text-white/50 uppercase tracking-wider font-semibold">Simülasyon Kontrolleri</p>
            <div className="flex flex-col gap-3">
              <div className="flex gap-3">
                <Button className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white" onClick={() => handleSimulateScan(true)}>
                  Başarılı Okuma
                </Button>
                <Button className="flex-1 bg-destructive hover:bg-destructive/90 text-white" onClick={() => handleSimulateScan(false)}>
                  Hatalı Okuma
                </Button>
              </div>
              <Button variant="secondary" className="w-full" onClick={handleSimulateLocationError}>
                Konum Hatası Simüle Et
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
