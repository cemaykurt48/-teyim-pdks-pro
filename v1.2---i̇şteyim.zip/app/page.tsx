import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle2, Clock, MapPin, QrCode, ShieldCheck } from 'lucide-react';

export default function LandingPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <header className="px-4 lg:px-6 h-16 flex items-center border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
        <Link className="flex items-center justify-center gap-2" href="/">
          <div className="bg-primary text-primary-foreground p-1.5 rounded-lg">
            <QrCode className="h-5 w-5" />
          </div>
          <span className="font-bold text-xl tracking-tight">İşteyim</span>
        </Link>
        <nav className="ml-auto flex gap-2 sm:gap-6 items-center">
          <Link className="hidden md:block text-sm font-medium hover:text-primary transition-colors" href="#ozellikler">
            Özellikler
          </Link>
          <Link className="hidden md:block text-sm font-medium hover:text-primary transition-colors" href="#fiyatlandirma">
            Fiyatlandırma
          </Link>
          <Link href="/login">
            <Button variant="ghost" className="text-sm font-medium px-2 sm:px-4">
              Giriş Yap
            </Button>
          </Link>
          <Link href="/register">
            <Button className="text-sm font-medium px-2 sm:px-4">Ücretsiz Dene</Button>
          </Link>
        </nav>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="w-full py-12 md:py-24 lg:py-32 xl:py-48 bg-gradient-to-b from-background to-muted/50">
          <div className="container px-4 md:px-6 mx-auto">
            <div className="flex flex-col items-center space-y-8 text-center">
              <div className="space-y-4 max-w-3xl">
                <h1 className="text-4xl font-extrabold tracking-tight sm:text-5xl md:text-6xl lg:text-7xl">
                  Personeliniz nerede? <br className="hidden sm:block" />
                  <span className="text-primary">Artık sormaya son.</span>
                </h1>
                <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl leading-relaxed">
                  KOBİ&apos;ler için QR ve konum doğrulamalı, donanım gerektirmeyen personel takip ve hafif İK yönetimi sistemi. 10 dakikada kurun, anında kullanmaya başlayın.
                </p>
              </div>
              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <Link href="/register">
                  <Button size="lg" className="w-full sm:w-auto gap-2 text-base h-12 px-8">
                    Hemen Ücretsiz Başla <ArrowRight className="w-4 h-4" />
                  </Button>
                </Link>
                <Link href="#ozellikler">
                  <Button size="lg" variant="outline" className="w-full sm:w-auto text-base h-12 px-8">
                    Nasıl Çalışır?
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section id="ozellikler" className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6 mx-auto">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
              <div className="space-y-2">
                <div className="inline-block rounded-lg bg-primary/10 text-primary px-3 py-1 text-sm font-medium">Özellikler</div>
                <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">İhtiyacınız olan her şey</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Karmaşık İK yazılımlarına veda edin. Sadece işinize yarayan, kullanımı kolay özellikler.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl items-center gap-6 py-12 lg:grid-cols-3 lg:gap-12">
              <div className="flex flex-col justify-center space-y-4 rounded-2xl border bg-background p-8 shadow-sm transition-all hover:shadow-md hover:border-primary/50 group">
                <div className="bg-primary/10 p-4 rounded-xl w-fit group-hover:bg-primary/20 transition-colors">
                  <QrCode className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-xl font-bold">QR ile Hızlı Giriş</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Personeliniz kendi telefonuyla şubedeki QR kodu okutarak saniyeler içinde giriş/çıkış yapar.
                </p>
              </div>
              <div className="flex flex-col justify-center space-y-4 rounded-2xl border bg-background p-8 shadow-sm transition-all hover:shadow-md hover:border-primary/50 group">
                <div className="bg-primary/10 p-4 rounded-xl w-fit group-hover:bg-primary/20 transition-colors">
                  <MapPin className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-xl font-bold">Konum Doğrulama</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Sadece şube konumunda olanlar işlem yapabilir. Sahte girişlerin önüne geçin.
                </p>
              </div>
              <div className="flex flex-col justify-center space-y-4 rounded-2xl border bg-background p-8 shadow-sm transition-all hover:shadow-md hover:border-primary/50 group">
                <div className="bg-primary/10 p-4 rounded-xl w-fit group-hover:bg-primary/20 transition-colors">
                  <Clock className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-xl font-bold">Otomatik Puantaj</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Geç kalmalar, erken çıkmalar ve mesai süreleri otomatik hesaplanır. Ay sonu raporunuz hazır.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Pricing Section */}
        <section id="fiyatlandirma" className="w-full py-12 md:py-24 lg:py-32 bg-muted/30">
          <div className="container px-4 md:px-6 mx-auto">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
              <div className="space-y-2">
                <div className="inline-block rounded-lg bg-primary/10 text-primary px-3 py-1 text-sm font-medium">Fiyatlandırma</div>
                <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Basit ve Şeffaf</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  İşletmenizin büyüklüğüne uygun planı seçin. Sürpriz ücret yok.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-4xl items-start gap-6 lg:grid-cols-2 lg:gap-12">
              {/* Free Plan */}
              <div className="flex flex-col rounded-2xl border bg-background p-8 shadow-sm transition-all hover:shadow-md">
                <h3 className="text-2xl font-bold">Başlangıç</h3>
                <div className="mt-4 flex items-baseline text-5xl font-extrabold">
                  ₺0
                  <span className="ml-1 text-xl font-medium text-muted-foreground">/ay</span>
                </div>
                <p className="mt-4 text-muted-foreground">Küçük işletmeler için ideal başlangıç noktası.</p>
                <ul className="mt-8 space-y-4 flex-1">
                  <li className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-primary" />
                    <span>1 Şube</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-primary" />
                    <span>5 Personele kadar</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-primary" />
                    <span>QR ve Konum Doğrulama</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-primary" />
                    <span>Temel Raporlama</span>
                  </li>
                </ul>
                <Link href="/register" className="mt-8">
                  <Button className="w-full h-12 text-base" variant="outline">Hemen Başla</Button>
                </Link>
              </div>

              {/* Pro Plan */}
              <div className="flex flex-col rounded-2xl border-2 border-primary bg-background p-8 shadow-lg relative transition-all hover:shadow-xl">
                <div className="absolute top-0 right-8 -translate-y-1/2">
                  <span className="bg-primary text-primary-foreground text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                    En Popüler
                  </span>
                </div>
                <h3 className="text-2xl font-bold">Pro</h3>
                <div className="mt-4 flex items-baseline text-5xl font-extrabold">
                  ₺499
                  <span className="ml-1 text-xl font-medium text-muted-foreground">/ay</span>
                </div>
                <p className="mt-4 text-muted-foreground">Büyüyen işletmeler için tüm özellikler.</p>
                <ul className="mt-8 space-y-4 flex-1">
                  <li className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-primary" />
                    <span className="font-medium">Sınırsız Şube</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-primary" />
                    <span className="font-medium">Sınırsız Personel</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-primary" />
                    <span>Gelişmiş İzin Yönetimi</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-primary" />
                    <span>Kiosk Modu (Tablet)</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-primary" />
                    <span>Anlık PWA Bildirimleri</span>
                  </li>
                </ul>
                <Link href="/register" className="mt-8">
                  <Button className="w-full h-12 text-base">Pro&apos;ya Geç</Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="w-full border-t bg-background py-6 md:py-8">
        <div className="container px-4 md:px-6 mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
          <Link href="/super-admin" className="flex items-center gap-2 group cursor-pointer" title="Sistem Yönetimi">
            <QrCode className="h-5 w-5 text-primary group-hover:scale-110 transition-transform" />
            <span className="font-semibold">İşteyim</span>
          </Link>
          <p className="text-sm text-muted-foreground text-center md:text-left">
            &copy; {new Date().getFullYear()} İşteyim. Tüm hakları saklıdır.
          </p>
          <div className="flex gap-4">
            <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">Gizlilik</Link>
            <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">Şartlar</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
