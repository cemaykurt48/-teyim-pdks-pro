"use client";

import { useState } from "react";
import { 
  Search, 
  Building2, 
  Users, 
  LogIn, 
  Ban, 
  Edit, 
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Mail,
  Calendar,
  UserCog
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { InfoBubble } from "@/components/info-bubble";

import { useRouter } from "next/navigation";

// Generate 45 mock companies
const generateMockCompanies = () => {
  const plans = ["Başlangıç", "Pro", "Enterprise"];
  const companies = [];
  for (let i = 1; i <= 45; i++) {
    companies.push({
      id: i,
      name: `Firma ${i} A.Ş.`,
      contact: `Yetkili ${i}`,
      email: `iletisim@firma${i}.com`,
      plan: plans[i % 3],
      staffCount: Math.floor(Math.random() * 100) + 5,
      branchCount: Math.floor(Math.random() * 5) + 1,
      status: i % 7 === 0 ? "suspended" : "active",
      joinDate: `${(i % 28) + 1} Oca 2024`
    });
  }
  return companies;
};

const initialCompanies = generateMockCompanies();

export default function CompaniesPage() {
  const router = useRouter();
  const [searchTerm, setSearchTerm] = useState("");
  const [companies, setCompanies] = useState(initialCompanies);
  const [currentPage, setCurrentPage] = useState(1);
  
  // Dialog States
  const [selectedCompany, setSelectedCompany] = useState<typeof initialCompanies[0] | null>(null);
  const [isDetailsDialogOpen, setIsDetailsDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editPlanValue, setEditPlanValue] = useState("");
  
  const itemsPerPage = 12; // Grid friendly

  const filteredCompanies = companies.filter(company => 
    company.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    company.contact.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalPages = Math.ceil(filteredCompanies.length / itemsPerPage);
  const paginatedCompanies = filteredCompanies.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const handleImpersonate = (companyName: string) => {
    toast.success(`${companyName} paneline yönetici olarak giriş yapılıyor...`);
    setIsDetailsDialogOpen(false);
    setTimeout(() => {
      router.push("/dashboard");
    }, 1000);
  };

  const handleStatusChange = (companyId: number, currentStatus: string) => {
    const newStatus = currentStatus === "active" ? "suspended" : "active";
    setCompanies(companies.map(c => c.id === companyId ? { ...c, status: newStatus } : c));
    const action = newStatus === "active" ? "aktifleştirildi" : "askıya alındı";
    toast.success(`Firma başarıyla ${action}.`);
    
    // Update selected company if it's the one being modified
    if (selectedCompany && selectedCompany.id === companyId) {
      setSelectedCompany({ ...selectedCompany, status: newStatus });
    }
  };

  const openDetails = (company: typeof initialCompanies[0]) => {
    setSelectedCompany(company);
    setIsDetailsDialogOpen(true);
  };

  const openEditPlan = () => {
    if (selectedCompany) {
      setEditPlanValue(selectedCompany.plan);
      setIsEditDialogOpen(true);
    }
  };

  const handleSavePlan = () => {
    if (selectedCompany) {
      const updatedCompany = { ...selectedCompany, plan: editPlanValue };
      setCompanies(companies.map(c => c.id === selectedCompany.id ? updatedCompany : c));
      setSelectedCompany(updatedCompany);
      toast.success(`${selectedCompany.name} paketi güncellendi.`);
      setIsEditDialogOpen(false);
    }
  };

  return (
    <div className="space-y-6 pb-20 md:pb-0">
      {/* Header & Search */}
      <div className="flex flex-col gap-4 sticky top-0 z-10 bg-slate-950/80 backdrop-blur-md pt-2 pb-4 -mx-4 px-4 sm:mx-0 sm:px-0 sm:pt-0 sm:bg-transparent sm:backdrop-blur-none">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            Firmalar
            <InfoBubble content="Sisteme kayıtlı tüm firmaları, abonelik durumlarını ve personel sayılarını buradan yönetebilirsiniz." />
          </h2>
          <p className="text-slate-400 text-sm mt-1">
            Müşterileri ve abonelik durumlarını yönetin.
          </p>
        </div>
        <div className="relative w-full sm:max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
          <Input
            placeholder="Firma veya yetkili ara..."
            className="pl-9 h-11 bg-slate-900 border-slate-800 text-slate-200 placeholder:text-slate-500 focus-visible:ring-indigo-500 rounded-xl"
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              setCurrentPage(1);
            }}
          />
        </div>
      </div>

      {/* Company Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 md:gap-4">
        {paginatedCompanies.map((company) => (
          <Card 
            key={company.id} 
            className="bg-slate-900 border-slate-800 cursor-pointer hover:border-slate-700 hover:bg-slate-800/50 transition-all active:scale-[0.98]"
            onClick={() => openDetails(company)}
          >
            <CardContent className="p-4">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-indigo-500/20 flex items-center justify-center text-indigo-400 font-bold shrink-0">
                    {company.name.charAt(0)}
                  </div>
                  <div>
                    <h3 className="font-medium text-slate-200 line-clamp-1">{company.name}</h3>
                    <span className="inline-flex items-center px-2 py-0.5 mt-1 rounded text-[10px] font-medium bg-slate-800 text-slate-300 border border-slate-700">
                      {company.plan}
                    </span>
                  </div>
                </div>
                {/* Status Dot */}
                <div className={`w-2.5 h-2.5 rounded-full shrink-0 ${company.status === 'active' ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.4)]' : 'bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.4)]'}`} />
              </div>
              
              <div className="grid grid-cols-2 gap-2 mt-4 pt-4 border-t border-slate-800/50">
                <div className="flex items-center gap-1.5 text-slate-400">
                  <Users className="w-3.5 h-3.5" />
                  <span className="text-xs">{company.staffCount} Personel</span>
                </div>
                <div className="flex items-center gap-1.5 text-slate-400">
                  <Building2 className="w-3.5 h-3.5" />
                  <span className="text-xs">{company.branchCount} Şube</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
        
        {paginatedCompanies.length === 0 && (
          <div className="col-span-full py-12 text-center text-slate-500">
            Arama kriterlerine uygun firma bulunamadı.
          </div>
        )}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center sm:justify-end gap-2 pt-4">
          <Button 
            variant="outline" 
            size="icon" 
            className="h-9 w-9 bg-slate-900 border-slate-800 text-slate-300 rounded-lg"
            onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
            disabled={currentPage === 1}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <div className="px-4 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 text-sm font-medium">
            {currentPage} / {totalPages}
          </div>
          <Button 
            variant="outline" 
            size="icon" 
            className="h-9 w-9 bg-slate-900 border-slate-800 text-slate-300 rounded-lg"
            onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
            disabled={currentPage === totalPages}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      )}

      {/* Company Details Dialog (Mobile-friendly full-ish screen) */}
      <Dialog open={isDetailsDialogOpen} onOpenChange={setIsDetailsDialogOpen}>
        <DialogContent className="bg-slate-900 border-slate-800 text-slate-200 sm:max-w-md w-[95vw] max-h-[90vh] overflow-y-auto rounded-2xl p-0 gap-0">
          {selectedCompany && (
            <>
              <div className="p-6 pb-4 border-b border-slate-800/50">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-14 h-14 rounded-2xl bg-indigo-500/20 flex items-center justify-center text-indigo-400 font-bold text-xl shrink-0">
                    {selectedCompany.name.charAt(0)}
                  </div>
                  <div>
                    <DialogTitle className="text-xl text-white">{selectedCompany.name}</DialogTitle>
                    <div className="flex items-center gap-2 mt-1.5">
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-slate-800 text-slate-300 border border-slate-700">
                        {selectedCompany.plan}
                      </span>
                      {selectedCompany.status === "active" ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium bg-emerald-500/10 text-emerald-400">
                          <CheckCircle2 className="w-3 h-3" /> Aktif
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium bg-amber-500/10 text-amber-400">
                          <Ban className="w-3 h-3" /> Askıda
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-6 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-slate-800/30 p-3 rounded-xl border border-slate-800/50">
                    <div className="flex items-center gap-2 text-slate-400 mb-1">
                      <UserCog className="w-4 h-4" />
                      <span className="text-xs font-medium">Yetkili</span>
                    </div>
                    <div className="text-sm text-slate-200">{selectedCompany.contact}</div>
                  </div>
                  <div className="bg-slate-800/30 p-3 rounded-xl border border-slate-800/50">
                    <div className="flex items-center gap-2 text-slate-400 mb-1">
                      <Mail className="w-4 h-4" />
                      <span className="text-xs font-medium">E-posta</span>
                    </div>
                    <div className="text-sm text-slate-200 truncate" title={selectedCompany.email}>{selectedCompany.email}</div>
                  </div>
                  <div className="bg-slate-800/30 p-3 rounded-xl border border-slate-800/50">
                    <div className="flex items-center gap-2 text-slate-400 mb-1">
                      <Users className="w-4 h-4" />
                      <span className="text-xs font-medium">Personel</span>
                    </div>
                    <div className="text-sm text-slate-200">{selectedCompany.staffCount} Kişi</div>
                  </div>
                  <div className="bg-slate-800/30 p-3 rounded-xl border border-slate-800/50">
                    <div className="flex items-center gap-2 text-slate-400 mb-1">
                      <Calendar className="w-4 h-4" />
                      <span className="text-xs font-medium">Kayıt</span>
                    </div>
                    <div className="text-sm text-slate-200">{selectedCompany.joinDate}</div>
                  </div>
                </div>

                {/* Big Action Buttons */}
                <div className="pt-4 space-y-2.5">
                  <div className="relative flex items-center">
                    <Button 
                      className="w-full h-12 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl pr-12"
                      onClick={() => handleImpersonate(selectedCompany.name)}
                    >
                      <LogIn className="w-5 h-5 mr-2" />
                      Yönetici Olarak Giriş Yap
                    </Button>
                    <div className="absolute right-3">
                      <InfoBubble content="Bu firmanın paneline sanki o firmanın yöneticisiymişsiniz gibi giriş yapmanızı sağlar. (Impersonation)" className="w-6 h-6 hover:bg-white/10" iconClassName="text-indigo-200 hover:text-white" />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2.5">
                    <Button 
                      variant="outline" 
                      className="h-12 bg-slate-900 border-slate-700 hover:bg-slate-800 text-slate-200 rounded-xl"
                      onClick={openEditPlan}
                    >
                      <Edit className="w-4 h-4 mr-2" />
                      Paketi Düzenle
                    </Button>
                    
                    <Button 
                      variant="outline" 
                      className={`h-12 rounded-xl border-slate-700 bg-slate-900 ${
                        selectedCompany.status === 'active' 
                          ? 'text-amber-400 hover:text-amber-300 hover:bg-amber-500/10 border-amber-500/20' 
                          : 'text-emerald-400 hover:text-emerald-300 hover:bg-emerald-500/10 border-emerald-500/20'
                      }`}
                      onClick={() => handleStatusChange(selectedCompany.id, selectedCompany.status)}
                    >
                      {selectedCompany.status === 'active' ? (
                        <><Ban className="w-4 h-4 mr-2" /> Askıya Al</>
                      ) : (
                        <><CheckCircle2 className="w-4 h-4 mr-2" /> Aktifleştir</>
                      )}
                    </Button>
                  </div>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Edit Plan Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="bg-slate-900 border-slate-800 text-slate-200 sm:max-w-sm rounded-2xl">
          <DialogHeader>
            <DialogTitle className="text-white">Paket Düzenle</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <Label className="text-slate-400 mb-2 block">Yeni Paket Seçin</Label>
            <Select value={editPlanValue} onValueChange={(val) => setEditPlanValue(val || "")}>
              <SelectTrigger className="w-full bg-slate-950 border-slate-800 text-slate-200 h-12 rounded-xl">
                <SelectValue placeholder="Paket seçin" />
              </SelectTrigger>
              <SelectContent className="bg-slate-900 border-slate-800 text-slate-200">
                <SelectItem value="Başlangıç">Başlangıç Paketi</SelectItem>
                <SelectItem value="Pro">Pro Paket</SelectItem>
                <SelectItem value="Enterprise">Enterprise Paket</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)} className="border-slate-700 text-slate-300 hover:bg-slate-800 rounded-xl h-11">
              İptal
            </Button>
            <Button onClick={handleSavePlan} className="bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl h-11">
              Kaydet
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
