"use client";

import { useState } from "react";
import { 
  ShieldAlert, 
  Search, 
  Filter,
  AlertTriangle,
  Info,
  XCircle,
  Terminal,
  ChevronDown,
  ChevronUp,
  ChevronLeft,
  ChevronRight
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

// Generate 40 mock logs
const generateMockLogs = () => {
  const types = ["error", "warning", "info", "info", "info"]; // More info logs
  const sources = ["Database", "Server-01", "Auth Service", "Billing Service", "Backup Job"];
  const messages = [
    "Veritabanı bağlantı hatası (Timeout)",
    "Yüksek CPU kullanımı tespit edildi (%85)",
    "Yeni firma kaydı: 'TechStart Yazılım'",
    "Süper Admin girişi başarılı (IP: 192.168.1.1)",
    "Ödeme API yanıt vermiyor (Stripe)",
    "Günlük veritabanı yedeği başarıyla alındı",
    "Başarısız giriş denemesi (IP: 45.33.22.11)"
  ];
  
  const logs = [];
  for (let i = 1; i <= 40; i++) {
    logs.push({
      id: `LOG-${10000 - i}`,
      type: types[i % types.length],
      message: messages[i % messages.length],
      source: sources[i % sources.length],
      date: `0${(i % 9) + 1} Nis 2026 14:${(i % 50) + 10}:01`
    });
  }
  return logs;
};

const initialLogs = generateMockLogs();

export default function LogsPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState("all");
  const [currentPage, setCurrentPage] = useState(1);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  
  const itemsPerPage = 10;

  const filteredLogs = initialLogs.filter(log => {
    const matchesSearch = log.message.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          log.source.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterType === "all" || log.type === filterType;
    return matchesSearch && matchesFilter;
  });

  const totalPages = Math.ceil(filteredLogs.length / itemsPerPage);
  const paginatedLogs = filteredLogs.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const getLogIcon = (type: string) => {
    switch (type) {
      case "error":
        return <XCircle className="w-4 h-4 text-red-400" />;
      case "warning":
        return <AlertTriangle className="w-4 h-4 text-amber-400" />;
      case "info":
        return <Info className="w-4 h-4 text-blue-400" />;
      default:
        return <Terminal className="w-4 h-4 text-slate-400" />;
    }
  };

  const getLogBadge = (type: string) => {
    switch (type) {
      case "error":
        return <Badge className="bg-red-500/10 text-red-400 border-red-500/20">Hata</Badge>;
      case "warning":
        return <Badge className="bg-amber-500/10 text-amber-400 border-amber-500/20">Uyarı</Badge>;
      case "info":
        return <Badge className="bg-blue-500/10 text-blue-400 border-blue-500/20">Bilgi</Badge>;
      default:
        return <Badge variant="outline">Bilinmiyor</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-white">Sistem Logları</h2>
          <p className="text-slate-400">
            Sistemdeki tüm hareketleri, hataları ve uyarıları izleyin.
          </p>
        </div>
      </div>

      <Card className="bg-slate-900 border-slate-800">
        <div className="p-4 border-b border-slate-800 flex flex-col sm:flex-row justify-between gap-4">
          <div className="relative w-full sm:w-96">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-500" />
            <Input
              placeholder="Log mesajı veya kaynak ara..."
              className="pl-9 bg-slate-950 border-slate-800 text-slate-200 placeholder:text-slate-500 focus-visible:ring-indigo-500"
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
            />
          </div>
          <div className="flex gap-2 overflow-x-auto pb-1 sm:pb-0">
            <Button 
              variant="outline" 
              size="sm" 
              className={`whitespace-nowrap ${filterType === 'all' ? 'bg-slate-800 text-white border-slate-700' : 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800 hover:text-white'}`}
              onClick={() => { setFilterType('all'); setCurrentPage(1); }}
            >
              Tümü
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className={`whitespace-nowrap ${filterType === 'error' ? 'bg-red-500/20 text-red-400 border-red-500/30' : 'bg-slate-950 border-slate-800 text-red-400 hover:bg-slate-800 hover:text-red-300'}`}
              onClick={() => { setFilterType('error'); setCurrentPage(1); }}
            >
              Hatalar
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className={`whitespace-nowrap ${filterType === 'warning' ? 'bg-amber-500/20 text-amber-400 border-amber-500/30' : 'bg-slate-950 border-slate-800 text-amber-400 hover:bg-slate-800 hover:text-amber-300'}`}
              onClick={() => { setFilterType('warning'); setCurrentPage(1); }}
            >
              Uyarılar
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className={`whitespace-nowrap ${filterType === 'info' ? 'bg-blue-500/20 text-blue-400 border-blue-500/30' : 'bg-slate-950 border-slate-800 text-blue-400 hover:bg-slate-800 hover:text-blue-300'}`}
              onClick={() => { setFilterType('info'); setCurrentPage(1); }}
            >
              Bilgi
            </Button>
          </div>
        </div>
        
        {/* Desktop Table View */}
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full text-sm text-left font-mono">
            <thead className="text-xs text-slate-400 uppercase bg-slate-900/50 border-b border-slate-800 font-sans">
              <tr>
                <th className="px-6 py-4 font-medium">Tarih / Saat</th>
                <th className="px-6 py-4 font-medium">Tip</th>
                <th className="px-6 py-4 font-medium">Kaynak</th>
                <th className="px-6 py-4 font-medium">Mesaj</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {paginatedLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="px-6 py-4 text-slate-400 text-xs whitespace-nowrap">
                    {log.date}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      {getLogIcon(log.type)}
                      {getLogBadge(log.type)}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-slate-300 text-xs">
                    {log.source}
                  </td>
                  <td className="px-6 py-4 text-slate-300 text-xs">
                    {log.message}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Mobile Compact List View */}
        <div className="md:hidden flex flex-col divide-y divide-slate-800 font-mono text-xs">
          {paginatedLogs.map((log) => (
            <div key={log.id} className="flex flex-col">
              <div 
                className="p-4 flex items-center justify-between cursor-pointer hover:bg-slate-800/30 transition-colors"
                onClick={() => setExpandedId(expandedId === log.id ? null : log.id)}
              >
                <div className="flex items-center gap-3">
                  {getLogIcon(log.type)}
                  <div className="flex flex-col gap-1">
                    <span className="text-slate-300 line-clamp-1">{log.message}</span>
                    <span className="text-slate-500">{log.date}</span>
                  </div>
                </div>
                <div className="text-slate-500 shrink-0 ml-2">
                  {expandedId === log.id ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </div>
              </div>
              
              {expandedId === log.id && (
                <div className="p-4 pt-0 bg-slate-800/10 flex flex-col gap-2 animate-in slide-in-from-top-2 duration-200">
                  <div className="text-slate-300 mt-2 break-words">
                    {log.message}
                  </div>
                  <div className="flex items-center gap-2 mt-2">
                    <span className="text-slate-500">Kaynak:</span>
                    <span className="text-slate-400 bg-slate-800 px-2 py-1 rounded-md">{log.source}</span>
                  </div>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-slate-500">Tip:</span>
                    {getLogBadge(log.type)}
                  </div>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-slate-500">ID:</span>
                    <span className="text-slate-400">{log.id}</span>
                  </div>
                </div>
              )}
            </div>
          ))}
          {paginatedLogs.length === 0 && (
            <div className="p-8 text-center text-slate-500 font-sans text-sm">
              Arama kriterlerinize uygun log bulunamadı.
            </div>
          )}
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="p-4 border-t border-slate-800 flex items-center justify-between text-sm text-slate-400 font-sans">
            <div>
              Toplam <span className="text-slate-200 font-medium">{filteredLogs.length}</span> kayıt
            </div>
            <div className="flex items-center gap-2">
              <Button 
                variant="outline" 
                size="icon" 
                className="h-8 w-8 bg-slate-900 border-slate-700 text-slate-300"
                onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <span className="text-slate-300">
                {currentPage} / {totalPages}
              </span>
              <Button 
                variant="outline" 
                size="icon" 
                className="h-8 w-8 bg-slate-900 border-slate-700 text-slate-300"
                onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                disabled={currentPage === totalPages}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
}
