"use client";

import { Card, CardContent } from "@/components/ui/card";
import { 
  Building2, 
  CreditCard, 
  Activity, 
  Plus, 
  AlertCircle, 
  CheckCircle2, 
  ArrowRight,
  Ticket
} from "lucide-react";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { InfoBubble } from "@/components/info-bubble";

export default function SuperAdminDashboard() {
  return (
    <div className="space-y-6 pb-20 md:pb-0">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold tracking-tight text-white">Genel Bakış</h2>
        <p className="text-slate-400 text-sm mt-1">
          Sistemin anlık durumu ve önemli metrikler.
        </p>
      </div>

      {/* KPI Cards - 2 Columns on Mobile */}
      <div className="grid grid-cols-2 gap-3 md:gap-4 lg:grid-cols-4">
        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="p-4 flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <div className="w-8 h-8 rounded-full bg-indigo-500/20 flex items-center justify-center">
                <CreditCard className="h-4 w-4 text-indigo-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1">
                <p className="text-xs font-medium text-slate-400">Aylık Gelir</p>
                <InfoBubble content="Tüm aktif aboneliklerden elde edilen toplam aylık gelir." className="w-3 h-3" iconClassName="text-slate-500" />
              </div>
              <h3 className="text-xl font-bold text-white mt-0.5">₺48.5K</h3>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="p-4 flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <div className="w-8 h-8 rounded-full bg-emerald-500/20 flex items-center justify-center">
                <Building2 className="h-4 w-4 text-emerald-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1">
                <p className="text-xs font-medium text-slate-400">Aktif Firma</p>
                <InfoBubble content="Sistemi aktif olarak kullanan ve aboneliği devam eden firma sayısı." className="w-3 h-3" iconClassName="text-slate-500" />
              </div>
              <h3 className="text-xl font-bold text-white mt-0.5">124</h3>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="p-4 flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <div className="w-8 h-8 rounded-full bg-amber-500/20 flex items-center justify-center">
                <Ticket className="h-4 w-4 text-amber-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1">
                <p className="text-xs font-medium text-slate-400">Açık Destek</p>
                <InfoBubble content="Müşteriler tarafından açılmış ve henüz çözümlenmemiş destek talepleri." className="w-3 h-3" iconClassName="text-slate-500" />
              </div>
              <h3 className="text-xl font-bold text-white mt-0.5">3</h3>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="p-4 flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <div className="w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center">
                <Activity className="h-4 w-4 text-blue-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1">
                <p className="text-xs font-medium text-slate-400">Sistem Sağlığı</p>
                <InfoBubble content="Sunucuların ve veritabanının genel çalışma durumu (Uptime)." className="w-3 h-3" iconClassName="text-slate-500" />
              </div>
              <h3 className="text-xl font-bold text-white mt-0.5">%99.9</h3>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div>
        <h3 className="text-sm font-medium text-slate-400 mb-3 uppercase tracking-wider">Hızlı İşlemler</h3>
        <div className="grid grid-cols-2 gap-3">
          <Button variant="outline" className="h-auto py-3 flex flex-col gap-2 bg-slate-900 border-slate-800 hover:bg-slate-800 hover:text-white">
            <Plus className="h-5 w-5 text-indigo-400" />
            <span className="text-xs">Yeni Firma</span>
          </Button>
          <Button variant="outline" className="h-auto py-3 flex flex-col gap-2 bg-slate-900 border-slate-800 hover:bg-slate-800 hover:text-white">
            <AlertCircle className="h-5 w-5 text-amber-400" />
            <span className="text-xs">Ödeme Hataları</span>
          </Button>
        </div>
      </div>

      {/* Activity Feed */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-medium text-slate-400 uppercase tracking-wider">Son Aktiviteler</h3>
          <Link href="/super-admin/logs" className="text-xs text-indigo-400 flex items-center hover:underline">
            Tümü <ArrowRight className="h-3 w-3 ml-1" />
          </Link>
        </div>
        
        <Card className="bg-slate-900 border-slate-800 overflow-hidden">
          <div className="flex flex-col divide-y divide-slate-800/50">
            {/* Activity Item 1 */}
            <div className="p-4 flex gap-3 items-start hover:bg-slate-800/30 transition-colors">
              <div className="w-8 h-8 rounded-full bg-emerald-500/10 flex items-center justify-center shrink-0 mt-0.5">
                <CheckCircle2 className="h-4 w-4 text-emerald-500" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-slate-200 font-medium truncate">Yeni Kayıt: TechNova A.Ş.</p>
                <p className="text-xs text-slate-500 mt-0.5">Pro Paket ile sisteme dahil oldu.</p>
              </div>
              <span className="text-[10px] text-slate-500 shrink-0">10 dk</span>
            </div>

            {/* Activity Item 2 */}
            <div className="p-4 flex gap-3 items-start hover:bg-slate-800/30 transition-colors">
              <div className="w-8 h-8 rounded-full bg-amber-500/10 flex items-center justify-center shrink-0 mt-0.5">
                <Ticket className="h-4 w-4 text-amber-500" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-slate-200 font-medium truncate">Yeni Destek Talebi</p>
                <p className="text-xs text-slate-500 mt-0.5">Global Lojistik fatura itirazı.</p>
              </div>
              <span className="text-[10px] text-slate-500 shrink-0">1 sa</span>
            </div>

            {/* Activity Item 3 */}
            <div className="p-4 flex gap-3 items-start hover:bg-slate-800/30 transition-colors">
              <div className="w-8 h-8 rounded-full bg-red-500/10 flex items-center justify-center shrink-0 mt-0.5">
                <AlertCircle className="h-4 w-4 text-red-500" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-slate-200 font-medium truncate">Ödeme Başarısız</p>
                <p className="text-xs text-slate-500 mt-0.5">Mega Market A.Ş. (₺1.499)</p>
              </div>
              <span className="text-[10px] text-slate-500 shrink-0">3 sa</span>
            </div>
            
            {/* Activity Item 4 */}
            <div className="p-4 flex gap-3 items-start hover:bg-slate-800/30 transition-colors">
              <div className="w-8 h-8 rounded-full bg-emerald-500/10 flex items-center justify-center shrink-0 mt-0.5">
                <CheckCircle2 className="h-4 w-4 text-emerald-500" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-slate-200 font-medium truncate">Abonelik Yenileme</p>
                <p className="text-xs text-slate-500 mt-0.5">Kuzey İnşaat (₺499)</p>
              </div>
              <span className="text-[10px] text-slate-500 shrink-0">5 sa</span>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
