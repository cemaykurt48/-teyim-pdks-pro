/* eslint-disable react-hooks/set-state-in-effect */
"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { 
  Building2, 
  CreditCard, 
  LayoutDashboard, 
  LogOut, 
  Settings, 
  ShieldAlert, 
  Ticket,
  QrCode,
  Lock,
  Menu,
  X
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const superAdminLinks = [
  { name: "Genel Bakış", href: "/super-admin", icon: LayoutDashboard },
  { name: "Firmalar", href: "/super-admin/companies", icon: Building2 },
  { name: "Abonelikler", href: "/super-admin/billing", icon: CreditCard },
  { name: "Destek", href: "/super-admin/tickets", icon: Ticket },
  { name: "Loglar", href: "/super-admin/logs", icon: ShieldAlert },
  { name: "Ayarlar", href: "/super-admin/settings", icon: Settings },
];

export default function SuperAdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const router = useRouter();
  
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isChecking, setIsChecking] = useState(true);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const auth = localStorage.getItem("super_admin_auth");
    if (auth === "true") {
      setIsAuthenticated(true);
    }
    setIsChecking(false);
  }, []);

  // Close mobile menu when route changes
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [pathname]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (email === "admin@isteyim.com" && password === "admin123") {
      localStorage.setItem("super_admin_auth", "true");
      setIsAuthenticated(true);
      toast.success("Süper Admin paneline hoş geldiniz.");
    } else {
      toast.error("Hatalı e-posta veya şifre.");
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("super_admin_auth");
    setIsAuthenticated(false);
    router.push("/");
  };

  if (isChecking) {
    return <div className="min-h-screen bg-slate-950 flex items-center justify-center text-slate-400">Yükleniyor...</div>;
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
        <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl p-8 shadow-2xl">
          <div className="flex flex-col items-center mb-8 text-center">
            <div className="bg-indigo-600 p-3 rounded-xl mb-4">
              <Lock className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-white">Süper Admin Girişi</h1>
            <p className="text-slate-400 text-sm mt-2">Bu alan sadece sistem yöneticilerine özeldir.</p>
          </div>
          
          <form onSubmit={handleLogin} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-slate-300">E-posta</Label>
              <Input 
                id="email" 
                type="email" 
                placeholder="admin@isteyim.com" 
                className="bg-slate-950 border-slate-800 text-white placeholder:text-slate-600 focus-visible:ring-indigo-500 h-12"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password" className="text-slate-300">Şifre</Label>
              <Input 
                id="password" 
                type="password" 
                placeholder="••••••••" 
                className="bg-slate-950 border-slate-800 text-white placeholder:text-slate-600 focus-visible:ring-indigo-500 h-12"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
              <p className="text-xs text-slate-500 mt-1">Demo: admin@isteyim.com / admin123</p>
            </div>
            <Button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700 text-white h-12 mt-6 text-base">
              Giriş Yap
            </Button>
          </form>
          
          <div className="mt-8 text-center">
            <Button variant="link" className="text-slate-500 hover:text-slate-300" onClick={() => router.push("/")}>
              Ana Sayfaya Dön
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-50 flex flex-col md:flex-row pb-16 md:pb-0">
      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 md:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* Dark Sidebar for Super Admin (Desktop) */}
      <aside className={cn(
        "w-64 flex-col fixed inset-y-0 z-50 bg-slate-900 border-r border-slate-800 transition-transform duration-300 md:translate-x-0 md:flex",
        isMobileMenuOpen ? "translate-x-0 flex" : "-translate-x-full"
      )}>
        <div className="h-16 flex items-center justify-between px-6 border-b border-slate-800">
          <Link href="/super-admin" className="flex items-center gap-2">
            <div className="bg-indigo-600 text-white p-1.5 rounded-lg">
              <QrCode className="h-5 w-5" />
            </div>
            <span className="font-bold text-xl tracking-tight text-white">Süper Admin</span>
          </Link>
          <Button 
            variant="ghost" 
            size="icon" 
            className="md:hidden text-slate-400 hover:text-white"
            onClick={() => setIsMobileMenuOpen(false)}
          >
            <X className="h-5 w-5" />
          </Button>
        </div>
        
        <div className="flex-1 py-6 px-4 space-y-1 overflow-y-auto">
          <div className="px-3 mb-2 text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Yönetim
          </div>
          {superAdminLinks.map((link) => {
            const Icon = link.icon;
            const isActive = pathname === link.href || (link.href !== '/super-admin' && pathname.startsWith(link.href));
            
            return (
              <Link key={link.href} href={link.href}>
                <span className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors",
                  isActive 
                    ? "bg-indigo-500/10 text-indigo-400" 
                    : "text-slate-400 hover:bg-slate-800 hover:text-slate-50"
                )}>
                  <Icon className="h-5 w-5" />
                  {link.name}
                </span>
              </Link>
            );
          })}
        </div>
        
        <div className="p-4 border-t border-slate-800">
          <Button 
            variant="ghost" 
            className="w-full justify-start gap-3 text-slate-400 hover:text-red-400 hover:bg-slate-800"
            onClick={handleLogout}
          >
            <LogOut className="h-5 w-5" />
            Sistemden Çık
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 md:pl-64 flex flex-col min-h-screen w-full">
        <header className="h-16 flex items-center justify-between px-4 md:px-6 border-b border-slate-800 bg-slate-900/50 backdrop-blur sticky top-0 z-30">
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="icon" 
              className="md:hidden text-slate-400 hover:text-white"
              onClick={() => setIsMobileMenuOpen(true)}
            >
              <Menu className="h-5 w-5" />
            </Button>
            <h1 className="text-lg font-semibold text-slate-200">
              {superAdminLinks.find(l => l.href === pathname)?.name || "Süper Admin Paneli"}
            </h1>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 bg-slate-800 px-3 py-1.5 rounded-full border border-slate-700">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-xs font-medium text-slate-300 hidden sm:inline-block">Sistem Aktif</span>
            </div>
            <Button 
              variant="ghost" 
              size="icon" 
              className="md:hidden text-slate-400 hover:text-red-400"
              onClick={handleLogout}
            >
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </header>

        <div className="flex-1 p-4 md:p-6 lg:p-8">
          {children}
        </div>
      </main>

      {/* Mobile Bottom Navigation */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-slate-900 border-t border-slate-800 z-40 flex items-center justify-around px-2 py-2 pb-safe">
        {superAdminLinks.slice(0, 5).map((link) => {
          const Icon = link.icon;
          const isActive = pathname === link.href || (link.href !== '/super-admin' && pathname.startsWith(link.href));
          
          return (
            <Link key={link.href} href={link.href} className="flex-1">
              <div className={cn(
                "flex flex-col items-center justify-center py-1 gap-1 rounded-lg transition-colors",
                isActive 
                  ? "text-indigo-400" 
                  : "text-slate-400 hover:text-slate-200"
              )}>
                <Icon className="h-5 w-5" />
                <span className="text-[10px] font-medium truncate w-full text-center px-1">{link.name}</span>
              </div>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
