"use client";

import { useState, useEffect } from "react";
import { Save, Shield, Server, Bell, Mail } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";

export default function SettingsPage() {
  const [maintenanceMode, setMaintenanceMode] = useState(() => {
    if (typeof window !== "undefined") {
      return localStorage.getItem("setting_maintenance") === "true";
    }
    return false;
  });
  const [disableNewSignups, setDisableNewSignups] = useState(() => {
    if (typeof window !== "undefined") {
      return localStorage.getItem("setting_disable_signups") === "true";
    }
    return false;
  });
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  
  // Notification settings
  const [notifNewCompany, setNotifNewCompany] = useState(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("setting_notifications");
      if (saved) {
        try {
          return JSON.parse(saved).newCompany ?? true;
        } catch (e) {}
      }
    }
    return true;
  });
  const [notifPaymentFailed, setNotifPaymentFailed] = useState(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("setting_notifications");
      if (saved) {
        try {
          return JSON.parse(saved).paymentFailed ?? true;
        } catch (e) {}
      }
    }
    return true;
  });
  const [notifNewTicket, setNotifNewTicket] = useState(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("setting_notifications");
      if (saved) {
        try {
          return JSON.parse(saved).newTicket ?? true;
        } catch (e) {}
      }
    }
    return true;
  });
  const [notifSystemError, setNotifSystemError] = useState(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("setting_notifications");
      if (saved) {
        try {
          return JSON.parse(saved).systemError ?? true;
        } catch (e) {}
      }
    }
    return true;
  });

  // No useEffect needed for initial load anymore!


  const handleSave = () => {
    // Save to localStorage
    localStorage.setItem("setting_maintenance", maintenanceMode.toString());
    localStorage.setItem("setting_disable_signups", disableNewSignups.toString());
    
    localStorage.setItem("setting_notifications", JSON.stringify({
      newCompany: notifNewCompany,
      paymentFailed: notifPaymentFailed,
      newTicket: notifNewTicket,
      systemError: notifSystemError
    }));
    
    toast.success("Sistem ayarları başarıyla kaydedildi.");
  };

  const handlePasswordUpdate = () => {
    if (!currentPassword || !newPassword) {
      toast.error("Lütfen mevcut ve yeni şifrenizi girin.");
      return;
    }
    
    if (currentPassword !== "admin123") {
      toast.error("Mevcut şifreniz hatalı.");
      return;
    }
    
    if (newPassword.length < 6) {
      toast.error("Yeni şifre en az 6 karakter olmalıdır.");
      return;
    }
    
    toast.success("Şifreniz başarıyla güncellendi.");
    setCurrentPassword("");
    setNewPassword("");
  };

  return (
    <div className="space-y-6 pb-20 md:pb-0">
      <div>
        <h2 className="text-2xl font-bold tracking-tight text-white">Sistem Ayarları</h2>
        <p className="text-slate-400">
          Platformun genel davranışını ve güvenlik ayarlarını yapılandırın.
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* General Settings */}
        <Card className="bg-slate-900 border-slate-800">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Server className="w-5 h-5 text-indigo-400" />
              Platform Durumu
            </CardTitle>
            <CardDescription className="text-slate-400">
              Sistemin genel erişilebilirliğini kontrol edin.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-slate-200 text-base">Bakım Modu</Label>
                <p className="text-sm text-slate-400">Tüm kullanıcıları bakım sayfasına yönlendirir.</p>
              </div>
              <Switch 
                checked={maintenanceMode} 
                onCheckedChange={setMaintenanceMode}
                className="data-[state=checked]:bg-indigo-500"
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-slate-200 text-base">Yeni Kayıtları Kapat</Label>
                <p className="text-sm text-slate-400">Yeni firmaların sisteme kayıt olmasını engeller.</p>
              </div>
              <Switch 
                checked={disableNewSignups} 
                onCheckedChange={setDisableNewSignups}
                className="data-[state=checked]:bg-indigo-500"
              />
            </div>
          </CardContent>
        </Card>

        {/* Security Settings */}
        <Card className="bg-slate-900 border-slate-800">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Shield className="w-5 h-5 text-indigo-400" />
              Süper Admin Güvenliği
            </CardTitle>
            <CardDescription className="text-slate-400">
              Yönetici hesabınızın güvenlik ayarları.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="current-password" className="text-slate-300">Mevcut Şifre</Label>
              <Input 
                id="current-password" 
                type="password" 
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                className="bg-slate-950 border-slate-800 text-white" 
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="new-password" className="text-slate-300">Yeni Şifre</Label>
              <Input 
                id="new-password" 
                type="password" 
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="bg-slate-950 border-slate-800 text-white" 
              />
            </div>
            <Button 
              variant="outline" 
              onClick={handlePasswordUpdate}
              className="w-full bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700 hover:text-white"
            >
              Şifreyi Güncelle
            </Button>
          </CardContent>
        </Card>

        {/* Notification Settings */}
        <Card className="bg-slate-900 border-slate-800 md:col-span-2">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Bell className="w-5 h-5 text-indigo-400" />
              Sistem Bildirimleri
            </CardTitle>
            <CardDescription className="text-slate-400">
              Hangi durumlarda e-posta bildirimi alacağınızı seçin.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="flex items-center space-x-2 bg-slate-950 p-4 rounded-lg border border-slate-800">
                <Switch 
                  id="notif-new-company" 
                  checked={notifNewCompany}
                  onCheckedChange={setNotifNewCompany}
                  className="data-[state=checked]:bg-indigo-500" 
                />
                <Label htmlFor="notif-new-company" className="text-slate-300 cursor-pointer">Yeni firma kayıt olduğunda</Label>
              </div>
              <div className="flex items-center space-x-2 bg-slate-950 p-4 rounded-lg border border-slate-800">
                <Switch 
                  id="notif-payment-failed" 
                  checked={notifPaymentFailed}
                  onCheckedChange={setNotifPaymentFailed}
                  className="data-[state=checked]:bg-indigo-500" 
                />
                <Label htmlFor="notif-payment-failed" className="text-slate-300 cursor-pointer">Bir ödeme başarısız olduğunda</Label>
              </div>
              <div className="flex items-center space-x-2 bg-slate-950 p-4 rounded-lg border border-slate-800">
                <Switch 
                  id="notif-new-ticket" 
                  checked={notifNewTicket}
                  onCheckedChange={setNotifNewTicket}
                  className="data-[state=checked]:bg-indigo-500" 
                />
                <Label htmlFor="notif-new-ticket" className="text-slate-300 cursor-pointer">Yeni destek talebi açıldığında</Label>
              </div>
              <div className="flex items-center space-x-2 bg-slate-950 p-4 rounded-lg border border-slate-800">
                <Switch 
                  id="notif-system-error" 
                  checked={notifSystemError}
                  onCheckedChange={setNotifSystemError}
                  className="data-[state=checked]:bg-indigo-500" 
                />
                <Label htmlFor="notif-system-error" className="text-slate-300 cursor-pointer">Kritik sistem hatası oluştuğunda</Label>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex justify-end">
        <Button onClick={handleSave} className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 w-full sm:w-auto">
          <Save className="w-4 h-4 mr-2" />
          Değişiklikleri Kaydet
        </Button>
      </div>
    </div>
  );
}
