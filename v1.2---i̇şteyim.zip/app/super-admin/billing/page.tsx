"use client";

import { useState } from "react";
import { 
  CreditCard, 
  TrendingUp, 
  ArrowUpRight, 
  ArrowDownRight, 
  CheckCircle2, 
  XCircle,
  FileText,
  RefreshCw,
  Edit,
  ChevronLeft,
  ChevronRight,
  Building2,
  Users
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

// Generate 45 mock transactions
const generateMockTransactions = () => {
  const plans = ["Başlangıç", "Pro", "Enterprise"];
  const statuses = ["success", "success", "success", "failed"]; // 25% fail rate
  const amounts = ["₺0.00", "₺499.00", "₺1,499.00"];
  
  const transactions = [];
  for (let i = 1; i <= 45; i++) {
    const planIndex = i % 3;
    transactions.push({
      id: `TRX-${10000 + i}`,
      company: `Firma ${i} A.Ş.`,
      amount: amounts[planIndex],
      date: `0${(i % 9) + 1} Nis 2026`,
      time: `1${i % 9}:${i % 5}0`,
      status: statuses[i % 4],
      plan: plans[planIndex]
    });
  }
  return transactions.reverse();
};

const initialTransactions = generateMockTransactions();

const initialPlans = [
  { id: 1, name: "Başlangıç", price: "0", interval: "ay", maxStaff: "5", maxBranch: "1", activeSubscribers: 45 },
  { id: 2, name: "Pro", price: "499", interval: "ay", maxStaff: "Sınırsız", maxBranch: "Sınırsız", activeSubscribers: 68 },
  { id: 3, name: "Enterprise", price: "Özel", interval: "ay", maxStaff: "Sınırsız", maxBranch: "Sınırsız", activeSubscribers: 11 },
];

export default function BillingPage() {
  const [transactions, setTransactions] = useState(initialTransactions);
  const [plans, setPlans] = useState(initialPlans);
  const [currentPage, setCurrentPage] = useState(1);
  
  // Dialog States
  const [selectedTransaction, setSelectedTransaction] = useState<typeof initialTransactions[0] | null>(null);
  const [isTransactionDialogOpen, setIsTransactionDialogOpen] = useState(false);
  
  // Edit Plan State
  const [editingPlan, setEditingPlan] = useState<typeof initialPlans[0] | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  
  const itemsPerPage = 15;
  const totalPages = Math.ceil(transactions.length / itemsPerPage);
  const paginatedTransactions = transactions.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const openTransactionDetails = (trx: typeof initialTransactions[0]) => {
    setSelectedTransaction(trx);
    setIsTransactionDialogOpen(true);
  };

  const handleViewInvoice = (id: string) => {
    toast.info(`${id} numaralı fatura indiriliyor...`);
  };

  const handleRetryPayment = (id: string) => {
    toast.success(`${id} numaralı işlem için ödeme yeniden deneniyor...`);
    setIsTransactionDialogOpen(false);
  };

  const handleEditPlan = (plan: typeof initialPlans[0]) => {
    setEditingPlan({ ...plan });
    setIsEditDialogOpen(true);
  };

  const handleSavePlan = () => {
    if (editingPlan) {
      setPlans(plans.map(p => p.id === editingPlan.id ? editingPlan : p));
      toast.success(`${editingPlan.name} paketi başarıyla güncellendi.`);
      setIsEditDialogOpen(false);
    }
  };

  return (
    <div className="space-y-6 pb-20 md:pb-0">
      {/* Header */}
      <div className="flex flex-col gap-4 sticky top-0 z-10 bg-slate-950/80 backdrop-blur-md pt-2 pb-4 sm:pt-0 sm:bg-transparent sm:backdrop-blur-none">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-white">Finans ve Abonelikler</h2>
          <p className="text-slate-400 text-sm mt-1">
            Gelir metriklerini, paketleri ve ödeme geçmişini yönetin.
          </p>
        </div>
      </div>

      <Tabs defaultValue="transactions" className="w-full flex flex-col">
        {/* Sticky Tabs List */}
        <div className="sticky top-[88px] sm:top-0 z-10 bg-slate-950/80 backdrop-blur-md py-2 sm:py-0 sm:bg-transparent sm:backdrop-blur-none mb-6">
          <TabsList className="w-full sm:w-auto bg-slate-900 border border-slate-800 p-1 h-12 rounded-xl">
            <TabsTrigger value="transactions" className="flex-1 sm:px-8 rounded-lg data-[state=active]:bg-slate-800 data-[state=active]:text-white text-xs sm:text-sm">
              Özet & İşlemler
            </TabsTrigger>
            <TabsTrigger value="plans" className="flex-1 sm:px-8 rounded-lg data-[state=active]:bg-slate-800 data-[state=active]:text-white text-xs sm:text-sm">
              Paketler
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="transactions" className="space-y-6 mt-0">
          {/* Big MRR Display */}
          <Card className="bg-gradient-to-br from-indigo-500/10 to-purple-500/10 border-indigo-500/20 overflow-hidden">
            <CardContent className="p-6 flex flex-col items-center justify-center text-center">
              <p className="text-xs sm:text-sm font-medium text-indigo-400/80 uppercase tracking-wider mb-2">Aylık Tekrarlayan Gelir (MRR)</p>
              <h1 className="text-4xl sm:text-5xl font-bold text-white tracking-tight break-all">₺48.500</h1>
              <div className="flex items-center gap-1.5 mt-3 text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-full text-xs sm:text-sm font-medium">
                <TrendingUp className="w-4 h-4" />
                <span>+%12 geçen aya göre</span>
              </div>
            </CardContent>
          </Card>

          {/* Secondary KPIs */}
          <div className="grid grid-cols-2 gap-3 md:gap-4">
            <Card className="bg-slate-900 border-slate-800 overflow-hidden">
              <CardContent className="p-3 sm:p-4">
                <p className="text-[10px] sm:text-xs font-medium text-slate-400 mb-1 truncate">Aktif Abonelik</p>
                <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-1">
                  <h3 className="text-xl sm:text-2xl font-bold text-white">79</h3>
                  <span className="text-[10px] text-emerald-400 flex items-center"><ArrowUpRight className="w-3 h-3 mr-0.5" /> 5 yeni</span>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-slate-900 border-slate-800 overflow-hidden">
              <CardContent className="p-3 sm:p-4">
                <p className="text-[10px] sm:text-xs font-medium text-slate-400 mb-1 truncate">Bekleyen Tahsilat</p>
                <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-1">
                  <h3 className="text-xl sm:text-2xl font-bold text-white">₺1.497</h3>
                  <span className="text-[10px] text-red-400 flex items-center"><ArrowDownRight className="w-3 h-3 mr-0.5" /> 3 hata</span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Transaction List (Banking Style) */}
          <div>
            <h3 className="text-sm font-medium text-slate-400 uppercase tracking-wider mb-3">Son İşlemler</h3>
            <Card className="bg-slate-900 border-slate-800 overflow-hidden">
              <div className="flex flex-col divide-y divide-slate-800/50">
                {paginatedTransactions.map((trx) => (
                  <div 
                    key={trx.id} 
                    className="flex items-center justify-between p-4 cursor-pointer hover:bg-slate-800/30 transition-colors active:bg-slate-800/50"
                    onClick={() => openTransactionDetails(trx)}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                        trx.status === 'success' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-red-500/10 text-red-500'
                      }`}>
                        {trx.status === 'success' ? <CheckCircle2 className="w-5 h-5" /> : <XCircle className="w-5 h-5" />}
                      </div>
                      <div>
                        <p className="text-sm font-medium text-slate-200">{trx.company}</p>
                        <p className="text-xs text-slate-500">{trx.date} • {trx.time}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`text-sm font-bold ${trx.status === 'success' ? 'text-emerald-400' : 'text-slate-200'}`}>
                        {trx.status === 'success' ? '+' : ''}{trx.amount}
                      </p>
                      <p className="text-[10px] text-slate-500">{trx.plan}</p>
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex items-center justify-center sm:justify-end gap-2 pt-4">
                <Button 
                  variant="outline" 
                  size="icon" 
                  className="h-9 w-9 bg-slate-900 border-slate-800 text-slate-300 rounded-lg"
                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  disabled={currentPage === 1}
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <div className="px-4 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 text-sm font-medium">
                  {currentPage} / {totalPages}
                </div>
                <Button 
                  variant="outline" 
                  size="icon" 
                  className="h-9 w-9 bg-slate-900 border-slate-800 text-slate-300 rounded-lg"
                  onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                  disabled={currentPage === totalPages}
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="plans" className="space-y-4 mt-0">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {plans.map((plan) => (
              <Card key={plan.id} className="bg-slate-900 border-slate-800 flex flex-col">
                <CardContent className="p-6 flex-1 flex flex-col">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-xl font-bold text-white">{plan.name}</h3>
                      <div className="mt-2 flex items-baseline gap-1">
                        <span className="text-3xl font-bold text-indigo-400">{plan.price === "Özel" ? plan.price : `₺${plan.price}`}</span>
                        {plan.price !== "Özel" && <span className="text-sm text-slate-500">/{plan.interval}</span>}
                      </div>
                    </div>
                    <div className="bg-indigo-500/10 text-indigo-400 px-2.5 py-1 rounded-full text-xs font-medium border border-indigo-500/20">
                      {plan.activeSubscribers} Abone
                    </div>
                  </div>

                  <div className="space-y-3 my-6 flex-1">
                    <div className="flex items-center gap-2 text-sm text-slate-300">
                      <Users className="w-4 h-4 text-slate-500" />
                      <span>Maksimum Personel: <strong className="text-white">{plan.maxStaff}</strong></span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-slate-300">
                      <Building2 className="w-4 h-4 text-slate-500" />
                      <span>Maksimum Şube: <strong className="text-white">{plan.maxBranch}</strong></span>
                    </div>
                  </div>

                  <Button 
                    variant="outline" 
                    className="w-full bg-slate-950 border-slate-800 hover:bg-slate-800 text-slate-200 h-12 rounded-xl"
                    onClick={() => handleEditPlan(plan)}
                  >
                    <Edit className="w-4 h-4 mr-2" />
                    Paketi Düzenle
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* Transaction Details Dialog */}
      <Dialog open={isTransactionDialogOpen} onOpenChange={setIsTransactionDialogOpen}>
        <DialogContent className="bg-slate-900 border-slate-800 text-slate-200 sm:max-w-sm w-[95vw] rounded-2xl p-0 overflow-hidden">
          {selectedTransaction && (
            <>
              <div className="p-6 text-center border-b border-slate-800/50 bg-slate-950/50">
                <div className={`w-16 h-16 rounded-full mx-auto flex items-center justify-center mb-4 ${
                  selectedTransaction.status === 'success' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-red-500/10 text-red-500'
                }`}>
                  {selectedTransaction.status === 'success' ? <CheckCircle2 className="w-8 h-8" /> : <XCircle className="w-8 h-8" />}
                </div>
                <h2 className="text-3xl font-bold text-white mb-1">{selectedTransaction.amount}</h2>
                <p className="text-sm text-slate-400">{selectedTransaction.company}</p>
              </div>

              <div className="p-6 space-y-4">
                <div className="flex justify-between items-center py-2 border-b border-slate-800/50">
                  <span className="text-sm text-slate-500">İşlem ID</span>
                  <span className="text-sm font-medium text-slate-200">{selectedTransaction.id}</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-slate-800/50">
                  <span className="text-sm text-slate-500">Tarih & Saat</span>
                  <span className="text-sm font-medium text-slate-200">{selectedTransaction.date} - {selectedTransaction.time}</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-slate-800/50">
                  <span className="text-sm text-slate-500">Paket</span>
                  <span className="text-sm font-medium text-slate-200">{selectedTransaction.plan}</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-slate-800/50">
                  <span className="text-sm text-slate-500">Durum</span>
                  <span className={`text-sm font-medium ${selectedTransaction.status === 'success' ? 'text-emerald-400' : 'text-red-400'}`}>
                    {selectedTransaction.status === 'success' ? 'Başarılı' : 'Başarısız'}
                  </span>
                </div>

                <div className="pt-4 space-y-2.5">
                  {selectedTransaction.status === 'failed' ? (
                    <Button 
                      className="w-full h-12 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl"
                      onClick={() => handleRetryPayment(selectedTransaction.id)}
                    >
                      <RefreshCw className="w-5 h-5 mr-2" />
                      Ödemeyi Tekrar Dene
                    </Button>
                  ) : (
                    <Button 
                      className="w-full h-12 bg-slate-800 hover:bg-slate-700 text-white rounded-xl"
                      onClick={() => handleViewInvoice(selectedTransaction.id)}
                    >
                      <FileText className="w-5 h-5 mr-2" />
                      Faturayı İndir
                    </Button>
                  )}
                  <Button 
                    variant="ghost" 
                    className="w-full h-12 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl"
                    onClick={() => setIsTransactionDialogOpen(false)}
                  >
                    Kapat
                  </Button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Edit Plan Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="bg-slate-900 border-slate-800 text-slate-200 sm:max-w-sm rounded-2xl">
          <DialogHeader>
            <DialogTitle className="text-white">Paketi Düzenle</DialogTitle>
          </DialogHeader>
          
          {editingPlan && (
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label className="text-slate-400">Paket Adı</Label>
                <Input 
                  value={editingPlan.name} 
                  onChange={(e) => setEditingPlan({...editingPlan, name: e.target.value})}
                  className="bg-slate-950 border-slate-800 text-slate-200 h-12 rounded-xl"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-slate-400">Aylık Fiyat (₺)</Label>
                <Input 
                  value={editingPlan.price} 
                  onChange={(e) => setEditingPlan({...editingPlan, price: e.target.value})}
                  className="bg-slate-950 border-slate-800 text-slate-200 h-12 rounded-xl"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-slate-400">Maksimum Personel</Label>
                <Input 
                  value={editingPlan.maxStaff} 
                  onChange={(e) => setEditingPlan({...editingPlan, maxStaff: e.target.value})}
                  className="bg-slate-950 border-slate-800 text-slate-200 h-12 rounded-xl"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-slate-400">Maksimum Şube</Label>
                <Input 
                  value={editingPlan.maxBranch} 
                  onChange={(e) => setEditingPlan({...editingPlan, maxBranch: e.target.value})}
                  className="bg-slate-950 border-slate-800 text-slate-200 h-12 rounded-xl"
                />
              </div>
            </div>
          )}
          
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)} className="border-slate-700 text-slate-300 hover:bg-slate-800 rounded-xl h-11">
              İptal
            </Button>
            <Button onClick={handleSavePlan} className="bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl h-11">
              Değişiklikleri Kaydet
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
