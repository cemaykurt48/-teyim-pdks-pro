"use client";

import { useState } from "react";
import { 
  Ticket, 
  MessageSquare, 
  Clock, 
  AlertCircle, 
  Search,
  MoreVertical,
  Eye,
  CheckCircle2,
  Reply,
  ChevronDown,
  ChevronUp,
  ChevronLeft,
  ChevronRight,
  Send
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { InfoBubble } from "@/components/info-bubble";

// Generate 35 mock tickets
const generateMockTickets = () => {
  const statuses = ["new", "open", "resolved"];
  const priorities = ["high", "medium", "low"];
  const subjects = [
    "Yeni şube ekleyemiyorum", 
    "Fatura adresi değişikliği", 
    "Kiosk modu tablet uyumluluğu", 
    "Personel PIN kodunu unuttu", 
    "Abonelik iptali hakkında",
    "Raporlar yüklenmiyor",
    "Sisteme giriş yapamıyoruz"
  ];
  
  const tickets = [];
  for (let i = 1; i <= 35; i++) {
    tickets.push({
      id: `TCK-${1000 + i}`,
      company: `Firma ${i} A.Ş.`,
      subject: subjects[i % subjects.length],
      status: statuses[i % 3],
      priority: priorities[i % 3],
      date: `${(i % 24) + 1} saat önce`,
      messages: Math.floor(Math.random() * 5) + 1
    });
  }
  return tickets.reverse();
};

const initialTickets = generateMockTickets();

export default function TicketsPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [tickets, setTickets] = useState(initialTickets);
  const [currentPage, setCurrentPage] = useState(1);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  
  // Dialog States
  const [selectedTicket, setSelectedTicket] = useState<typeof initialTickets[0] | null>(null);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [isReplyDialogOpen, setIsReplyDialogOpen] = useState(false);
  const [replyMessage, setReplyMessage] = useState("");
  
  // Announcement State
  const [isAnnouncementDialogOpen, setIsAnnouncementDialogOpen] = useState(false);
  const [announcementTitle, setAnnouncementTitle] = useState("");
  const [announcementMessage, setAnnouncementMessage] = useState("");
  
  const itemsPerPage = 10;

  const filteredTickets = tickets.filter(ticket => {
    const matchesSearch = ticket.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          ticket.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          ticket.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === "all" || ticket.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const totalPages = Math.ceil(filteredTickets.length / itemsPerPage);
  const paginatedTickets = filteredTickets.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const handleView = (ticket: typeof initialTickets[0]) => {
    setSelectedTicket(ticket);
    setIsViewDialogOpen(true);
  };

  const handleReply = (ticket: typeof initialTickets[0]) => {
    setSelectedTicket(ticket);
    setReplyMessage("");
    setIsReplyDialogOpen(true);
  };

  const handleSendReply = () => {
    if (selectedTicket && replyMessage.trim()) {
      toast.success(`${selectedTicket.id} numaralı talebe yanıt gönderildi.`);
      setIsReplyDialogOpen(false);
      setReplyMessage("");
    } else {
      toast.error("Lütfen bir yanıt mesajı yazın.");
    }
  };

  const handleResolve = (id: string) => {
    setTickets(tickets.map(t => t.id === id ? { ...t, status: "resolved" } : t));
    toast.success(`${id} numaralı talep çözüldü olarak işaretlendi.`);
  };

  const handlePublishAnnouncement = () => {
    if (announcementTitle.trim() && announcementMessage.trim()) {
      toast.success("Genel duyuru başarıyla yayınlandı.");
      setIsAnnouncementDialogOpen(false);
      setAnnouncementTitle("");
      setAnnouncementMessage("");
    } else {
      toast.error("Lütfen başlık ve mesaj alanlarını doldurun.");
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "new":
        return <Badge className="bg-blue-500/10 text-blue-400 border-blue-500/20 hover:bg-blue-500/20">Yeni</Badge>;
      case "open":
        return <Badge className="bg-amber-500/10 text-amber-400 border-amber-500/20 hover:bg-amber-500/20">Açık</Badge>;
      case "resolved":
        return <Badge className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20 hover:bg-emerald-500/20">Çözüldü</Badge>;
      default:
        return <Badge variant="outline">Bilinmiyor</Badge>;
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case "high":
        return <AlertCircle className="w-4 h-4 text-red-400" />;
      case "medium":
        return <AlertCircle className="w-4 h-4 text-amber-400" />;
      case "low":
        return <AlertCircle className="w-4 h-4 text-blue-400" />;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            Destek Talepleri
            <InfoBubble content="Müşterilerinizin oluşturduğu tüm destek taleplerini (ticket) buradan takip edebilir ve yanıtlayabilirsiniz." />
          </h2>
          <p className="text-slate-400">
            Müşterilerden gelen yardım taleplerini ve sistem bildirimlerini yönetin.
          </p>
        </div>
        <div className="flex gap-2 w-full sm:w-auto">
          <div className="relative flex items-center w-full sm:w-auto">
            <Button 
              variant="outline" 
              className="bg-slate-900 border-slate-800 text-slate-200 hover:bg-slate-800 hover:text-white w-full pr-10"
              onClick={() => setIsAnnouncementDialogOpen(true)}
            >
              <MessageSquare className="w-4 h-4 mr-2" />
              Genel Duyuru Yayınla
            </Button>
            <div className="absolute right-2">
              <InfoBubble content="Tüm müşterilerinizin (firmaların) panelinde görünecek genel bir duyuru mesajı yayınlayın." className="w-6 h-6 hover:bg-slate-800" iconClassName="text-slate-400 hover:text-white" />
            </div>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card className="bg-slate-900 border-slate-800 text-slate-50">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-400">
              Bekleyen Talepler
            </CardTitle>
            <Ticket className="h-4 w-4 text-blue-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{tickets.filter(t => t.status !== 'resolved').length}</div>
            <p className="text-xs text-slate-400 mt-1">
              İşlem bekleyen aktif talepler
            </p>
          </CardContent>
        </Card>
        
        <Card className="bg-slate-900 border-slate-800 text-slate-50">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-400">
              Ortalama Yanıt Süresi
            </CardTitle>
            <Clock className="h-4 w-4 text-amber-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">45 dk</div>
            <p className="text-xs text-emerald-400 mt-1">
              Geçen haftaya göre %15 daha hızlı
            </p>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-800 text-slate-50">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-400">
              Çözülen Talepler (Bu Ay)
            </CardTitle>
            <CheckCircle2 className="h-4 w-4 text-emerald-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{tickets.filter(t => t.status === 'resolved').length}</div>
            <p className="text-xs text-slate-400 mt-1">
              %98 müşteri memnuniyeti
            </p>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-slate-900 border-slate-800">
        <div className="p-4 border-b border-slate-800 flex flex-col sm:flex-row justify-between gap-4">
          <div className="relative w-full sm:w-72">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-500" />
            <Input
              placeholder="Talep ID, firma veya konu ara..."
              className="pl-9 bg-slate-950 border-slate-800 text-slate-200 placeholder:text-slate-500 focus-visible:ring-indigo-500"
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
            />
          </div>
          <div className="flex gap-2 overflow-x-auto pb-1 sm:pb-0">
            <Button 
              variant="outline" 
              size="sm" 
              className={`whitespace-nowrap ${filterStatus === 'all' ? 'bg-slate-800 text-white border-slate-700' : 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800 hover:text-white'}`}
              onClick={() => { setFilterStatus('all'); setCurrentPage(1); }}
            >
              Tümü
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className={`whitespace-nowrap ${filterStatus === 'open' ? 'bg-slate-800 text-white border-slate-700' : 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800 hover:text-white'}`}
              onClick={() => { setFilterStatus('open'); setCurrentPage(1); }}
            >
              Açık
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className={`whitespace-nowrap ${filterStatus === 'resolved' ? 'bg-slate-800 text-white border-slate-700' : 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800 hover:text-white'}`}
              onClick={() => { setFilterStatus('resolved'); setCurrentPage(1); }}
            >
              Çözüldü
            </Button>
          </div>
        </div>
        
        {/* Desktop Table View */}
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="text-xs text-slate-400 uppercase bg-slate-900/50 border-b border-slate-800">
              <tr>
                <th className="px-6 py-4 font-medium">Talep</th>
                <th className="px-6 py-4 font-medium">Firma</th>
                <th className="px-6 py-4 font-medium">Durum</th>
                <th className="px-6 py-4 font-medium">Öncelik</th>
                <th className="px-6 py-4 font-medium">Son Güncelleme</th>
                <th className="px-6 py-4 font-medium text-right">İşlem</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {paginatedTickets.map((ticket) => (
                <tr key={ticket.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex flex-col">
                      <span className="font-medium text-slate-200">{ticket.subject}</span>
                      <span className="text-xs text-slate-500">{ticket.id} • {ticket.messages} mesaj</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 font-medium text-slate-300">
                    {ticket.company}
                  </td>
                  <td className="px-6 py-4">
                    {getStatusBadge(ticket.status)}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-1.5 text-slate-300">
                      {getPriorityIcon(ticket.priority)}
                      <span className="capitalize">{ticket.priority === 'high' ? 'Yüksek' : ticket.priority === 'medium' ? 'Orta' : 'Düşük'}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-slate-400">
                    {ticket.date}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger render={
                        <Button variant="ghost" size="icon" className="text-slate-400 hover:text-slate-200 hover:bg-slate-800">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      } />
                      <DropdownMenuContent align="end" className="bg-slate-900 border-slate-800 text-slate-200">
                        <DropdownMenuItem className="hover:bg-slate-800 focus:bg-slate-800 cursor-pointer" onClick={() => handleView(ticket)}>
                          <Eye className="mr-2 h-4 w-4 text-slate-400" />
                          <span>Görüntüle</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem className="hover:bg-slate-800 focus:bg-slate-800 cursor-pointer" onClick={() => handleReply(ticket)}>
                          <Reply className="mr-2 h-4 w-4 text-slate-400" />
                          <span>Yanıtla</span>
                        </DropdownMenuItem>
                        {ticket.status !== "resolved" && (
                          <>
                            <DropdownMenuSeparator className="bg-slate-800" />
                            <DropdownMenuItem 
                              className="hover:bg-emerald-500/20 focus:bg-emerald-500/20 text-emerald-400 cursor-pointer"
                              onClick={() => handleResolve(ticket.id)}
                            >
                              <CheckCircle2 className="mr-2 h-4 w-4" />
                              <span>Çözüldü İşaretle</span>
                            </DropdownMenuItem>
                          </>
                        )}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Mobile Compact List View */}
        <div className="md:hidden flex flex-col divide-y divide-slate-800">
          {paginatedTickets.map((ticket) => (
            <div key={ticket.id} className="flex flex-col">
              <div 
                className="p-4 flex items-center justify-between cursor-pointer hover:bg-slate-800/30 transition-colors"
                onClick={() => setExpandedId(expandedId === ticket.id ? null : ticket.id)}
              >
                <div className="flex flex-col">
                  <span className="font-medium text-slate-200">{ticket.subject}</span>
                  <div className="flex items-center gap-2 mt-1">
                    {getStatusBadge(ticket.status)}
                    <span className="text-xs text-slate-500">{ticket.id} • {ticket.company}</span>
                  </div>
                </div>
                <div className="text-slate-500">
                  {expandedId === ticket.id ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                </div>
              </div>
              
              {expandedId === ticket.id && (
                <div className="p-4 pt-0 bg-slate-800/10 flex flex-col gap-3 animate-in slide-in-from-top-2 duration-200">
                  <div className="flex flex-wrap items-center gap-2 mt-2">
                    <div className="flex items-center gap-1 text-xs text-slate-300 bg-slate-800 px-2 py-1 rounded-md">
                      {getPriorityIcon(ticket.priority)}
                      <span className="capitalize">{ticket.priority === 'high' ? 'Yüksek' : ticket.priority === 'medium' ? 'Orta' : 'Düşük'}</span>
                    </div>
                    <div className="flex items-center gap-1 text-xs text-slate-400 bg-slate-800 px-2 py-1 rounded-md">
                      <Clock className="w-3 h-3" />
                      {ticket.date}
                    </div>
                    <div className="flex items-center gap-1 text-xs text-slate-400 bg-slate-800 px-2 py-1 rounded-md">
                      <MessageSquare className="w-3 h-3" />
                      {ticket.messages} mesaj
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    <Button variant="outline" size="sm" className="bg-slate-900 border-slate-700 text-slate-300" onClick={() => handleView(ticket)}>
                      <Eye className="w-4 h-4 mr-2" /> Görüntüle
                    </Button>
                    <Button variant="outline" size="sm" className="bg-slate-900 border-slate-700 text-slate-300" onClick={() => handleReply(ticket)}>
                      <Reply className="w-4 h-4 mr-2" /> Yanıtla
                    </Button>
                    {ticket.status !== "resolved" && (
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="col-span-2 bg-emerald-500/10 border-emerald-500/20 text-emerald-400"
                        onClick={() => handleResolve(ticket.id)}
                      >
                        <CheckCircle2 className="w-4 h-4 mr-2" /> Çözüldü İşaretle
                      </Button>
                    )}
                  </div>
                </div>
              )}
            </div>
          ))}
          {paginatedTickets.length === 0 && (
            <div className="p-8 text-center text-slate-500">
              Arama kriterlerinize uygun talep bulunamadı.
            </div>
          )}
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="p-4 border-t border-slate-800 flex items-center justify-between text-sm text-slate-400">
            <div>
              Toplam <span className="text-slate-200 font-medium">{filteredTickets.length}</span> kayıt
            </div>
            <div className="flex items-center gap-2">
              <Button 
                variant="outline" 
                size="icon" 
                className="h-8 w-8 bg-slate-900 border-slate-700 text-slate-300"
                onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <span className="text-slate-300">
                {currentPage} / {totalPages}
              </span>
              <Button 
                variant="outline" 
                size="icon" 
                className="h-8 w-8 bg-slate-900 border-slate-700 text-slate-300"
                onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                disabled={currentPage === totalPages}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </Card>

      {/* View Ticket Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="bg-slate-900 border-slate-800 text-slate-200 sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center gap-2">
              <Ticket className="w-5 h-5 text-indigo-400" />
              Talep Detayı: {selectedTicket?.id}
            </DialogTitle>
            <DialogDescription className="text-slate-400">
              {selectedTicket?.company} tarafından oluşturulan destek talebi.
            </DialogDescription>
          </DialogHeader>
          
          {selectedTicket && (
            <div className="space-y-6 py-4">
              <div className="flex flex-col gap-2 p-4 bg-slate-950 rounded-lg border border-slate-800">
                <div className="flex justify-between items-start">
                  <h3 className="text-lg font-medium text-white">{selectedTicket.subject}</h3>
                  {getStatusBadge(selectedTicket.status)}
                </div>
                <div className="flex items-center gap-4 text-sm text-slate-400 mt-2">
                  <div className="flex items-center gap-1">
                    {getPriorityIcon(selectedTicket.priority)}
                    <span className="capitalize">{selectedTicket.priority === 'high' ? 'Yüksek' : selectedTicket.priority === 'medium' ? 'Orta' : 'Düşük'} Öncelik</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    {selectedTicket.date}
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h4 className="text-sm font-medium text-slate-300 border-b border-slate-800 pb-2">Mesaj Geçmişi</h4>
                
                <div className="space-y-4 max-h-[300px] overflow-y-auto pr-2">
                  {/* Mock Initial Message */}
                  <div className="flex flex-col gap-1">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-indigo-400">{selectedTicket.company}</span>
                      <span className="text-xs text-slate-500">{selectedTicket.date}</span>
                    </div>
                    <div className="bg-slate-800/50 p-3 rounded-lg text-sm text-slate-300">
                      Merhaba, sistemde karşılaştığımız bir sorun hakkında destek rica ediyoruz. Konuyla ilgili detaylar şöyledir...
                    </div>
                  </div>
                  
                  {/* Mock Reply if messages > 1 */}
                  {selectedTicket.messages > 1 && (
                    <div className="flex flex-col gap-1 items-end">
                      <div className="flex items-center justify-between w-full flex-row-reverse">
                        <span className="text-sm font-medium text-emerald-400">Destek Ekibi</span>
                        <span className="text-xs text-slate-500">Kısa süre sonra</span>
                      </div>
                      <div className="bg-indigo-500/10 border border-indigo-500/20 p-3 rounded-lg text-sm text-slate-300 text-right">
                        Talebiniz alınmıştır, ekibimiz konuyu inceliyor. En kısa sürede size dönüş yapacağız.
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
          
          <DialogFooter className="flex gap-2 sm:justify-between">
            {selectedTicket?.status !== 'resolved' ? (
              <Button 
                variant="outline" 
                className="bg-emerald-500/10 border-emerald-500/20 text-emerald-400 hover:bg-emerald-500/20 hover:text-emerald-300"
                onClick={() => {
                  if (selectedTicket) {
                    handleResolve(selectedTicket.id);
                    setIsViewDialogOpen(false);
                  }
                }}
              >
                <CheckCircle2 className="w-4 h-4 mr-2" />
                Çözüldü İşaretle
              </Button>
            ) : (
              <div></div> // Empty div for spacing
            )}
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setIsViewDialogOpen(false)} className="bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700">
                Kapat
              </Button>
              {selectedTicket?.status !== 'resolved' && (
                <Button 
                  onClick={() => {
                    if (selectedTicket) {
                      setIsViewDialogOpen(false);
                      handleReply(selectedTicket);
                    }
                  }} 
                  className="bg-indigo-600 hover:bg-indigo-700 text-white"
                >
                  <Reply className="w-4 h-4 mr-2" />
                  Yanıtla
                </Button>
              )}
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reply Ticket Dialog */}
      <Dialog open={isReplyDialogOpen} onOpenChange={setIsReplyDialogOpen}>
        <DialogContent className="bg-slate-900 border-slate-800 text-slate-200 sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center gap-2">
              <Reply className="w-5 h-5 text-indigo-400" />
              Talebe Yanıt Ver
            </DialogTitle>
            <DialogDescription className="text-slate-400">
              {selectedTicket?.id} numaralı talep için yanıtınızı yazın.
            </DialogDescription>
          </DialogHeader>
          
          {selectedTicket && (
            <div className="grid gap-4 py-4">
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-md">
                <p className="text-xs text-slate-500 mb-1">Talep Konusu</p>
                <p className="text-sm font-medium text-slate-300">{selectedTicket.subject}</p>
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="reply-message" className="text-slate-300">Yanıtınız</Label>
                <Textarea 
                  id="reply-message" 
                  placeholder="Müşteriye iletilecek mesajınızı buraya yazın..." 
                  className="min-h-[150px] bg-slate-950 border-slate-800 text-slate-200 placeholder:text-slate-600 focus-visible:ring-indigo-500"
                  value={replyMessage}
                  onChange={(e) => setReplyMessage(e.target.value)}
                />
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsReplyDialogOpen(false)} className="bg-transparent border-slate-700 text-slate-300 hover:bg-slate-800">
              İptal
            </Button>
            <Button onClick={handleSendReply} className="bg-indigo-600 hover:bg-indigo-700 text-white">
              <Send className="w-4 h-4 mr-2" />
              Yanıtı Gönder
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Announcement Dialog */}
      <Dialog open={isAnnouncementDialogOpen} onOpenChange={setIsAnnouncementDialogOpen}>
        <DialogContent className="bg-slate-900 border-slate-800 text-slate-200 sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-indigo-400" />
              Genel Duyuru Yayınla
            </DialogTitle>
            <DialogDescription className="text-slate-400">
              Tüm firmaların panelinde görünecek bir duyuru yayınlayın.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="announcement-title" className="text-slate-300">Duyuru Başlığı</Label>
              <Input 
                id="announcement-title" 
                placeholder="Örn: Planlı Bakım Çalışması" 
                className="bg-slate-950 border-slate-800 text-slate-200 placeholder:text-slate-600 focus-visible:ring-indigo-500"
                value={announcementTitle}
                onChange={(e) => setAnnouncementTitle(e.target.value)}
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="announcement-message" className="text-slate-300">Duyuru İçeriği</Label>
              <Textarea 
                id="announcement-message" 
                placeholder="Duyuru detaylarını buraya yazın..." 
                className="min-h-[150px] bg-slate-950 border-slate-800 text-slate-200 placeholder:text-slate-600 focus-visible:ring-indigo-500"
                value={announcementMessage}
                onChange={(e) => setAnnouncementMessage(e.target.value)}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAnnouncementDialogOpen(false)} className="bg-transparent border-slate-700 text-slate-300 hover:bg-slate-800">
              İptal
            </Button>
            <Button onClick={handlePublishAnnouncement} className="bg-indigo-600 hover:bg-indigo-700 text-white">
              <Send className="w-4 h-4 mr-2" />
              Yayınla
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
