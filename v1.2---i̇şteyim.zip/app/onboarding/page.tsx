"use client";

import { useState, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Building2, CreditCard, MapPin, Clock, 
  CheckCircle2, ArrowRight, Briefcase, User, Trash2, Plus, Lock,
  Phone, Target, Lightbulb, Users, ShieldCheck, Camera
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import confetti from "canvas-confetti";
import { useRouter } from "next/navigation";
import { toPng } from "html-to-image";
import { toast } from "sonner";

// --- SCHEMAS ---
const surveySchema = z.object({
  companyName: z.string().min(2, "Firma adı zorunludur"),
  employeeCount: z.string().min(1, "Lütfen çalışan sayısını seçin"),
  mainChallenge: z.string().min(1, "Lütfen en büyük zorluğunuzu seçin"),
});

const contactSchema = z.object({
  phone: z.string().min(10, "Geçerli bir telefon numarası girin"),
  companyType: z.string().min(1, "Lütfen şirket türünü seçin"),
});

const STEPS = [
  { id: "survey", title: "İşletmeniz", icon: Target },
  { id: "contact", title: "İletişim", icon: Phone },
  { id: "branches", title: "Şubeler", icon: MapPin },
  { id: "shifts", title: "Vardiyalar", icon: Clock },
  { id: "payment", title: "Abonelik", icon: CreditCard },
  { id: "success", title: "Tamamlandı", icon: CheckCircle2 },
];

export default function OnboardingPage() {
  const [currentStep, setCurrentStep] = useState(0);
  const [direction, setDirection] = useState(1);
  const router = useRouter();

  // Forms
  const surveyForm = useForm({
    resolver: zodResolver(surveySchema),
    defaultValues: { companyName: "", employeeCount: "", mainChallenge: "" }
  });

  const contactForm = useForm({
    resolver: zodResolver(contactSchema),
    defaultValues: { phone: "", companyType: "ltd" }
  });

  // State for Branches & Shifts
  const [branches, setBranches] = useState([{ id: 1, name: "Merkez Şube" }]);
  const [shifts, setShifts] = useState([
    { id: 1, name: "Sabah", time: "08:00 - 16:00" },
    { id: 2, name: "Akşam", time: "16:00 - 00:00" }
  ]);

  // State for Payment
  const [selectedPlan, setSelectedPlan] = useState<"free" | "pro">("pro");
  const successRef = useRef<HTMLDivElement>(null);

  const nextStep = () => {
    setDirection(1);
    setCurrentStep(prev => Math.min(prev + 1, STEPS.length - 1));
  };

  const prevStep = () => {
    setDirection(-1);
    setCurrentStep(prev => Math.max(prev - 1, 0));
  };

  const handleSurveySubmit = (data: any) => {
    nextStep();
  };

  const handleContactSubmit = (data: any) => {
    nextStep();
  };

  const finishOnboarding = () => {
    confetti({
      particleCount: 150,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#4f46e5', '#3b82f6', '#10b981', '#f59e0b']
    });
    setTimeout(() => {
      router.push("/dashboard");
    }, 3000);
  };

  const downloadSummary = async () => {
    if (!successRef.current) return;
    
    const toastId = toast.loading("Özet görseli hazırlanıyor...");
    try {
      const dataUrl = await toPng(successRef.current, {
        cacheBust: true,
        backgroundColor: "#ffffff",
      });
      const link = document.createElement("a");
      link.download = `isteyim-kurulum-ozeti.png`;
      link.href = dataUrl;
      link.click();
      toast.success("Özet başarıyla kaydedildi!", { id: toastId });
    } catch (err) {
      toast.error("Görsel oluşturulurken bir hata oluştu.", { id: toastId });
    }
  };

  const variants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 50 : -50,
      opacity: 0
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1
    },
    exit: (direction: number) => ({
      zIndex: 0,
      x: direction < 0 ? 50 : -50,
      opacity: 0
    })
  };

  const companyName = surveyForm.watch("companyName") || "İşletmeniz";
  const employeeCount = surveyForm.watch("employeeCount");
  const mainChallenge = surveyForm.watch("mainChallenge");

  // --- RENDERERS ---
  const renderStepContent = () => {
    switch (currentStep) {
      case 0: // SURVEY
        return (
          <div className="space-y-6">
            <div className="text-center mb-6">
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white">İşletmenizi Tanıyalım</h2>
              <p className="text-sm sm:text-base text-slate-500 dark:text-slate-400 mt-2">Size en uygun deneyimi sunabilmemiz için birkaç kısa soru.</p>
            </div>

            <form onSubmit={surveyForm.handleSubmit(handleSurveySubmit)} className="space-y-5">
              <div className="space-y-2">
                <Label className="text-sm font-semibold">İşletme / Firma Adı <span className="text-rose-500">*</span></Label>
                <Input {...surveyForm.register("companyName")} placeholder="Örn: Acme Kafe" className="h-12 rounded-xl bg-white dark:bg-slate-900" />
                {surveyForm.formState.errors.companyName && <p className="text-xs text-rose-500">{surveyForm.formState.errors.companyName.message as string}</p>}
              </div>
              
              <div className="space-y-3">
                <Label className="text-sm font-semibold">Kaç çalışanınız var?</Label>
                <div className="grid grid-cols-3 gap-2">
                  {['1-10', '11-50', '50+'].map((size) => (
                    <div 
                      key={size}
                      onClick={() => surveyForm.setValue("employeeCount", size, { shouldValidate: true })}
                      className={`h-12 flex items-center justify-center rounded-xl border cursor-pointer transition-all text-sm font-medium ${
                        employeeCount === size 
                          ? "border-blue-600 bg-blue-50 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300" 
                          : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-blue-300"
                      }`}
                    >
                      {size}
                    </div>
                  ))}
                </div>
                {surveyForm.formState.errors.employeeCount && <p className="text-xs text-rose-500">{surveyForm.formState.errors.employeeCount.message as string}</p>}
              </div>

              <div className="space-y-3">
                <Label className="text-sm font-semibold">Şu an en çok hangi konuda zorlanıyorsunuz?</Label>
                <div className="grid grid-cols-1 gap-2">
                  {[
                    { id: "puantaj", label: "Ay sonu puantaj ve maaş hesaplama" },
                    { id: "vardiya", label: "Vardiya planlama ve karmaşası" },
                    { id: "izin", label: "Personel izin ve rapor takibi" },
                    { id: "takip", label: "Personelin işe geliş gidiş takibi" }
                  ].map((challenge) => (
                    <div 
                      key={challenge.id}
                      onClick={() => surveyForm.setValue("mainChallenge", challenge.id, { shouldValidate: true })}
                      className={`p-3 rounded-xl border cursor-pointer transition-all text-sm font-medium ${
                        mainChallenge === challenge.id 
                          ? "border-blue-600 bg-blue-50 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300" 
                          : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-blue-300"
                      }`}
                    >
                      {challenge.label}
                    </div>
                  ))}
                </div>
                {surveyForm.formState.errors.mainChallenge && <p className="text-xs text-rose-500">{surveyForm.formState.errors.mainChallenge.message as string}</p>}
              </div>

              <div className="pt-2">
                <Button type="submit" className="w-full h-12 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-base">
                  Devam Et <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </form>
          </div>
        );

      case 1: // CONTACT
        return (
          <div className="space-y-6">
            <div className="text-center mb-6">
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white">İletişim Bilgileri</h2>
              <p className="text-sm sm:text-base text-slate-500 dark:text-slate-400 mt-2">Hesabınızın güvenliği ve faturalandırma için gerekli temel bilgiler.</p>
            </div>

            <form onSubmit={contactForm.handleSubmit(handleContactSubmit)} className="space-y-5">
              <div className="space-y-2">
                <Label className="text-sm font-semibold">Yetkili Telefon Numarası <span className="text-rose-500">*</span></Label>
                <Input {...contactForm.register("phone")} placeholder="0555 555 55 55" className="h-12 rounded-xl bg-white dark:bg-slate-900" />
                {contactForm.formState.errors.phone && <p className="text-xs text-rose-500">{contactForm.formState.errors.phone.message as string}</p>}
              </div>
              
              <div className="space-y-2">
                <Label className="text-sm font-semibold">Şirket Türü</Label>
                <Select onValueChange={(val) => val && contactForm.setValue("companyType", val)} defaultValue={contactForm.getValues("companyType")}>
                  <SelectTrigger className="h-12 rounded-xl bg-white dark:bg-slate-900">
                    <SelectValue placeholder="Seçiniz" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sahis">Şahıs Şirketi</SelectItem>
                    <SelectItem value="ltd">Limited Şirketi (Ltd. Şti.)</SelectItem>
                    <SelectItem value="as">Anonim Şirketi (A.Ş.)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="bg-slate-50 dark:bg-slate-900/50 p-4 rounded-xl border text-sm text-slate-500 dark:text-slate-400 flex gap-3">
                <ShieldCheck className="w-5 h-5 text-slate-400 shrink-0" />
                <p>Vergi No, Vergi Dairesi ve açık adres gibi detaylı fatura bilgilerinizi daha sonra yönetim panelinden girebilirsiniz.</p>
              </div>

              <div className="flex gap-3 pt-4">
                <Button type="button" variant="outline" onClick={prevStep} className="h-12 rounded-xl px-6">
                  Geri
                </Button>
                <Button type="submit" className="flex-1 h-12 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-base">
                  Devam Et <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </form>
          </div>
        );

      case 2: // BRANCHES
        return (
          <div className="space-y-6">
            <div className="text-center mb-6">
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white">Şubelerinizi Ekleyin</h2>
              <p className="text-sm sm:text-base text-slate-500 dark:text-slate-400 mt-2"><span className="font-semibold text-blue-600">{companyName}</span> için ilk şubelerinizi oluşturalım.</p>
            </div>

            <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-800/50 p-4 rounded-xl flex gap-3 mb-6">
              <Lightbulb className="w-5 h-5 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
              <p className="text-sm text-blue-900 dark:text-blue-200 leading-relaxed">
                <strong>İpucu:</strong> Eklediğiniz her şube için sistem otomatik bir QR kod üretir. Personeliniz sadece bu şubeye geldiğinde kendi telefonuyla giriş yapabilir. Sahte konumları engeller.
              </p>
            </div>

            <div className="space-y-3 max-h-[35vh] overflow-y-auto pr-2">
              {branches.map((branch, index) => (
                <div key={branch.id} className="flex items-center gap-3">
                  <div className="flex-1 relative">
                    <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                    <Input 
                      value={branch.name} 
                      onChange={(e) => {
                        const newBranches = [...branches];
                        newBranches[index].name = e.target.value;
                        setBranches(newBranches);
                      }}
                      className="pl-10 h-12 rounded-xl bg-white dark:bg-slate-900" 
                    />
                  </div>
                  {branches.length > 1 && (
                    <Button variant="ghost" size="icon" onClick={() => setBranches(branches.filter(b => b.id !== branch.id))} className="h-12 w-12 text-rose-500 hover:bg-rose-50 rounded-xl shrink-0">
                      <Trash2 className="w-5 h-5" />
                    </Button>
                  )}
                </div>
              ))}
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setBranches([...branches, { id: Date.now(), name: "Yeni Şube" }])} 
                className="w-full h-12 border-dashed text-blue-600 border-blue-200 hover:bg-blue-50 rounded-xl"
              >
                <Plus className="w-4 h-4 mr-2" /> Şube Ekle
              </Button>
            </div>

            <div className="flex gap-3 pt-4">
              <Button type="button" variant="outline" onClick={prevStep} className="h-12 rounded-xl px-6">
                Geri
              </Button>
              <Button type="button" onClick={nextStep} className="flex-1 h-12 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-base">
                Devam Et <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>
        );

      case 3: // SHIFTS
        return (
          <div className="space-y-6">
            <div className="text-center mb-6">
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white">Vardiya Saatleri</h2>
              <p className="text-sm sm:text-base text-slate-500 dark:text-slate-400 mt-2">Temel çalışma saatlerinizi belirleyin.</p>
            </div>

            <div className="bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-100 dark:border-emerald-800/50 p-4 rounded-xl flex gap-3 mb-6">
              <Lightbulb className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
              <p className="text-sm text-emerald-900 dark:text-emerald-200 leading-relaxed">
                <strong>Otomatik Puantaj:</strong> Bu saatleri bir kez girin. Sistem geç kalanları, erken çıkanları ve mesaileri ay sonunda otomatik hesaplayıp önünüze getirsin.
              </p>
            </div>

            <div className="space-y-3 max-h-[35vh] overflow-y-auto pr-2">
              {shifts.map((shift, index) => (
                <div key={shift.id} className="flex items-center gap-3 bg-slate-50 dark:bg-slate-900/50 p-3 rounded-xl border">
                  <div className="flex-1 space-y-1">
                    <Label className="text-xs text-muted-foreground">Vardiya Adı</Label>
                    <Input 
                      value={shift.name} 
                      onChange={(e) => {
                        const newShifts = [...shifts];
                        newShifts[index].name = e.target.value;
                        setShifts(newShifts);
                      }}
                      className="h-10 bg-white dark:bg-slate-950" 
                    />
                  </div>
                  <div className="flex-1 space-y-1">
                    <Label className="text-xs text-muted-foreground">Saat Aralığı</Label>
                    <Input 
                      value={shift.time} 
                      onChange={(e) => {
                        const newShifts = [...shifts];
                        newShifts[index].time = e.target.value;
                        setShifts(newShifts);
                      }}
                      placeholder="08:00 - 16:00"
                      className="h-10 bg-white dark:bg-slate-950" 
                    />
                  </div>
                  {shifts.length > 1 && (
                    <Button variant="ghost" size="icon" onClick={() => setShifts(shifts.filter(s => s.id !== shift.id))} className="h-10 w-10 mt-5 text-rose-500 hover:bg-rose-50 rounded-lg shrink-0">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              ))}
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setShifts([...shifts, { id: Date.now(), name: "Yeni Vardiya", time: "12:00 - 20:00" }])} 
                className="w-full h-12 border-dashed text-blue-600 border-blue-200 hover:bg-blue-50 rounded-xl"
              >
                <Plus className="w-4 h-4 mr-2" /> Vardiya Ekle
              </Button>
            </div>

            <div className="flex gap-3 pt-4">
              <Button type="button" variant="outline" onClick={prevStep} className="h-12 rounded-xl px-6">
                Geri
              </Button>
              <Button type="button" onClick={nextStep} className="flex-1 h-12 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-base">
                Devam Et <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>
        );

      case 4: // PAYMENT
        return (
          <div className="space-y-6">
            <div className="text-center mb-6">
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white">Abonelik Planı</h2>
              <p className="text-sm sm:text-base text-slate-500 dark:text-slate-400 mt-2">İhtiyacınıza uygun planı seçerek kurulumu tamamlayın.</p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div 
                onClick={() => setSelectedPlan("free")}
                className={`p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                  selectedPlan === "free" ? "border-blue-600 bg-blue-50 dark:bg-blue-900/20" : "border-slate-200 dark:border-slate-800 hover:border-blue-300"
                }`}
              >
                <h4 className="font-bold text-slate-900 dark:text-white">Başlangıç</h4>
                <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Ücretsiz</p>
              </div>
              <div 
                onClick={() => setSelectedPlan("pro")}
                className={`relative p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                  selectedPlan === "pro" ? "border-blue-600 bg-blue-50 dark:bg-blue-900/20" : "border-slate-200 dark:border-slate-800 hover:border-blue-300"
                }`}
              >
                {selectedPlan === "pro" && (
                  <div className="absolute -top-2 -right-2 bg-blue-600 text-white rounded-full p-0.5">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                )}
                <h4 className="font-bold text-slate-900 dark:text-white">Pro Plan</h4>
                <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">₺499/ay</p>
              </div>
            </div>

            <AnimatePresence>
              {selectedPlan === "pro" && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="overflow-hidden"
                >
                  <div className="space-y-3 mt-4 p-4 bg-slate-50 dark:bg-slate-900/50 rounded-2xl border">
                    <div className="relative">
                      <Input placeholder="Kart Numarası" className="h-11 rounded-xl pl-10 bg-white dark:bg-slate-950" />
                      <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <Input placeholder="AA/YY" className="h-11 rounded-xl bg-white dark:bg-slate-950" />
                      <div className="relative">
                        <Input placeholder="CVC" type="password" maxLength={3} className="h-11 rounded-xl pr-10 bg-white dark:bg-slate-950" />
                        <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="flex gap-3 pt-6">
              <Button type="button" variant="outline" onClick={prevStep} className="h-12 rounded-xl px-6">
                Geri
              </Button>
              <Button type="button" onClick={nextStep} className="flex-1 h-12 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-base">
                Kurulumu Tamamla <CheckCircle2 className="w-5 h-5 ml-2" />
              </Button>
            </div>
          </div>
        );

      case 5: // SUCCESS
        return (
          <div ref={successRef} className="text-center space-y-6 py-10 bg-white dark:bg-slate-950 p-6 rounded-3xl">
            <div className="w-24 h-24 bg-emerald-100 dark:bg-emerald-900/30 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle2 className="w-12 h-12 text-emerald-600 dark:text-emerald-400" />
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-slate-900 dark:text-white">Kurulum Tamamlandı! 🎉</h2>
            <p className="text-base sm:text-lg text-slate-500 dark:text-slate-400 max-w-md mx-auto">
              <span className="font-semibold text-slate-700 dark:text-slate-300">{companyName}</span> başarıyla oluşturuldu. Artık personellerinizi ekleyebilir ve akıllı vardiya planlamaya başlayabilirsiniz.
            </p>
            <div className="pt-8 flex flex-col gap-3">
              <Button onClick={finishOnboarding} className="h-14 px-8 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white text-lg shadow-xl shadow-blue-200 dark:shadow-none hover:scale-105 transition-transform w-full">
                İlk Personelinizi Ekleyin <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
              <Button variant="outline" onClick={downloadSummary} className="h-12 rounded-xl border-blue-200 text-blue-600 hover:bg-blue-50 w-full">
                <Camera className="w-4 h-4 mr-2" /> Özeti Görsel Olarak Kaydet
              </Button>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="h-[100dvh] w-full flex bg-slate-50 dark:bg-slate-950 overflow-hidden">
      {/* LEFT PANEL - BRANDING & INFO (Hidden on Mobile) */}
      <div className="hidden lg:flex flex-col justify-between w-[45%] bg-blue-600 p-12 relative overflow-hidden">
        {/* Background Elements */}
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
          <div className="absolute -top-24 -left-24 w-96 h-96 bg-white opacity-10 rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-blue-400 opacity-20 rounded-full blur-3xl translate-x-1/3 translate-y-1/3"></div>
        </div>

        <div className="relative z-10">
          <div className="flex items-center gap-2 text-white mb-16">
            <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center">
              <Briefcase className="w-6 h-6 text-blue-600" />
            </div>
            <span className="text-2xl font-bold tracking-tight">İşteyim</span>
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={currentStep}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="space-y-6"
            >
              <div className="w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center backdrop-blur-sm border border-white/20">
                {(() => {
                  const Icon = STEPS[currentStep]?.icon || CheckCircle2;
                  return <Icon className="w-8 h-8 text-white" />;
                })()}
              </div>
              <h1 className="text-4xl font-bold text-white leading-tight">
                {currentStep === 0 && "İşletmenizi Birlikte Büyütelim."}
                {currentStep === 1 && "İletişimde Kalalım."}
                {currentStep === 2 && "Organizasyon Yapınızı Kurun."}
                {currentStep === 3 && "Çalışma Saatlerinizi Belirleyin."}
                {currentStep === 4 && "Aboneliğinizi Başlatın."}
                {currentStep === 5 && "Her Şey Hazır!"}
              </h1>
              <p className="text-blue-100 text-lg max-w-md">
                {currentStep === 0 && "Size en uygun çözümleri sunabilmemiz için işletmenizi biraz daha yakından tanımak istiyoruz."}
                {currentStep === 1 && "Hesap güvenliğiniz ve faturalandırma işlemleri için temel iletişim bilgilerinizi alıyoruz."}
                {currentStep === 2 && "Şubelerinizi ekleyerek personellerinizi doğru konumlandırın ve sahte girişleri engelleyin."}
                {currentStep === 3 && "Esnek vardiya şablonları ile işletmenizin çalışma düzenini sisteme öğretin, puantajı otomatiğe bağlayın."}
                {currentStep === 4 && "İşletmenizin büyüklüğüne uygun planı seçerek tüm özelliklerin kilidini açın."}
                {currentStep === 5 && "Tebrikler! İşletmeniz için en iyi vardiya yönetim deneyimini yaşamaya hazırsınız."}
              </p>
            </motion.div>
          </AnimatePresence>
        </div>

        <div className="relative z-10 flex items-center gap-4 text-blue-200 text-sm">
          <div className="flex -space-x-2">
            {[1, 2, 3].map((i) => (
              <div key={i} className="w-8 h-8 rounded-full bg-blue-400 border-2 border-blue-600 flex items-center justify-center text-xs font-bold text-white">
                {String.fromCharCode(64 + i)}
              </div>
            ))}
          </div>
          <p>1000+ işletme bize güveniyor</p>
        </div>
      </div>

      {/* RIGHT PANEL - WIZARD */}
      <div className="flex-1 flex flex-col h-full relative overflow-hidden bg-white dark:bg-slate-950">
        {/* Progress Bar */}
        <div className="w-full h-1.5 bg-slate-100 dark:bg-slate-800 absolute top-0 left-0 z-50">
          <motion.div 
            className="h-full bg-blue-600"
            initial={{ width: "0%" }}
            animate={{ width: `${((currentStep + 1) / STEPS.length) * 100}%` }}
            transition={{ duration: 0.3 }}
          />
        </div>

        {/* Mobile Step Indicator */}
        <div className="lg:hidden absolute top-6 left-0 w-full flex justify-center z-40 pointer-events-none">
          <div className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-md px-4 py-1.5 rounded-full text-xs font-medium text-blue-600 border shadow-sm">
            Adım {currentStep + 1} / {STEPS.length}
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto overflow-x-hidden p-4 sm:p-8 flex items-center justify-center">
          <div className="w-full max-w-md relative">
            <AnimatePresence mode="wait" custom={direction}>
              <motion.div
                key={currentStep}
                custom={direction}
                variants={variants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ duration: 0.3, ease: "easeInOut" }}
                className="w-full"
              >
                {renderStepContent()}
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
}
