# Security Specification: İşteyim App

## 1. Data Invariants
- A `Company` document is the root of most access control. The `ownerId` of the company must match the authenticated `request.auth.uid`.
- Once a `Company` is created, its `ownerId` and `createdAt` fields are immutable.
- `Branch`, `Staff`, `AttendanceLog`, and `LeaveRequest` reside as subcollections under the company path.
- Accessing any subcollection document requires resolving the parent `Company` and verifying that `request.auth.uid` is the `ownerId`.
- Super Admins are resolved by checking if their uid exists in the `/admins/{uid}` collection. Super admins have global read and write privileges over `Company` and `SupportTicket`.

## 2. The "Dirty Dozen" Payloads
1. **Identity Spoofing**: Changing `ownerId` during an update to another user's UID.
   - *Result*: Should reject (cannot modify `ownerId`).
2. **State Shortcutting / Unapproved Write**: Updating `status` of a `LeaveRequest` from 'pending' to 'approved' by a non-owner/non-manager.
   - *Result*: Should reject (staff cannot approve their own leave).
3. **Ghost Field / Shadow Update**: Creating a `Branch` with an extra field like `isVerified: true`.
   - *Result*: Should reject (strict key validation).
4. **Denial of Wallet (DoW) Size**: Giving a `name` array or string of 1MB in size for `Staff`.
   - *Result*: Should reject (max length constraint).
5. **Path ID Poisoning**: Sending a `companyId` path parameter that is massive or contains invalid characters.
   - *Result*: Should reject (`isValidId` check).
6. **Time Travel / Timestamp Forgery**: Creating a `AttendanceLog` with `timestamp` set manually by client rather than `request.time`.
   - *Result*: Should reject (must be server time, though we must be mindful if the app needs to sync offline logs. In this app, we will enforce `request.time` unless an admin is editing).
7. **Orphaned Write**: Creating a `Staff` record in a `companyId` that doesn't exist.
   - *Result*: Should reject (`exists()` on company).
8. **PII Blanket Read**: A Staff querying `/companies/{cId}/staff` and getting phone numbers or PINs of others.
   - *Result*: Right now, Staff needs to see themselves. Only the Boss/Owner can list all staff.
9. **Query Scraper**: Executing `allow list` without restricting to `ownerId` or `staffId`.
   - *Result*: Should reject (Missing explicit `resource.data` check in rules).
10. **Terminal State Break**: Altering an `AttendanceLog` that has already been verified/closed by a manager.
    - *Result*: Log records shouldn't be altered once written unless by the Owner.
11. **Type Poisoning**: Sending `radius` as a string instead of number in `Branch`.
    - *Result*: Should reject (Schema check `data.radius is number`).
12. **Unverified Email / Auth Leak**: `request.auth` has a valid email but `email_verified == false`.
    - *Result*: We must ensure owners have verified accounts to create/manage companies.

## 3. Test Configuration
The next step is to create a test runner (`firestore.rules.test.ts`) that will validate these invariants using the firebase firestore emulator and rules setup.
