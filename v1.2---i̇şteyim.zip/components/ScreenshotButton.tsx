"use client";

import React, { useRef } from "react";
import { Camera, Download } from "lucide-react";
import { toPng } from "html-to-image";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export function ScreenshotButton() {
  const takeScreenshot = async () => {
    const element = document.body;
    if (!element) return;

    const toastId = toast.loading("Ekran görüntüsü hazırlanıyor...");

    try {
      // Hide the screenshot button itself before taking the picture
      const btn = document.getElementById("global-screenshot-btn");
      if (btn) btn.style.display = "none";

      const dataUrl = await toPng(element, {
        cacheBust: true,
        backgroundColor: "#f8fafc", // slate-50 default
      });

      // Show the button back
      if (btn) btn.style.display = "flex";

      const link = document.createElement("a");
      link.download = `isteyim-ekran-goruntusu-${new Date().getTime()}.png`;
      link.href = dataUrl;
      link.click();

      toast.success("Ekran görüntüsü kaydedildi!", { id: toastId });
    } catch (err) {
      console.error("Screenshot error:", err);
      toast.error("Ekran görüntüsü alınırken bir hata oluştu.", { id: toastId });
      
      // Ensure button is visible again on error
      const btn = document.getElementById("global-screenshot-btn");
      if (btn) btn.style.display = "flex";
    }
  };

  return (
    <Button
      id="global-screenshot-btn"
      onClick={takeScreenshot}
      variant="outline"
      size="icon"
      className="fixed bottom-6 right-6 z-[9999] h-12 w-12 rounded-full shadow-2xl bg-white dark:bg-slate-900 border-2 border-blue-600 text-blue-600 hover:bg-blue-50 hover:scale-110 transition-all active:scale-95"
      title="Ekran Görüntüsü Al"
    >
      <Camera className="h-6 w-6" />
    </Button>
  );
}
