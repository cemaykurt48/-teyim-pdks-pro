"use client";

import { useEffect } from "react";

export function PointerCapturePolyfill() {
  useEffect(() => {
    if (typeof window !== "undefined") {
      const originalReleasePointerCapture = Element.prototype.releasePointerCapture;
      Element.prototype.releasePointerCapture = function (pointerId) {
        try {
          originalReleasePointerCapture.call(this, pointerId);
        } catch (e) {
          if (e instanceof DOMException && e.name === "NotFoundError") {
            // Ignore the error
          } else {
            throw e;
          }
        }
      };
    }
  }, []);

  return null;
}
