"use client";

import React from "react";
import { HelpCircle } from "lucide-react";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

interface InfoBubbleProps {
  content: React.ReactNode;
  className?: string;
  iconClassName?: string;
}

export function InfoBubble({ content, className, iconClassName }: InfoBubbleProps) {
  return (
    <Popover>
      <PopoverTrigger 
        className={`inline-flex items-center justify-center rounded-full w-6 h-6 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-1 ${className || ""}`}
        aria-label="Bilgi"
      >
        <HelpCircle className={`w-4 h-4 text-slate-400 hover:text-blue-500 transition-colors ${iconClassName || ""}`} />
      </PopoverTrigger>
      <PopoverContent 
        className="w-64 text-sm p-3 bg-slate-900 text-slate-100 border-slate-800 shadow-lg rounded-xl z-50"
        sideOffset={8}
        align="center"
      >
        {content}
      </PopoverContent>
    </Popover>
  );
}
