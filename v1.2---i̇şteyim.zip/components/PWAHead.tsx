"use client";

import { usePathname } from "next/navigation";
import { useEffect } from "react";

export default function PWAHead() {
  const pathname = usePathname();
  
  // Determine which manifest to use
  const isStaffApp = pathname.startsWith("/staff-app");
  const isDashboard = pathname.startsWith("/dashboard");
  
  let manifestPath = "/manifest.json";
  if (isStaffApp) manifestPath = "/manifest-staff.json";
  if (isDashboard) manifestPath = "/manifest-admin.json";

  useEffect(() => {
    // Request notification permission on load if not granted
    if ("Notification" in window && Notification.permission === "default") {
      Notification.requestPermission();
    }
  }, []);

  return (
    <>
      <link rel="manifest" href={manifestPath} />
      <meta name="apple-mobile-web-app-capable" content="yes" />
      <meta name="apple-mobile-web-app-status-bar-style" content="default" />
      <meta name="apple-mobile-web-app-title" content="İşteyim" />
      <meta name="theme-color" content={isDashboard ? "#0f172a" : "#2563eb"} />
    </>
  );
}
