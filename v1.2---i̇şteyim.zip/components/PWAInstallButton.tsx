"use client";

import { usePWAInstall } from "@/hooks/usePWAInstall";
import { Button } from "@/components/ui/button";
import { Download, Smartphone } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function PWAInstallButton() {
  const { installPrompt, isInstalled, install } = usePWAInstall();

  if (isInstalled || !installPrompt) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 20 }}
        className="fixed bottom-20 left-4 right-4 z-50 md:bottom-8 md:left-auto md:right-8 md:w-80"
      >
        <div className="bg-primary text-primary-foreground p-4 rounded-2xl shadow-2xl border border-primary-foreground/10 flex flex-col gap-3">
          <div className="flex items-center gap-3">
            <div className="bg-white/20 p-2 rounded-xl">
              <Smartphone className="h-6 w-6" />
            </div>
            <div>
              <h4 className="font-bold text-sm">Uygulamayı Yükle</h4>
              <p className="text-xs opacity-90">Hızlı erişim için ana ekrana ekleyin.</p>
            </div>
          </div>
          <Button 
            onClick={install} 
            variant="secondary" 
            className="w-full font-bold gap-2 h-11 rounded-xl"
          >
            <Download className="h-4 w-4" />
            Ana Ekrana Ekle
          </Button>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
