import firebaseRulesPlugin from "@firebase/eslint-plugin-security-rules";

export default [
    {
        plugins: {
            "@firebase/security-rules": firebaseRulesPlugin
        },
        files: ["**/*.rules"],
        rules: {
            ...firebaseRulesPlugin.configs.recommended.rules
        }
    }
]
